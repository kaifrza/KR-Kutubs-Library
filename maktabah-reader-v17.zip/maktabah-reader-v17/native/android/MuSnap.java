package com.kr.urdulibrary;

import android.graphics.Bitmap;

/**
 * Finds the text line under a finger on a rendered page, so a marker stroke on a scanned page
 * can snap to the line instead of wobbling. Works on pixels only, so it also works for scans.
 */
final class MuSnap {
    private MuSnap() { }

    /**
     * Looks at rows around y in the column range [x0, x1] and returns the dark band nearest to y.
     * out = top, bottom (bitmap pixels). Returns false when there is no clear line (blank area, picture).
     */
    static boolean band(Bitmap b, int x0, int x1, int y, int reach, float[] out) {
        if (b == null || b.isRecycled()) return false;
        int w = b.getWidth(), h = b.getHeight();
        x0 = Math.max(0, Math.min(w - 1, x0));
        x1 = Math.max(x0 + 1, Math.min(w, x1));
        int from = Math.max(0, y - reach), to = Math.min(h - 1, y + reach);
        if (to - from < 6) return false;
        int n = to - from + 1;
        float[] dark = new float[n];
        int[] row = new int[x1 - x0];
        int step = Math.max(1, (x1 - x0) / 160);
        float max = 0f, sum = 0f;
        for (int i = 0; i < n; i++) {
            b.getPixels(row, 0, x1 - x0, x0, from + i, x1 - x0, 1);
            float d = 0f;
            int cnt = 0;
            for (int j = 0; j < row.length; j += step) {
                int p = row[j];
                int lum = (((p >> 16) & 255) * 77 + ((p >> 8) & 255) * 150 + (p & 255) * 29) >> 8;
                d += 255 - lum;
                cnt++;
            }
            dark[i] = cnt == 0 ? 0f : d / cnt;
            max = Math.max(max, dark[i]);
            sum += dark[i];
        }
        float mean = sum / n;
        if (max < 14f || max < mean * 1.35f) return false;   // flat region: nothing to snap to
        float thr = mean + (max - mean) * 0.30f;
        // smooth a little so gaps between letters of Urdu / Arabic script do not split a line
        float[] s = new float[n];
        for (int i = 0; i < n; i++) {
            float a = dark[Math.max(0, i - 1)], c = dark[i], d = dark[Math.min(n - 1, i + 1)];
            s[i] = (a + c * 2f + d) / 4f;
        }
        int cy = y - from;
        int best = -1, bd = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            if (s[i] >= thr && Math.abs(i - cy) < bd) { bd = Math.abs(i - cy); best = i; }
        }
        if (best < 0) return false;
        int t = best, bt = best;
        int gap = 0;
        while (t > 0) { if (s[t - 1] >= thr) { t--; gap = 0; } else if (++gap <= 2 && t > 1 && s[t - 2] >= thr) { t -= 2; gap = 0; } else break; }
        gap = 0;
        while (bt < n - 1) { if (s[bt + 1] >= thr) { bt++; gap = 0; } else if (++gap <= 2 && bt < n - 2 && s[bt + 2] >= thr) { bt += 2; gap = 0; } else break; }
        if (bt - t < 4) return false;
        if (bt - t > reach * 1.9f) return false;              // too tall to be one line (a picture or a block)
        out[0] = from + t;
        out[1] = from + bt + 1;
        return true;
    }
}
