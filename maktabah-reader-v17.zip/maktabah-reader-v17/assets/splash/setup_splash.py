#!/usr/bin/env python3
"""Native Android launch screen = plain app-background colour, NO icon.

Why: the in-app splash (js/splash.js + css/splash.css) already shows the logo, name and tagline. If Android
also showed its own icon splash first, the user would see two different splash screens one after the other.
So the native launch screen only paints the app background (no icon) and the in-app splash is the one splash.

Run from the repo root by build-apk.yml AFTER `npx cap add android`. It only adds/patches RESOURCES:
  - res/drawable/kr_splash_blank.xml        fully transparent 1-pixel vector (Android 12+ requires "an icon")
  - res/drawable/kr_splash_window.xml       plain background colour (Android 11 and older launch window)
  - res/values/kr_splash_colors.xml         #F7F7F5   (same as the app background, light)
  - res/values-night/kr_splash_colors.xml   #101512   (same as the app background, dark)
  - res/values/styles.xml                   AppTheme.NoActionBarLaunch (the theme MainActivity launches with)

It never fails the build: if the generated project looks different from what it expects, it prints a
warning and changes nothing.
"""
import os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.environ.get("ANDROID_RES", "android/app/src/main/res")
MANIFEST = os.environ.get("ANDROID_MANIFEST", "android/app/src/main/AndroidManifest.xml")
BG_LIGHT, BG_DARK = "#F7F7F5", "#101512"          # keep in sync with --bg in css/variables.css and MainActivity

def warn(msg):
    print("::warning::Native splash skipped - " + msg)

def main():
    styles_path = os.path.join(RES, "values", "styles.xml")
    if not os.path.isfile(styles_path):
        return warn(styles_path + " not found")
    styles = open(styles_path, encoding="utf-8").read()

    pattern = re.compile(r'<style\s+name="AppTheme\.NoActionBarLaunch"[^>]*>.*?</style>', re.S)
    match = pattern.search(styles)
    if not match:
        return warn("style AppTheme.NoActionBarLaunch not found in styles.xml")
    parent_match = re.search(r'parent="([^"]+)"', match.group(0))
    parent = parent_match.group(1) if parent_match else "Theme.SplashScreen"

    items = [
        '        <item name="android:windowBackground">@drawable/kr_splash_window</item>',
        '        <item name="android:background">@drawable/kr_splash_window</item>',
    ]
    if "SplashScreen" in parent:      # androidx.core:core-splashscreen attributes (Android 12+ system splash)
        items = [
            '        <item name="windowSplashScreenBackground">@color/kr_splash_bg</item>',
            '        <item name="windowSplashScreenAnimatedIcon">@drawable/kr_splash_blank</item>',
            '        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>',
        ] + items
    new_style = ('<style name="AppTheme.NoActionBarLaunch" parent="%s">\n%s\n    </style>' % (parent, "\n".join(items)))

    # ---- everything is validated: now write ----
    os.makedirs(os.path.join(RES, "drawable"), exist_ok=True)
    with open(os.path.join(RES, "drawable", "kr_splash_blank.xml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n'
                '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
                '    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n'
                '    <path android:fillColor="#00000000" android:pathData="M0,0h1v1h-1z" />\n'
                '</vector>\n')
    with open(os.path.join(RES, "drawable", "kr_splash_window.xml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n'
                '<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
                '    <item android:drawable="@color/kr_splash_bg" />\n'
                '</layer-list>\n')

    for folder, color in (("values", BG_LIGHT), ("values-night", BG_DARK)):
        os.makedirs(os.path.join(RES, folder), exist_ok=True)
        with open(os.path.join(RES, folder, "kr_splash_colors.xml"), "w", encoding="utf-8") as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
                    '    <color name="kr_splash_bg">%s</color>\n</resources>\n' % color)

    with open(styles_path, "w", encoding="utf-8") as f:
        f.write(pattern.sub(lambda _m: new_style, styles, count=1))

    # The template's own full-screen splash.png is unused now; drop it only if nothing still points at it.
    leftover = False
    for root, _dirs, files in os.walk(RES):
        for name in files:
            if name.endswith((".xml",)):
                if "@drawable/splash" in open(os.path.join(root, name), encoding="utf-8", errors="ignore").read():
                    leftover = True
    if os.path.isfile(MANIFEST) and "@drawable/splash" in open(MANIFEST, encoding="utf-8").read():
        leftover = True
    if not leftover:
        for root, _dirs, files in os.walk(RES):
            for name in files:
                if name == "splash.png":
                    os.remove(os.path.join(root, name))

    if os.path.isfile(MANIFEST) and "NoActionBarLaunch" not in open(MANIFEST, encoding="utf-8").read():
        print("::warning::AndroidManifest.xml does not use AppTheme.NoActionBarLaunch - the native splash will not show.")
    print("Native splash installed (parent=%s)." % parent)

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:                      # never break the APK build because of the splash
        warn(repr(exc))
        sys.exit(0)
