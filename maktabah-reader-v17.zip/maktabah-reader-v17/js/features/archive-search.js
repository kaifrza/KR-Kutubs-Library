// Archive.org search for books that are NOT in the Maktabah library.
//
// Archive results are kept in a small SEPARATE registry (memory + localStorage). They are never
// merged into the Supabase library cache, so the real catalogue stays clean.
//
// An archive book looks like a normal book object (so bookCard / book detail / reader work
// unchanged) with:  id = "ia:<identifier>", isArchive = true, source.pageUrl = details page.
// The existing readerSourceForBook() already turns that page URL into archive.org/embed/<id>.
// The direct PDF file name is resolved lazily (archive.org/metadata) only when the user
// taps Download, so searching stays fast.

import { getFavorites, getHistory } from "../utils/storage.js";
import { analyzeQuery, buildStrategies, scoreItem, isUrduItem } from "./archive-query.js";

const ARCHIVE_PREFIX = "ia:";
const ADVANCED_SEARCH = "https://archive.org/advancedsearch.php";
const METADATA = "https://archive.org/metadata/";
const STORE_KEY = "kr-archive-books-v1";
const STORE_LIMIT = 300;
const REQUEST_TIMEOUT_MS = 12000;

const registry = new Map();
let loadedFromStorage = false;

export const isArchiveId = id => String(id || "").startsWith(ARCHIVE_PREFIX);
export const archiveIdentifier = id => String(id || "").slice(ARCHIVE_PREFIX.length);

function loadStore() {
  if (loadedFromStorage) return;
  loadedFromStorage = true;
  try {
    const list = JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
    if (Array.isArray(list)) list.forEach(b => { if (b?.id && isArchiveId(b.id) && !registry.has(b.id)) registry.set(b.id, b); });
  } catch { /* storage unavailable: memory only */ }
}

function saveStore() {
  // Favourites and reading history are pinned: they are never trimmed away, so a saved
  // Archive book always still has its title / cover / author after the app restarts.
  let pinnedIds;
  try { pinnedIds = new Set([...getFavorites(), ...getHistory()]); } catch { pinnedIds = new Set(); }
  const all = [...registry.values()];
  const pinned = all.filter(b => pinnedIds.has(b.id));
  const recent = all.filter(b => !pinnedIds.has(b.id)).slice(-STORE_LIMIT);
  for (const list of [[...pinned, ...recent], pinned]) {   // second try: pinned only, if storage is full
    try { localStorage.setItem(STORE_KEY, JSON.stringify(list)); return; } catch { /* try smaller */ }
  }
}

export function getArchiveBook(id) {
  if (!isArchiveId(id)) return null;
  loadStore();
  return registry.get(id) || null;
}

function remember(book) {
  loadStore();
  const previous = registry.get(book.id);
  // Keep an already-resolved PDF link when the same item shows up again.
  const merged = previous?.pdfUrl && !book.pdfUrl ? { ...book, pdfUrl: previous.pdfUrl } : book;
  registry.delete(book.id);       // re-insert so the newest are kept when trimming
  registry.set(book.id, merged);
  return merged;
}

const first = v => Array.isArray(v) ? first(v[0]) : v;
const text = v => {
  const x = Array.isArray(v) ? v.filter(Boolean).join("، ") : v;
  return String(x ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
};

export function archiveCoverUrl(identifier) {
  return `https://archive.org/services/img/${encodeURIComponent(identifier)}`;
}

// Some uploads are titled with their file name ("bahar-e-shariat-jild-1"): show it as words.
function readableTitle(raw) {
  if (/^[A-Za-z0-9._-]+$/.test(raw) && /[-_]/.test(raw)) {
    return raw.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim().replace(/\b([a-z])/g, c => c.toUpperCase());
  }
  return raw;
}

function bookFromRecord(identifier, fields = {}) {
  const title = readableTitle(text(fields.title) || identifier);
  const pages = Number(first(fields.imagecount));
  return {
    id: ARCHIVE_PREFIX + identifier,
    title,
    titleEn: title,
    author: text(fields.creator),
    description: text(fields.description).slice(0, 1200),
    classId: "",
    classIds: [],
    bookType: "archive",
    pages: Number.isFinite(pages) && pages > 0 ? pages : null,
    cover: archiveCoverUrl(identifier),
    pdfUrl: "",                       // resolved lazily, see resolveArchivePdf()
    pdfSourceType: "archive",
    driveFileId: "",
    source: { name: "Internet Archive", pageUrl: `https://archive.org/details/${encodeURIComponent(identifier)}` },
    status: "available",
    keywords: [],
    categoryIds: [],
    isArchive: true,
    language: text(fields.language),
    isUrdu: isUrduItem({ language: text(fields.language), title }),
    addedAt: "",
    createdAt: ""
  };
}

async function fetchJson(url, signal) {
  const controller = new AbortController();
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener("abort", () => controller.abort(), { once: true });
  }
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) { const e = new Error(`Archive.org request failed (${res.status})`); e.status = res.status; throw e; }
    return await res.json();
  } catch (error) {
    if (timedOut) throw new Error("Archive.org request timed out");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

const PAGE_ROWS = 30;
const MAX_PAGES = 6;
const FIELDS = ["identifier", "title", "creator", "description", "imagecount", "language", "downloads", "subject", "access-restricted-item"];

let fuzzyOk = true;            // switched off for the session if the server rejects fuzzy (~) syntax

function searchUrl(q, page) {
  const params = new URLSearchParams();
  params.set("q", q);
  FIELDS.forEach(f => params.append("fl[]", f));
  params.set("rows", String(PAGE_ROWS));       // no sort: Archive's own relevance order, re-ranked below
  params.set("page", String(page));
  params.set("output", "json");
  return `${ADVANCED_SEARCH}?${params}`;
}

/**
 * One search = several Archive searches (spellings, Urdu script, any-word, fuzzy) run together,
 * merged without duplicates and re-ranked: see archive-query.js for why.
 */
function createEngine(query) {
  const analysis = analyzeQuery(query);
  const strategies = buildStrategies(analysis, { fuzzyOk }).map(s => ({ ...s, page: 0, done: false, failed: false, total: 0 }));
  const seen = new Set();
  let everSucceeded = false;
  // Visible in chrome://inspect -> Console: what was actually asked of Archive.org (useful when a book is missing).
  try { console.info("[Archive search]", query, strategies.map(x => `${x.id}: ${x.q}`)); } catch { /* no console */ }

  async function runOne(strategy, signal) {
    const json = await fetchJson(searchUrl(strategy.q, strategy.page + 1), signal);
    if (!json || !json.response) { const e = new Error(json?.error || "Bad Archive.org response"); e.status = 400; throw e; }
    return json.response;
  }

  return {
    analysis,
    get hasWork() { return strategies.some(s => !s.done && !s.failed); },
    async next(signal) {
      const active = strategies.filter(s => !s.done && !s.failed);
      if (!active.length) return { books: [], done: true, total: 0, meta: { urduQuery: analysis.urduQuery } };

      const results = await Promise.allSettled(active.map(s => runOne(s, signal)));
      const batch = new Map();   // identifier -> { doc, hits }
      let networkErrors = 0, lastError = null;

      results.forEach((res, i) => {
        const s = active[i];
        if (res.status === "rejected") {
          lastError = res.reason;
          if (res.reason?.status) {                 // the server answered with an error: this search is not usable
            s.failed = true;
            if (s.fuzzy) fuzzyOk = false;
          } else networkErrors += 1;               // no answer (offline / timeout): the next call retries it
          return;
        }
        everSucceeded = true;
        const { docs = [], numFound = 0 } = res.value;
        s.page += 1;
        s.total = Number(numFound) || 0;
        s.done = !docs.length || s.page * PAGE_ROWS >= s.total || s.page >= (s.id === "any" ? 4 : MAX_PAGES);
        for (const doc of docs) {
          if (!doc?.identifier || seen.has(doc.identifier)) continue;
          const entry = batch.get(doc.identifier) || { doc, hits: new Set() };
          entry.hits.add(s.id);
          batch.set(doc.identifier, entry);
        }
      });

      if (networkErrors === active.length && !everSucceeded) throw lastError || new Error("Archive.org request failed");
      if (!everSucceeded && strategies.every(s => s.failed)) throw lastError || new Error("Archive.org search failed");

      const ranked = [...batch.values()]
        .map(e => ({ ...e, score: scoreItem(e.doc, analysis, e.hits) }))
        .sort((a, b) => b.score - a.score);
      const books = ranked.map(e => {
        seen.add(e.doc.identifier);
        const book = bookFromRecord(e.doc.identifier, e.doc);
        book.archiveScore = Math.round(e.score);
        return remember(book);
      });
      saveStore();
      const total = Math.max(0, ...strategies.filter(s => s.id !== "any").map(s => s.total));
      return { books, done: !strategies.some(s => !s.done && !s.failed), total, meta: { urduQuery: analysis.urduQuery } };
    }
  };
}

let current = null;   // { query, engine }

/**
 * Next page of Archive.org results for `query` (page 1 starts a fresh search).
 * Resolves to { books, done, total, meta }. Books are ranked best-first inside each page.
 */
export async function searchArchive(query, { page = 1, signal } = {}) {
  const trimmed = String(query || "").trim();
  if (!analyzeQuery(trimmed).core.length) return { books: [], done: true, total: 0, meta: {} };
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    const error = new Error("Offline");
    error.code = "OFFLINE";
    throw error;
  }
  if (page === 1 || !current || current.query !== trimmed) current = { query: trimmed, engine: createEngine(trimmed) };
  return current.engine.next(signal);
}

/** Loads one item's details by identifier (used when a deep link / favourite is opened after a restart). */
export async function hydrateArchiveBook(id) {
  const existing = getArchiveBook(id);
  if (existing) return existing;
  if (!isArchiveId(id)) return null;
  const identifier = archiveIdentifier(id);
  const json = await fetchJson(`${METADATA}${encodeURIComponent(identifier)}`);
  if (!json?.metadata) return null;
  const book = remember(bookFromRecord(identifier, { ...json.metadata, imagecount: json.metadata.imagecount }));
  saveStore();
  return book;
}

function pickPdf(files = []) {
  const pdfs = files.filter(f => /\.pdf$/i.test(f?.name || "") && !/^__ia_thumb/i.test(f.name));
  if (!pdfs.length) return null;
  const score = f => {
    let s = 0;
    const format = String(f.format || "");
    if (/text pdf/i.test(format)) s += 4;          // searchable, usually smaller
    else if (/image container pdf/i.test(format)) s += 3;
    if (!/_text\.pdf$/i.test(f.name)) s += 2;      // "_text.pdf" is just an OCR dump
    if (!/\//.test(f.name)) s += 1;                // top-level file
    return s;
  };
  return pdfs.slice().sort((a, b) => score(b) - score(a) || (Number(b.size) || 0) - (Number(a.size) || 0))[0];
}

/**
 * Finds the direct PDF address of an archive book and stores it on the book (book.pdfUrl),
 * so the normal download flow can use it. Resolves to the URL, or null if the item has no PDF.
 */
export async function resolveArchivePdf(book) {
  if (!book?.isArchive) return book?.pdfUrl || null;
  if (book.pdfUrl) return book.pdfUrl;
  const identifier = archiveIdentifier(book.id);
  const json = await fetchJson(`${METADATA}${encodeURIComponent(identifier)}`);
  const file = pickPdf(json?.files);
  if (!file) return null;
  const path = String(file.name).split("/").map(encodeURIComponent).join("/");
  book.pdfUrl = `https://archive.org/download/${encodeURIComponent(identifier)}/${path}`;
  if (!book.pages && json?.metadata?.imagecount) book.pages = Number(json.metadata.imagecount) || null;
  remember(book);
  saveStore();
  return book.pdfUrl;
}
