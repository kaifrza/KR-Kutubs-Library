/* Splash controller (classic script, runs before the app module).
   Keeps the splash up until the first real screen is on screen, but never shorter than MIN_MS
   AFTER the splash was first painted (so the whole entrance animation can play, and it feels
   intentional rather than a flicker), and never longer than MAX_MS (safety net). */
(function () {
  var MIN_MS = 1300, MAX_MS = 7000;
  var el = document.getElementById("kr-splash");
  if (!el) return;
  var hidden = false, paintedAt = 0, scheduled = false, observer = null;

  function now() { return window.performance && performance.now ? performance.now() : 0; }

  function hide() {
    if (hidden) return;
    hidden = true;
    if (observer) observer.disconnect();
    el.classList.add("is-leaving");
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 460);
  }

  function schedule() { setTimeout(hide, Math.max(0, paintedAt + MIN_MS - now())); }

  // Remember when the splash actually reached the screen (two frames after this script ran).
  if (window.requestAnimationFrame) {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { paintedAt = now(); if (scheduled) schedule(); });
    });
  } else { paintedAt = now(); }

  // "Ready" = the boot skeleton is gone and the app has drawn something.
  var app = document.getElementById("app");
  function appReady() { return app && app.children.length > 0 && !document.querySelector(".boot"); }
  function check() {
    if (scheduled || !appReady()) return;
    scheduled = true;
    if (paintedAt) schedule();
  }
  if (app && window.MutationObserver) {
    observer = new MutationObserver(check);
    observer.observe(app, { childList: true, subtree: true });
  }
  check();
  setTimeout(hide, MAX_MS);
})();
