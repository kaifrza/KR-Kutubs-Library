// Picks a cover address for a book whose backend record has NO cover set.
//
//   1. Archive.org book  -> the item's own thumbnail (the PDF's first page), same as in Archive search results.
//   2. Google Drive book -> Drive's thumbnail of the file (works for publicly shared files).
//   3. otherwise         -> "" (the app's typeset cover is shown).
//
// A cover that IS set in the backend always wins; this is only the fallback for an empty one.
// The typeset cover stays underneath while the image loads and when it fails, see utils/cover.js.

export function archiveIdFromUrl(url) {
  try {
    const u = new URL(url);
    if (!/(^|\.)archive\.org$/i.test(u.hostname)) return null;
    const parts = u.pathname.split('/').filter(Boolean);
    for (const marker of ['download', 'details', 'embed']) {
      const i = parts.indexOf(marker);
      if (i >= 0 && parts[i + 1]) return decodeURIComponent(parts[i + 1]);
    }
  } catch { /* not a URL */ }
  return null;
}

function driveIdFromUrl(url) {
  try {
    const u = new URL(url);
    if (!/(^|\.)drive\.google\.com$/i.test(u.hostname)) return null;
    return u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i)?.[1] || null;
  } catch { return null; }
}

export function deriveCoverUrl(book) {
  if (!book) return '';
  if (book.cover) return book.cover;
  const urls = [book.source?.pageUrl, book.pdfUrl];
  for (const url of urls) {
    const id = archiveIdFromUrl(url);
    if (id) return `https://archive.org/services/img/${encodeURIComponent(id)}`;
  }
  const driveId = String(book.driveFileId || '').trim() || urls.map(driveIdFromUrl).find(Boolean);
  if (driveId) return `https://drive.google.com/thumbnail?id=${encodeURIComponent(driveId)}&sz=w480`;
  return '';
}
