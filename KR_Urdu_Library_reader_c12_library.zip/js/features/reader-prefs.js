// Small local stores for the in-app reader: look & feel, bookmarks, exact reading position.
const PREFS_KEY = "krl_reader_prefs_v1";
const MARKS_KEY = "krl_reader_marks_v1";
const POS_KEY = "krl_reader_pos_v1";

const DEFAULTS = { theme: "paper", dim: 0, keepAwake: false, autoHide: true };
const THEMES = ["paper", "sepia", "night"];

function read(key, fallback){
  try{
    const v = JSON.parse(localStorage.getItem(key) || "null");
    return v && typeof v === "object" ? v : fallback;
  }catch{ return fallback; }
}
function write(key, value){
  try{ localStorage.setItem(key, JSON.stringify(value)); }catch{}
}

export function getReaderPrefs(){
  const p = { ...DEFAULTS, ...read(PREFS_KEY, {}) };
  if(!THEMES.includes(p.theme)) p.theme = DEFAULTS.theme;
  p.dim = Math.min(.7, Math.max(0, Number(p.dim) || 0));
  p.keepAwake = Boolean(p.keepAwake);
  p.autoHide = p.autoHide !== false;
  return p;
}
export function saveReaderPrefs(patch){
  const next = { ...getReaderPrefs(), ...patch };
  write(PREFS_KEY, next);
  return next;
}

export function getBookmarks(key){
  const all = read(MARKS_KEY, {});
  const list = Array.isArray(all[key]) ? all[key] : [];
  return list.filter(n => Number.isInteger(n) && n > 0).sort((a, b) => a - b);
}
export function toggleBookmark(key, page){
  const all = read(MARKS_KEY, {});
  const list = new Set(Array.isArray(all[key]) ? all[key] : []);
  let added;
  if(list.has(page)){ list.delete(page); added = false; }
  else{ list.add(page); added = true; }
  all[key] = Array.from(list).sort((a, b) => a - b);
  if(!all[key].length) delete all[key];
  write(MARKS_KEY, all);
  return added;
}

export function getReadingPosition(key){
  const all = read(POS_KEY, {});
  const v = all[key];
  if(!v || !Number.isInteger(v.p) || v.p < 1) return null;
  return { page: v.p, frac: Math.min(1, Math.max(0, Number(v.f) || 0)) };
}
export function saveReadingPosition(key, page, frac){
  const all = read(POS_KEY, {});
  all[key] = { p: page, f: Math.round(frac * 1000) / 1000 };
  const keys = Object.keys(all);
  if(keys.length > 400) delete all[keys[0]];
  write(POS_KEY, all);
}
