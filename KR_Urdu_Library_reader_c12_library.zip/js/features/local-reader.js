// Premium in-app PDF reader for files that live on the phone (Downloads / "Open with" / device scan).
// Continuous vertical scrolling; only pages near the screen are rendered, so big books stay fast.
import { escapeHTML } from "../utils/helpers.js";
import { getBookProgress, setProgress } from "../utils/storage.js";
import { loadPdfJs } from "./pdfjs-loader.js";
import { openNativeFile, loadLocalPdf, nativeReaderAvailable } from "./local-file.js";
import { getNativePlugin } from "./download-manager.js";
import {
  getReaderPrefs, saveReaderPrefs, getBookmarks, toggleBookmark, getReadingPosition, saveReadingPosition
} from "./reader-prefs.js";

const PAD = 8;          // side padding (css px)
const GAP = 12;         // space between pages
const TOP_PAD = 76;     // room under the floating top bar for the first page
const BOTTOM_PAD = 110; // room above the floating bottom bar for the last page
const MIN_ZOOM = .6, MAX_ZOOM = 4;

let activeCleanup = null;

export function cleanupLocalReader(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

const ICONS = {
  back: '<path d="M15 5l-7 7 7 7"/>',
  backRtl: '<path d="M9 5l7 7-7 7"/>',
  bookmark: '<path d="M7 4.5h10a1 1 0 0 1 1 1V20l-6-3.8L6 20V5.5a1 1 0 0 1 1-1z"/>',
  list: '<path d="M8.5 6.5H20M8.5 12H20M8.5 17.5H20"/><circle cx="4.5" cy="6.5" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="17.5" r="1"/>',
  up: '<path d="M6 14l6-6 6 6"/>',
  down: '<path d="M6 10l6 6 6-6"/>',
  text: '<path d="M4 18 9.5 5.5 15 18M6.2 13.5h6.6"/><path d="M17 18l2.8-6.4L22 18M17.9 16h3.8"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M18.5 5.5l-1.7 1.7M7.2 16.8l-1.7 1.7"/>',
  moon: '<path d="M20 14.2A8.2 8.2 0 0 1 9.8 4 8.2 8.2 0 1 0 20 14.2z"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  warn: '<path d="M12 4 3 19.5h18z"/><path d="M12 10v4.5M12 17.2h.01"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  trash: '<path d="M5 7h14M10 7V4.8h4V7M7 7l.8 12.2h8.4L17 7"/>'
};
const svg = (name, cls = "") => `<svg class="lr-i ${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[name] || ""}</svg>`;

export function renderLocalReader(app, { lang = "en", title = "PDF", subtitle = "", source, progressKey }){
  cleanupLocalReader();
  const ur = lang === "ur";
  const L = ur ? {
    back:"واپس", marks:"بُک مارک", marksAdd:"اس صفحے پر بُک مارک لگائیں", contents:"فہرست", navigate:"رہنمائی", look:"پڑھنے کا انداز",
    paper:"سفید", sepia:"سیپیا", night:"رات", brightness:"روشنی", keepAwake:"اسکرین چالو رکھیں", autoHide:"پڑھتے ہوئے بارز چھپائیں",
    zoom:"زوم", fit:"چوڑائی کے مطابق", jump:"صفحہ پر جائیں", page:"صفحہ", of:"از", go:"جائیں", close:"بند کریں",
    invalid:"درست صفحہ نمبر درج کریں۔", loading:"کتاب کھل رہی ہے…", failed:"یہ فائل نہیں کھل سکی۔",
    hint:"ممکن ہے فائل ہٹا دی گئی ہو یا کسی اور جگہ منتقل ہوگئی ہو۔", retry:"دوبارہ کوشش کریں",
    androidOnly:"یہ فیچر صرف اینڈرائیڈ ایپ میں دستیاب ہے۔", noContents:"اس کتاب میں فہرست موجود نہیں۔",
    noMarks:"ابھی کوئی بُک مارک نہیں۔", added:"بُک مارک لگ گیا", removed:"بُک مارک ہٹ گیا", resumed:"جہاں چھوڑا تھا وہیں سے", pages:"صفحات",
    left:"باقی", info:"فائل کی معلومات", delete:"ہٹائیں"
  } : {
    back:"Back", marks:"Bookmarks", marksAdd:"Bookmark this page", contents:"Contents", navigate:"Navigate", look:"Reading look",
    paper:"Paper", sepia:"Sepia", night:"Night", brightness:"Brightness", keepAwake:"Keep screen on", autoHide:"Hide bars while reading",
    zoom:"Zoom", fit:"Fit to width", jump:"Jump to page", page:"Page", of:"of", go:"Go", close:"Close",
    invalid:"Enter a valid page number.", loading:"Opening book…", failed:"This file could not be opened.",
    hint:"It may have been moved or deleted.", retry:"Try again",
    androidOnly:"This feature is only available in the Android app.", noContents:"This book has no table of contents.",
    noMarks:"No bookmarks yet.", added:"Bookmark added", removed:"Bookmark removed", resumed:"Resumed where you left off", pages:"pages",
    left:"left", info:"File info", delete:"Remove"
  };

  const plugin = getNativePlugin();
  const key = progressKey || "";
  const saved = key ? getBookProgress(key) : null;
  const savedPos = key ? getReadingPosition(key) : null;
  const startPage = savedPos?.page || Math.max(1, Number(saved?.page) || 1);
  const startFrac = savedPos?.frac || 0;
  let prefs = getReaderPrefs();

  let pdf = null, task = null, file = null;
  let numPages = 0, zoom = 1, currentPage = startPage, outline = null;
  let ratios = [], tops = [], heights = [];
  let W = 0, containerW = 0, totalH = 0, layoutVersion = 0;
  const wrappers = new Map();
  let pumping = false, destroyed = false, barsHidden = false, sliding = false, lastScroll = 0;
  let marks = key ? getBookmarks(key) : [];
  let rafId = 0, saveTimer = null, pillTimer = null, resizeTimer = null, tapTimer = null, toastTimer = null;

  app.innerHTML = `<main class="lr-shell" data-rtheme="${prefs.theme}" aria-label="${escapeHTML(title)}">
    <div class="lr-progress" aria-hidden="true"><span id="lrProg"></span></div>
    <header class="lr-top">
      <button class="lr-btn" id="lrBack" type="button" aria-label="${L.back}">${svg(ur ? "backRtl" : "back")}</button>
      <div class="lr-title"><strong>${escapeHTML(title)}</strong><small id="lrSub">${escapeHTML(subtitle)}</small></div>
      <button class="lr-btn" id="lrMark" type="button" aria-label="${L.marksAdd}" aria-pressed="false">${svg("bookmark")}</button>
      <button class="lr-btn" id="lrSettings" type="button" aria-label="${L.look}">${svg("text")}</button>
    </header>
    <section class="lr-body" id="lrBody" tabindex="0" aria-label="${escapeHTML(title)}" aria-busy="true">
      <div class="lr-loading" id="lrLoading"><div class="lr-skel"><i></i><i></i><i></i><i></i></div><span>${L.loading}</span></div>
      <div class="lr-pages" id="lrPages"></div>
    </section>
    <div class="lr-pill" id="lrPill" hidden></div>
    <div class="lr-toast" id="lrToast" hidden role="status"></div>
    <div class="lr-dim" id="lrDim" aria-hidden="true"></div>
    <footer class="lr-bottom">
      <div class="lr-scrub">
        <span id="lrCur">—</span>
        <input class="lr-slider" id="lrSlider" type="range" min="1" max="1" value="1" step="1" disabled aria-label="${L.jump}">
        <span id="lrLeft"></span>
      </div>
      <div class="lr-actions">
        <button class="lr-btn" id="lrNav" type="button" aria-label="${L.navigate}">${svg("list")}</button>
        <button class="lr-btn" id="lrPrev" type="button" disabled aria-label="Previous page">${svg("up")}</button>
        <button class="lr-page-btn" id="lrPageBtn" type="button" aria-label="${L.jump}">—</button>
        <button class="lr-btn" id="lrNext" type="button" disabled aria-label="Next page">${svg("down")}</button>
        <button class="lr-btn" id="lrTheme" type="button" aria-label="${L.look}">${svg(prefs.theme === "night" ? "moon" : "sun")}</button>
      </div>
    </footer>
    <div class="lr-sheet-wrap" id="lrSheetWrap" hidden></div>
  </main>`;

  const $ = s => app.querySelector(s);
  const shellEl = $(".lr-shell"), body = $("#lrBody"), loading = $("#lrLoading"), pagesEl = $("#lrPages");
  const pill = $("#lrPill"), toastEl = $("#lrToast"), dimEl = $("#lrDim"), progEl = $("#lrProg");
  const slider = $("#lrSlider"), prevBtn = $("#lrPrev"), nextBtn = $("#lrNext"), pageBtn = $("#lrPageBtn");
  const curEl = $("#lrCur"), leftEl = $("#lrLeft"), subEl = $("#lrSub"), markBtn = $("#lrMark"), themeBtn = $("#lrTheme");
  const sheetWrap = $("#lrSheetWrap");

  // ---------------- native helpers (never fatal) ----------------
  const native = (method, opts) => { try{ Promise.resolve(plugin?.[method]?.(opts)).catch(() => {}); }catch{} };
  const applyKeepAwake = () => native("setKeepScreenOn", { on: prefs.keepAwake });
  const applyImmersive = on => native("setImmersive", { on });

  // ---------------- small helpers ----------------
  const clampPage = n => Math.min(numPages || 1, Math.max(1, n));
  const fmtBytes = n => n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;

  function applyLook(){
    shellEl.dataset.rtheme = prefs.theme;
    dimEl.style.opacity = String(prefs.dim);
    themeBtn.innerHTML = svg(prefs.theme === "night" ? "moon" : "sun");
  }
  applyLook();

  function indexAt(y){
    let lo = 0, hi = numPages - 1;
    while(lo < hi){
      const mid = (lo + hi + 1) >> 1;
      if(tops[mid] <= y) lo = mid; else hi = mid - 1;
    }
    return lo;
  }

  function showPill(text){
    if(!numPages) return;
    pill.textContent = text || `${currentPage} / ${numPages}`;
    pill.hidden = false;
    clearTimeout(pillTimer);
    pillTimer = setTimeout(() => { pill.hidden = true; }, 1200);
  }
  function toast(text){
    toastEl.textContent = text;
    toastEl.hidden = false;
    toastEl.classList.remove("show");
    void toastEl.offsetWidth;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.hidden = true; }, 1900);
  }

  function updateMarkButton(){
    const on = marks.includes(currentPage);
    markBtn.classList.toggle("is-on", on);
    markBtn.setAttribute("aria-pressed", String(on));
  }

  function setCurrent(n){
    currentPage = clampPage(n);
    const pct = Math.round(currentPage / numPages * 100);
    curEl.textContent = `${currentPage}`;
    pageBtn.textContent = `${currentPage} / ${numPages}`;
    leftEl.textContent = `${numPages - currentPage} ${L.left}`;
    subEl.textContent = `${pct}%${subtitle ? " · " + subtitle : ""}`;
    if(!sliding) slider.value = String(currentPage);
    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= numPages;
    updateMarkButton();
  }

  function currentFraction(){
    if(!numPages) return 0;
    const y = body.scrollTop + body.clientHeight * .35;
    const i = indexAt(y);
    return Math.min(1, Math.max(0, (y - tops[i]) / Math.max(1, heights[i])));
  }
  function saveProgress(){
    if(!numPages || !key) return;
    setProgress(key, { page: currentPage, totalPages: numPages, percent: Math.round(currentPage / numPages * 100) });
    saveReadingPosition(key, currentPage, currentFraction());
  }

  // ---------------- layout ----------------
  function positionWrapper(el, i){
    el.style.top = `${tops[i]}px`;
    el.style.left = `${Math.round((containerW - W) / 2)}px`;
    el.style.width = `${W}px`;
    el.style.height = `${heights[i]}px`;
  }

  function layout(){
    const vw = body.clientWidth || 360;
    W = Math.max(120, Math.round((vw - PAD * 2) * zoom));
    containerW = Math.max(vw, W + PAD * 2);
    let y = TOP_PAD;
    for(let i = 0; i < numPages; i++){
      const h = Math.round(W * ratios[i]);
      heights[i] = h; tops[i] = y; y += h + GAP;
    }
    totalH = y - GAP + BOTTOM_PAD;
    pagesEl.style.width = `${containerW}px`;
    pagesEl.style.height = `${totalH}px`;
    layoutVersion++;
  }

  function applyRatio(i, r){
    const oldH = heights[i];
    ratios[i] = r;
    const newH = Math.round(W * r);
    const delta = newH - oldH;
    if(!delta) return;
    const before = body.scrollTop;
    heights[i] = newH;
    for(let k = i + 1; k < numPages; k++) tops[k] += delta;
    totalH += delta;
    pagesEl.style.height = `${totalH}px`;
    for(const [k, w] of wrappers){
      if(k === i) w.el.style.height = `${newH}px`;
      else if(k > i) w.el.style.top = `${tops[k]}px`;
    }
    if(tops[i] + oldH <= before) body.scrollTop = before + delta;
  }

  // ---------------- virtual window ----------------
  function dispose(i){
    const w = wrappers.get(i);
    if(!w) return;
    if(w.task){ try{ w.task.cancel(); }catch{} }
    const c = w.el.querySelector("canvas");
    if(c){ c.width = 0; c.height = 0; }
    w.el.remove();
    wrappers.delete(i);
  }
  function clearWrappers(){ for(const i of Array.from(wrappers.keys())) dispose(i); }

  function createWrapper(i){
    const el = document.createElement("div");
    el.className = "lr-page";
    el.dataset.page = String(i + 1);
    el.innerHTML = `<div class="lr-ph"><i></i></div>`;
    positionWrapper(el, i);
    pagesEl.appendChild(el);
    wrappers.set(i, { el, rendered: false, task: null });
  }

  function update(){
    if(!pdf || !numPages || destroyed) return;
    const st = body.scrollTop, vh = body.clientHeight, m = vh * 1.2;
    const a = indexAt(Math.max(0, st - m)), b = indexAt(st + vh + m);
    for(const i of Array.from(wrappers.keys())) if(i < a || i > b) dispose(i);
    for(let i = a; i <= b; i++) if(!wrappers.has(i)) createWrapper(i);
    setCurrent(indexAt(st + vh * .35) + 1);
    const span = Math.max(1, totalH - vh);
    progEl.style.transform = `scaleX(${Math.min(1, Math.max(0, st / span))})`;
    pump();
  }

  function nextToRender(){
    const center = body.scrollTop + body.clientHeight / 2;
    let best = -1, bestD = Infinity;
    for(const [i, w] of wrappers){
      if(w.rendered) continue;
      const d = Math.abs(tops[i] + heights[i] / 2 - center);
      if(d < bestD){ bestD = d; best = i; }
    }
    return best;
  }

  async function pump(){
    if(pumping) return;
    pumping = true;
    try{
      while(!destroyed){
        const idx = nextToRender();
        if(idx < 0) break;
        await renderIndex(idx);
      }
    }finally{
      pumping = false;
    }
  }

  async function renderIndex(i){
    const w = wrappers.get(i);
    if(!w) return;
    const ver = layoutVersion;
    let page;
    try{
      page = await pdf.getPage(i + 1);
    }catch{
      w.rendered = true;
      return;
    }
    if(destroyed || wrappers.get(i) !== w || ver !== layoutVersion){
      try{ page.cleanup?.(); }catch{}
      return;
    }
    try{
      const base = page.getViewport({ scale: 1 });
      const ratio = base.height / base.width;
      if(Math.abs(ratio - ratios[i]) > .004) applyRatio(i, ratio);
      const cssW = W, cssH = heights[i];
      const viewport = page.getViewport({ scale: cssW / base.width });
      let dpr = Math.min(2.5, window.devicePixelRatio || 1);
      if(cssW * cssH * dpr * dpr > 16000000) dpr = Math.max(1, Math.sqrt(16000000 / (cssW * cssH)));
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil(viewport.width * dpr);
      canvas.height = Math.ceil(viewport.height * dpr);
      const ctx = canvas.getContext("2d", { alpha: false });
      const rt = page.render({ canvasContext: ctx, viewport, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
      w.task = rt;
      await rt.promise;
      w.task = null;
      if(!destroyed && wrappers.get(i) === w && ver === layoutVersion){
        w.el.querySelector("canvas")?.remove();
        w.el.appendChild(canvas);
        requestAnimationFrame(() => w.el.classList.add("is-ready"));
        w.rendered = true;
      }
    }catch(err){
      w.task = null;
      if(err?.name === "RenderingCancelledException") return;
      w.rendered = true;
      console.warn("Page render failed", i + 1, err);
    }finally{
      try{ page.cleanup?.(); }catch{}
    }
  }

  // ---------------- navigation & zoom ----------------
  function goTo(n, smooth, frac = 0){
    if(!numPages) return;
    const i = clampPage(n) - 1;
    const top = Math.max(0, tops[i] - (i === 0 ? TOP_PAD : GAP) + frac * heights[i]);
    if(smooth) body.scrollTo({ top, behavior: "smooth" });
    else{ body.scrollTop = top; update(); }
  }

  // Keep the content under (fx, fy) still while the layout changes size.
  function captureAnchor(fx, fy){
    const r = body.getBoundingClientRect();
    const oy = fy - r.top, ox = fx - r.left;
    const cy = body.scrollTop + oy;
    const i = indexAt(cy);
    return { i, frac: (cy - tops[i]) / Math.max(1, heights[i]), x: (body.scrollLeft + ox) / Math.max(1, containerW), oy, ox };
  }
  function restoreAnchor(a){
    body.scrollTop = Math.max(0, tops[a.i] + a.frac * heights[a.i] - a.oy);
    body.scrollLeft = Math.max(0, a.x * containerW - a.ox);
  }
  function centerPoint(){
    const r = body.getBoundingClientRect();
    return [r.left + r.width / 2, r.top + r.height / 2];
  }
  function relayout(focus){
    if(!pdf) return;
    const [fx, fy] = focus || centerPoint();
    const a = captureAnchor(fx, fy);
    clearWrappers();
    layout();
    restoreAnchor(a);
    update();
  }
  function setZoom(z, focus){
    z = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(z * 100) / 100));
    if(!pdf || z === zoom) return;
    zoom = z;
    relayout(focus);
    showPill(`${Math.round(zoom * 100)}%`);
  }

  // ---------------- bars (auto-hide, immersive) ----------------
  function setBars(visible){
    const hide = !visible;
    if(hide === barsHidden) return;
    barsHidden = hide;
    shellEl.classList.toggle("bars-hidden", hide);
    applyImmersive(hide);
  }

  // ---------------- error / loading ----------------
  const showError = err => {
    body.setAttribute("aria-busy", "false");
    pagesEl.hidden = true;
    loading.hidden = false;
    const friendly = err?.friendly ? err.message : L.failed;
    loading.innerHTML = `<div class="lr-error">${svg("warn")}<strong>${escapeHTML(friendly)}</strong>
      ${err?.friendly ? "" : `<p>${L.hint}</p><button class="lr-cta" id="lrRetry" type="button">${L.retry}</button>`}</div>`;
    $("#lrRetry")?.addEventListener("click", () => {
      loading.innerHTML = `<div class="lr-skel"><i></i><i></i><i></i><i></i></div><span>${L.loading}</span>`;
      pagesEl.hidden = false;
      load();
    });
    console.warn("Local reader error:", err);
  };

  async function loadOutline(){
    try{
      const raw = await pdf.getOutline();
      if(!raw || !raw.length) return;
      const flat = [];
      const walk = (items, depth) => items.forEach(it => {
        if(flat.length > 400) return;
        flat.push({ title: String(it.title || "").trim() || "—", dest: it.dest, depth });
        if(it.items?.length && depth < 3) walk(it.items, depth + 1);
      });
      walk(raw, 0);
      outline = flat;
    }catch{ outline = null; }
  }

  async function resolveDest(dest){
    try{
      const d = typeof dest === "string" ? await pdf.getDestination(dest) : dest;
      if(!Array.isArray(d)) return null;
      const ref = d[0];
      if(Number.isInteger(ref)) return ref + 1;
      return (await pdf.getPageIndex(ref)) + 1;
    }catch{ return null; }
  }

  async function load(){
    try{
      if(!nativeReaderAvailable()) throw Object.assign(new Error(L.androidOnly), { friendly: true });
      const pdfjs = await loadPdfJs();
      if(destroyed) return;
      file = await openNativeFile(source);
      if(destroyed){ file.close(); return; }
      const result = await loadLocalPdf(pdfjs, file);
      if(destroyed){ try{ result.task.destroy(); }catch{} return; }
      pdf = result.pdf; task = result.task; numPages = pdf.numPages;
      const first = await pdf.getPage(1);
      const v = first.getViewport({ scale: 1 });
      try{ first.cleanup?.(); }catch{}
      ratios = new Array(numPages).fill(v.height / v.width);
      slider.max = String(numPages); slider.disabled = false;
      loading.hidden = true;
      body.setAttribute("aria-busy", "false");
      layout();
      goTo(clampPage(startPage), false, startPage > 1 || startFrac > 0 ? startFrac : 0);
      if(startPage > 1) toast(L.resumed);
      applyKeepAwake();
      loadOutline();
    }catch(err){
      if(!destroyed) showError(err);
    }
  }

  // ---------------- sheets ----------------
  function closeSheet(){
    sheetWrap.classList.remove("open");
    setTimeout(() => { if(!sheetWrap.classList.contains("open")){ sheetWrap.hidden = true; sheetWrap.innerHTML = ""; } }, 260);
  }
  function openSheet(inner, onMount){
    sheetWrap.innerHTML = `<div class="lr-backdrop" data-close></div><section class="lr-sheet" role="dialog" aria-modal="true"><div class="lr-grab" aria-hidden="true"></div>${inner}</section>`;
    sheetWrap.hidden = false;
    requestAnimationFrame(() => sheetWrap.classList.add("open"));
    sheetWrap.querySelector("[data-close]").onclick = closeSheet;
    sheetWrap.querySelectorAll("[data-dismiss]").forEach(b => b.onclick = closeSheet);
    // drag the handle area down to dismiss
    const sheet = sheetWrap.querySelector(".lr-sheet");
    let y0 = 0, dy = 0;
    sheet.addEventListener("touchstart", e => { y0 = (sheet.scrollTop <= 0 && e.target.closest(".lr-grab, .lr-sheet-head")) ? e.touches[0].clientY : 0; dy = 0; }, { passive: true });
    sheet.addEventListener("touchmove", e => { if(!y0) return; dy = Math.max(0, e.touches[0].clientY - y0); sheet.style.transform = `translateY(${dy}px)`; sheet.style.transition = "none"; }, { passive: true });
    sheet.addEventListener("touchend", () => { sheet.style.transition = ""; sheet.style.transform = ""; if(y0 && dy > 90) closeSheet(); y0 = 0; });
    onMount?.(sheet);
  }

  function openSettings(){
    const sw = (v, label) => `<button type="button" class="lr-theme ${prefs.theme === v ? "on" : ""}" data-theme="${v}" aria-pressed="${prefs.theme === v}"><span class="lr-swatch s-${v}"></span><em>${label}</em></button>`;
    openSheet(`<div class="lr-sheet-head"><h2>${L.look}</h2><button class="lr-btn" data-dismiss type="button" aria-label="${L.close}">${svg("close")}</button></div>
      <div class="lr-themes">${sw("paper", L.paper)}${sw("sepia", L.sepia)}${sw("night", L.night)}</div>
      <label class="lr-row"><span>${L.brightness}</span><input class="lr-slider" id="lrBright" type="range" min="30" max="100" step="1" value="${Math.round((1 - prefs.dim) * 100)}"></label>
      <div class="lr-row"><span>${L.zoom}</span>
        <div class="lr-stepper"><button type="button" class="lr-btn" id="lrZm" aria-label="${L.zoom} −">${svg("minus")}</button><b id="lrZv">${Math.round(zoom * 100)}%</b><button type="button" class="lr-btn" id="lrZp" aria-label="${L.zoom} +">${svg("plus")}</button><button type="button" class="lr-chip" id="lrZf">${L.fit}</button></div></div>
      <button type="button" class="lr-row lr-switch" id="lrAwake" role="switch" aria-checked="${prefs.keepAwake}"><span>${L.keepAwake}</span><i></i></button>
      <button type="button" class="lr-row lr-switch" id="lrAuto" role="switch" aria-checked="${prefs.autoHide}"><span>${L.autoHide}</span><i></i></button>
      <p class="lr-info">${L.info}: ${numPages} ${L.pages}${file ? " · " + fmtBytes(file.size) : ""}</p>`, sheet => {
      sheet.querySelectorAll("[data-theme]").forEach(b => b.onclick = () => {
        prefs = saveReaderPrefs({ theme: b.dataset.theme }); applyLook();
        sheet.querySelectorAll("[data-theme]").forEach(x => { const on = x === b; x.classList.toggle("on", on); x.setAttribute("aria-pressed", String(on)); });
      });
      sheet.querySelector("#lrBright").oninput = e => {
        const v = Number(e.target.value);
        prefs = saveReaderPrefs({ dim: Math.min(.7, Math.max(0, (100 - v) / 100)) }); applyLook();
      };
      const zv = sheet.querySelector("#lrZv");
      const bump = z => { setZoom(z); zv.textContent = `${Math.round(zoom * 100)}%`; };
      sheet.querySelector("#lrZm").onclick = () => bump(zoom - .25);
      sheet.querySelector("#lrZp").onclick = () => bump(zoom + .25);
      sheet.querySelector("#lrZf").onclick = () => bump(1);
      const flip = (id, name, after) => {
        const el = sheet.querySelector(id);
        el.onclick = () => { const on = el.getAttribute("aria-checked") !== "true"; el.setAttribute("aria-checked", String(on)); prefs = saveReaderPrefs({ [name]: on }); after?.(on); };
      };
      flip("#lrAwake", "keepAwake", applyKeepAwake);
      flip("#lrAuto", "autoHide", on => { if(!on) setBars(true); });
    });
  }

  function openNavigate(startTab){
    const renderTab = tab => {
      const contentsList = outline?.length
        ? `<ul class="lr-list">${outline.map((it, n) => `<li><button type="button" data-ci="${n}" style="--d:${it.depth}"><span>${escapeHTML(it.title)}</span></button></li>`).join("")}</ul>`
        : `<p class="lr-empty">${L.noContents}</p>`;
      const marksList = marks.length
        ? `<ul class="lr-list">${marks.map(p => `<li class="lr-markrow"><button type="button" data-mp="${p}">${svg("bookmark", "on")}<span>${L.page} ${p}</span></button><button type="button" class="lr-btn" data-md="${p}" aria-label="${L.delete}">${svg("trash")}</button></li>`).join("")}</ul>`
        : `<div class="lr-empty"><p>${L.noMarks}</p><button type="button" class="lr-cta" id="lrAddMark">${L.marksAdd}</button></div>`;
      return `<div class="lr-sheet-head"><h2>${L.navigate}</h2><button class="lr-btn" data-dismiss type="button" aria-label="${L.close}">${svg("close")}</button></div>
        <div class="lr-tabs" role="tablist"><button type="button" role="tab" data-tab="contents" aria-selected="${tab === "contents"}">${L.contents}</button><button type="button" role="tab" data-tab="marks" aria-selected="${tab === "marks"}">${L.marks}${marks.length ? ` · ${marks.length}` : ""}</button></div>
        <div class="lr-tabbody">${tab === "contents" ? contentsList : marksList}</div>`;
    };
    const redraw = (sheet, tab) => {
      sheet.innerHTML = `<div class="lr-grab" aria-hidden="true"></div>${renderTab(tab)}`;
      sheet.querySelectorAll("[data-dismiss]").forEach(x => x.onclick = closeSheet);
      mount(sheet);
    };
    const mount = sheet => {
      sheet.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => redraw(sheet, b.dataset.tab));
      sheet.querySelectorAll("[data-ci]").forEach(b => b.onclick = async () => {
        const it = outline[Number(b.dataset.ci)];
        const page = await resolveDest(it.dest);
        closeSheet();
        if(page) goTo(page, false);
      });
      sheet.querySelectorAll("[data-mp]").forEach(b => b.onclick = () => { closeSheet(); goTo(Number(b.dataset.mp), false); });
      sheet.querySelectorAll("[data-md]").forEach(b => b.onclick = () => {
        toggleBookmark(key, Number(b.dataset.md)); marks = getBookmarks(key); updateMarkButton();
        redraw(sheet, "marks");
      });
      sheet.querySelector("#lrAddMark")?.addEventListener("click", () => {
        toggleBookmark(key, currentPage); marks = getBookmarks(key); updateMarkButton(); toast(L.added);
        redraw(sheet, "marks");
      });
    };
    openSheet(renderTab(startTab), mount);
  }

  function openJump(){
    openSheet(`<div class="lr-sheet-head"><h2>${L.jump}</h2><button class="lr-btn" data-dismiss type="button" aria-label="${L.close}">${svg("close")}</button></div>
      <form class="lr-jump" id="lrJumpForm"><input id="lrJumpInput" type="number" inputmode="numeric" min="1" max="${numPages}" value="${currentPage}" aria-label="${L.jump}"><span>${L.of} ${numPages}</span><button class="lr-cta" type="submit">${L.go}</button></form>
      <small class="lr-err" id="lrJumpErr" hidden>${L.invalid}</small>`, sheet => {
      const input = sheet.querySelector("#lrJumpInput"), err = sheet.querySelector("#lrJumpErr");
      sheet.querySelector("#lrJumpForm").onsubmit = e => {
        e.preventDefault();
        const n = Number(input.value);
        if(!Number.isInteger(n) || n < 1 || n > numPages){ err.hidden = false; return; }
        closeSheet(); goTo(n, false);
      };
      input.oninput = () => { err.hidden = true; };
      setTimeout(() => { input.focus(); input.select(); }, 260);
    });
  }

  // ---------------- events ----------------
  const onScroll = () => {
    if(rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      const st = body.scrollTop, delta = st - lastScroll;
      lastScroll = st;
      update();
      showPill();
      if(prefs.autoHide && !sliding){
        if(delta > 14 && st > 120) setBars(false);
        else if(delta < -14 || st < 60) setBars(true);
      }
      clearTimeout(saveTimer);
      saveTimer = setTimeout(saveProgress, 500);
    });
  };
  body.addEventListener("scroll", onScroll, { passive: true });

  $("#lrBack").onclick = () => { saveProgress(); history.back(); };
  prevBtn.onclick = () => { setBars(true); goTo(currentPage - 1, true); };
  nextBtn.onclick = () => { setBars(true); goTo(currentPage + 1, true); };
  pageBtn.onclick = () => openJump();
  $("#lrNav").onclick = () => openNavigate(outline?.length ? "contents" : "marks");
  $("#lrSettings").onclick = () => openSettings();
  themeBtn.onclick = () => {
    const order = ["paper", "sepia", "night"];
    prefs = saveReaderPrefs({ theme: order[(order.indexOf(prefs.theme) + 1) % order.length] });
    applyLook();
    showPill(L[prefs.theme]);
  };
  markBtn.onclick = () => {
    if(!numPages || !key) return;
    const added = toggleBookmark(key, currentPage);
    marks = getBookmarks(key);
    updateMarkButton();
    toast(added ? L.added : L.removed);
    try{ navigator.vibrate?.(10); }catch{}
  };
  slider.addEventListener("input", () => { sliding = true; setCurrent(Number(slider.value)); goTo(Number(slider.value), false); showPill(); });
  slider.addEventListener("change", () => { sliding = false; });

  // Single tap toggles bars (delayed so a double-tap can zoom instead), double-tap zooms, pinch zooms.
  let touchMoved = false, startX = 0, startY = 0, pinchStart = 0, pinchLast = 0, pinchMid = [0, 0];
  const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  body.addEventListener("click", () => {
    if(touchMoved){ touchMoved = false; return; }
    clearTimeout(tapTimer);
    tapTimer = setTimeout(() => setBars(barsHidden), 230);
  });
  body.addEventListener("dblclick", e => {
    clearTimeout(tapTimer);
    if(!pdf) return;
    setZoom(zoom > 1.05 ? 1 : 2.2, [e.clientX, e.clientY]);
  });
  body.addEventListener("touchstart", e => {
    if(e.touches.length === 2){
      pinchStart = pinchLast = dist(e.touches); touchMoved = true;
      pinchMid = [(e.touches[0].clientX + e.touches[1].clientX) / 2, (e.touches[0].clientY + e.touches[1].clientY) / 2];
      const r = body.getBoundingClientRect();
      pagesEl.style.transformOrigin = `${pinchMid[0] - r.left + body.scrollLeft}px ${pinchMid[1] - r.top + body.scrollTop}px`;
      return;
    }
    startX = e.touches[0].clientX; startY = e.touches[0].clientY; touchMoved = false;
  }, { passive: true });
  body.addEventListener("touchmove", e => {
    if(e.touches.length === 2 && pinchStart){
      pinchLast = dist(e.touches); touchMoved = true;
      const ratio = Math.min(MAX_ZOOM / zoom, Math.max(MIN_ZOOM / zoom, pinchLast / pinchStart));
      pagesEl.style.transform = `scale(${ratio})`;
      return;
    }
    const t = e.touches[0];
    if(Math.abs(t.clientX - startX) > 10 || Math.abs(t.clientY - startY) > 10) touchMoved = true;
  }, { passive: true });
  body.addEventListener("touchend", () => {
    if(!pinchStart) return;
    const ratio = pinchLast / pinchStart;
    pinchStart = pinchLast = 0;
    pagesEl.style.transform = "";
    if(ratio > 1.06 || ratio < .94) setZoom(zoom * ratio, pinchMid);
  }, { passive: true });

  const onResize = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if(pdf && !destroyed) relayout(); }, 200);
  };
  window.addEventListener("resize", onResize, { passive: true });
  const onVisibility = () => { if(document.visibilityState !== "visible") saveProgress(); };
  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("pagehide", saveProgress);

  activeCleanup = () => {
    destroyed = true;
    saveProgress();
    cancelAnimationFrame(rafId);
    [saveTimer, pillTimer, resizeTimer, tapTimer, toastTimer].forEach(clearTimeout);
    window.removeEventListener("resize", onResize);
    window.removeEventListener("pagehide", saveProgress);
    document.removeEventListener("visibilitychange", onVisibility);
    native("setKeepScreenOn", { on: false });
    native("setImmersive", { on: false });
    for(const w of wrappers.values()){ try{ w.task?.cancel(); }catch{} }
    wrappers.clear();
    try{ task?.destroy?.(); }catch{}
    try{ pdf?.destroy?.(); }catch{}
    try{ file?.close?.(); }catch{}
  };

  load();
}
