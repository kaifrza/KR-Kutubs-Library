package com.kr.urdulibrary;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;
import android.util.Base64;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "KRDownloader")
public class KRDownloaderPlugin extends Plugin {

    // ------------------------------------------------------------------
    // Open files kept open while the in-app reader is using them
    // ------------------------------------------------------------------
    private static final class OpenFile {
        final ParcelFileDescriptor pfd;
        final FileInputStream in;
        final FileChannel channel;
        final long size;

        OpenFile(ParcelFileDescriptor pfd, FileInputStream in, FileChannel channel, long size) {
            this.pfd = pfd;
            this.in = in;
            this.channel = channel;
            this.size = size;
        }

        void close() {
            try { channel.close(); } catch (Exception ignored) { }
            try { in.close(); } catch (Exception ignored) { }
            try { pfd.close(); } catch (Exception ignored) { }
        }
    }

    private final Map<Integer, OpenFile> openFiles = new HashMap<>();
    private int nextHandle = 1;

    // ------------------------------------------------------------------
    // "Open with" support: MainActivity stores the incoming PDF here
    // ------------------------------------------------------------------
    private static String pendingUri = null;
    private static String pendingName = null;

    static synchronized void setPendingIntent(Context context, Intent intent) {
        if (intent == null) return;
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null) return;
        pendingUri = uri.toString();
        pendingName = displayName(context, uri);
    }

    private static String displayName(Context context, Uri uri) {
        Cursor c = null;
        try {
            c = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !c.isNull(i)) return c.getString(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "PDF" : last;
    }

    private long querySize(Uri uri) {
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) return c.getLong(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private DownloadManager manager() {
        return (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
    }

    private String msg(Exception e, String fallback) {
        return e.getMessage() != null ? e.getMessage() : fallback;
    }

    // ------------------------------------------------------------------
    // Downloading (Android DownloadManager -> public Downloads folder)
    // ------------------------------------------------------------------
    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url");
        String filename = call.getString("filename", "book.pdf");
        String title = call.getString("title", filename);
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            request.setDescription("KR Urdu Library");
            request.setMimeType("application/pdf");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            request.addRequestHeader("x-kr-client", "KR-URDU-LIBRARY-PDF-V1");
            long id = manager().enqueue(request);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not start download"));
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        Cursor c = null;
        try {
            JSObject ret = new JSObject();
            c = manager().query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()) {
                ret.put("found", true);
                ret.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                ret.put("downloaded", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                ret.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                ret.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                String uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                ret.put("uri", uri == null ? "" : uri);
            } else {
                ret.put("found", false);
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not read download status"));
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not cancel download"));
        }
    }

    // ------------------------------------------------------------------
    // Reading a file straight from storage (no copy is made)
    // ------------------------------------------------------------------
    @PluginMethod
    public void openFile(PluginCall call) {
        try {
            JSObject data = call.getData();
            String uriStr = data.optString("uri", "");
            String pathStr = data.optString("path", "");
            ParcelFileDescriptor pfd;
            if (pathStr != null && !pathStr.isEmpty()) {
                pfd = ParcelFileDescriptor.open(new File(pathStr), ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (uriStr != null && !uriStr.isEmpty()) {
                pfd = getContext().getContentResolver().openFileDescriptor(Uri.parse(uriStr), "r");
            } else {
                long id = data.optLong("id", -1);
                pfd = manager().openDownloadedFile(id);
            }
            if (pfd == null) {
                call.reject("Cannot open file");
                return;
            }
            long size = pfd.getStatSize();
            if (size <= 0 && uriStr != null && !uriStr.isEmpty()) {
                size = querySize(Uri.parse(uriStr));
            }
            if (size <= 0) {
                pfd.close();
                call.reject("File size is unknown");
                return;
            }
            FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
            FileChannel channel = in.getChannel();
            int handle;
            synchronized (openFiles) {
                handle = nextHandle++;
                openFiles.put(handle, new OpenFile(pfd, in, channel, size));
            }
            JSObject ret = new JSObject();
            ret.put("handle", handle);
            ret.put("size", size);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("openFile failed: " + msg(e, "unknown error"));
        }
    }

    @PluginMethod
    public void readChunk(PluginCall call) {
        try {
            JSObject data = call.getData();
            int handle = data.optInt("handle", -1);
            long offset = data.optLong("offset", 0);
            int length = data.optInt("length", 0);
            OpenFile f;
            synchronized (openFiles) {
                f = openFiles.get(handle);
            }
            if (f == null) {
                call.reject("File is not open");
                return;
            }
            JSObject ret = new JSObject();
            if (length <= 0 || offset < 0 || offset >= f.size) {
                ret.put("data", "");
                ret.put("bytes", 0);
                call.resolve(ret);
                return;
            }
            if (length > 1048576) length = 1048576;
            if (offset + length > f.size) length = (int) (f.size - offset);
            ByteBuffer buf = ByteBuffer.allocate(length);
            int total = 0;
            synchronized (f) {
                while (total < length) {
                    int n = f.channel.read(buf, offset + total);
                    if (n < 0) break;
                    total += n;
                }
            }
            ret.put("data", Base64.encodeToString(buf.array(), 0, total, Base64.NO_WRAP));
            ret.put("bytes", total);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("readChunk failed: " + msg(e, "unknown error"));
        }
    }

    @PluginMethod
    public void closeFile(PluginCall call) {
        int handle = call.getData().optInt("handle", -1);
        OpenFile f;
        synchronized (openFiles) {
            f = openFiles.remove(handle);
        }
        if (f != null) f.close();
        call.resolve();
    }

    @PluginMethod
    public void fileInfo(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        JSObject ret = new JSObject();
        ret.put("exists", false);
        ParcelFileDescriptor pfd = null;
        try {
            pfd = manager().openDownloadedFile(id);
            if (pfd != null) {
                ret.put("exists", true);
                ret.put("size", pfd.getStatSize());
            }
        } catch (Exception ignored) {
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) { }
            }
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void deleteDownload(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not delete file"));
        }
    }

    // ------------------------------------------------------------------
    // "Open with" hand-over to the web layer
    // ------------------------------------------------------------------
    @PluginMethod
    public void getPendingOpen(PluginCall call) {
        JSObject ret = new JSObject();
        synchronized (KRDownloaderPlugin.class) {
            if (pendingUri != null) {
                ret.put("uri", pendingUri);
                ret.put("name", pendingName == null ? "" : pendingName);
                pendingUri = null;
                pendingName = null;
            }
        }
        call.resolve(ret);
    }

    // ------------------------------------------------------------------
    // Storage access (needed to list every PDF on the phone)
    // ------------------------------------------------------------------
    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void checkStorageAccess(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", hasStorageAccess());
        ret.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestStorageAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                try {
                    getActivity().startActivity(intent);
                } catch (Exception e) {
                    getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7301);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not request storage access"));
        }
    }

    // ------------------------------------------------------------------
    // Find every PDF on the phone's main storage
    // ------------------------------------------------------------------
    @PluginMethod
    public void scanPdfs(final PluginCall call) {
        new Thread(() -> {
            try {
                if (!hasStorageAccess()) {
                    call.reject("Storage access not granted");
                    return;
                }
                final int limit = 5000;
                int count = 0;
                File rootDir = Environment.getExternalStorageDirectory();
                String root = rootDir.getAbsolutePath();
                String skipData = root + "/Android/data";
                String skipObb = root + "/Android/obb";
                JSArray files = new JSArray();
                ArrayDeque<File> stack = new ArrayDeque<>();
                stack.push(rootDir);
                while (!stack.isEmpty() && count < limit) {
                    File dir = stack.pop();
                    File[] children = dir.listFiles();
                    if (children == null) continue;
                    for (File f : children) {
                        String name = f.getName();
                        if (name.startsWith(".")) continue;
                        if (f.isDirectory()) {
                            String path = f.getAbsolutePath();
                            if (path.equals(skipData) || path.equals(skipObb)) continue;
                            stack.push(f);
                        } else if (name.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                            long len = f.length();
                            if (len <= 0) continue;
                            JSObject o = new JSObject();
                            o.put("path", f.getAbsolutePath());
                            o.put("name", name);
                            o.put("size", len);
                            o.put("modified", f.lastModified());
                            files.put(o);
                            count++;
                            if (count >= limit) break;
                        }
                    }
                }
                JSObject ret = new JSObject();
                ret.put("files", files);
                ret.put("truncated", count >= limit);
                call.resolve(ret);
            } catch (Throwable e) {
                call.reject("scan failed: " + (e.getMessage() != null ? e.getMessage() : "error"));
            }
        }).start();
    }

    // ------------------------------------------------------------------
    // First-page thumbnails (small JPEGs cached in the app's cache folder)
    // ------------------------------------------------------------------
    private final ExecutorService thumbExecutor = Executors.newSingleThreadExecutor();

    private static byte[] readAll(File f) throws java.io.IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    @PluginMethod
    public void thumbnail(final PluginCall call) {
        final JSObject data = call.getData();
        thumbExecutor.execute(() -> {
            ParcelFileDescriptor pfd = null;
            PdfRenderer renderer = null;
            PdfRenderer.Page page = null;
            try {
                String path = data.optString("path", "");
                String key = data.optString("key", path);
                int width = data.optInt("width", 240);
                if (path.isEmpty()) {
                    call.reject("path is required");
                    return;
                }
                File dir = new File(getContext().getCacheDir(), "thumbs");
                if (!dir.exists()) dir.mkdirs();
                File cached = new File(dir, Integer.toHexString(key.hashCode()) + "_" + key.length() + ".jpg");
                byte[] jpg;
                if (cached.exists() && cached.length() > 0) {
                    jpg = readAll(cached);
                } else {
                    pfd = ParcelFileDescriptor.open(new File(path), ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer = new PdfRenderer(pfd);
                    if (renderer.getPageCount() < 1) {
                        call.reject("empty pdf");
                        return;
                    }
                    page = renderer.openPage(0);
                    int h = Math.max(1, Math.min(width * 2,
                            Math.round((float) page.getHeight() * width / page.getWidth())));
                    Bitmap bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 72, out);
                    bmp.recycle();
                    jpg = out.toByteArray();
                    try (FileOutputStream fos = new FileOutputStream(cached)) {
                        fos.write(jpg);
                    } catch (Exception ignored) {
                    }
                }
                JSObject ret = new JSObject();
                ret.put("data", "data:image/jpeg;base64," + Base64.encodeToString(jpg, Base64.NO_WRAP));
                call.resolve(ret);
            } catch (Throwable e) {
                call.reject("thumbnail failed: " + (e.getMessage() != null ? e.getMessage() : "error"));
            } finally {
                try { if (page != null) page.close(); } catch (Exception ignored) { }
                try { if (renderer != null) renderer.close(); } catch (Exception ignored) { }
                try { if (pfd != null) pfd.close(); } catch (Exception ignored) { }
            }
        });
    }

    // ------------------------------------------------------------------
    // Reader comfort: keep the screen awake / hide system bars while reading
    // ------------------------------------------------------------------
    @PluginMethod
    public void setKeepScreenOn(final PluginCall call) {
        final boolean on = call.getData().optBoolean("on", false);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                if (on) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change screen setting"));
            }
        });
    }

    @PluginMethod
    public void setImmersive(final PluginCall call) {
        final boolean on = call.getData().optBoolean("on", false);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                if (c != null) {
                    if (on) {
                        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        c.hide(WindowInsetsCompat.Type.systemBars());
                    } else {
                        c.show(WindowInsetsCompat.Type.systemBars());
                    }
                }
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change system bars"));
            }
        });
    }

    // ------------------------------------------------------------------
    // Theme sync: colour the window + status/navigation bars like the app background
    // ------------------------------------------------------------------
    @PluginMethod
    public void setSystemBars(final PluginCall call) {
        final String hex = call.getData().optString("color", "#f7f7f5");
        final boolean light = call.getData().optBoolean("light", true);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                MainActivity.applySystemBars(getActivity(), Color.parseColor(hex), light);
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change system bar colours"));
            }
        });
    }
}
