// Small local stores for the in-app reader: look & feel, bookmarks, exact reading position.
const PREFS_KEY = "krl_reader_prefs_v1";
const MARKS_KEY = "krl_reader_marks_v1";
const POS_KEY = "krl_reader_pos_v1";
const HL_KEY = "krl_reader_hl_v1";

const DEFAULTS = { theme: "paper", dim: 0, keepAwake: false, autoHide: true };
const THEMES = ["paper", "sepia", "night"];

function read(key, fallback){
  try{
    const v = JSON.parse(localStorage.getItem(key) || "null");
    return v && typeof v === "object" ? v : fallback;
  }catch{ return fallback; }
}
function write(key, value){
  try{ localStorage.setItem(key, JSON.stringify(value)); }catch{}
}

export function getReaderPrefs(){
  const p = { ...DEFAULTS, ...read(PREFS_KEY, {}) };
  if(!THEMES.includes(p.theme)) p.theme = DEFAULTS.theme;
  p.dim = Math.min(.7, Math.max(0, Number(p.dim) || 0));
  p.keepAwake = Boolean(p.keepAwake);
  p.autoHide = p.autoHide !== false;
  return p;
}
export function saveReaderPrefs(patch){
  const next = { ...getReaderPrefs(), ...patch };
  write(PREFS_KEY, next);
  return next;
}

export function getBookmarks(key){
  const all = read(MARKS_KEY, {});
  const list = Array.isArray(all[key]) ? all[key] : [];
  return list.filter(n => Number.isInteger(n) && n > 0).sort((a, b) => a - b);
}
export function toggleBookmark(key, page){
  const all = read(MARKS_KEY, {});
  const list = new Set(Array.isArray(all[key]) ? all[key] : []);
  let added;
  if(list.has(page)){ list.delete(page); added = false; }
  else{ list.add(page); added = true; }
  all[key] = Array.from(list).sort((a, b) => a - b);
  if(!all[key].length) delete all[key];
  write(MARKS_KEY, all);
  return added;
}

export function setBookmarks(key, pages){
  const all = read(MARKS_KEY, {});
  const list = Array.from(new Set((pages || []).map(Number).filter(n => Number.isInteger(n) && n > 0))).sort((a, b) => a - b);
  if(list.length) all[key] = list; else delete all[key];
  write(MARKS_KEY, all);
}

function cleanHighlights(list){
  if(!Array.isArray(list)) return [];
  const out = [];
  for(const h of list){
    if(!h || typeof h !== "object") continue;
    const r = Array.isArray(h.r) ? h.r.map(Number).filter(Number.isFinite) : [];
    const p = Number(h.p);
    if(r.length < 4 || !Number.isInteger(p) || p < 1) continue;
    out.push({
      id: String(h.id || "").slice(0, 40) || Math.random().toString(36).slice(2),
      p, r: r.slice(0, r.length - (r.length % 4)),
      t: String(h.t || "").slice(0, 4000),
      c: Math.min(4, Math.max(0, Number(h.c) | 0)),
      s: Math.min(2, Math.max(0, Number(h.s) | 0)),
      n: String(h.n || "").slice(0, 4000),
      d: Number(h.d) || 0
    });
    if(out.length >= 1500) break;
  }
  return out;
}
export function getHighlights(key){
  const all = read(HL_KEY, {});
  return cleanHighlights(all[key]);
}
export function setHighlights(key, list){
  const all = read(HL_KEY, {});
  const clean = cleanHighlights(list);
  if(clean.length) all[key] = clean; else delete all[key];
  write(HL_KEY, all);
}

export function getReadingPosition(key){
  const all = read(POS_KEY, {});
  const v = all[key];
  if(!v || !Number.isInteger(v.p) || v.p < 1) return null;
  return { page: v.p, frac: Math.min(1, Math.max(0, Number(v.f) || 0)) };
}
export function saveReadingPosition(key, page, frac){
  const all = read(POS_KEY, {});
  all[key] = { p: page, f: Math.round(frac * 1000) / 1000 };
  const keys = Object.keys(all);
  if(keys.length > 400) delete all[keys[0]];
  write(POS_KEY, all);
}

// Copy bookmarks + reading position from an old key to a new one (only if the new key has none yet).
export function migrateReaderKey(from, to){
  if(!from || !to || from === to) return;
  const marks = read(MARKS_KEY, {});
  if(marks[from] && !marks[to]){ marks[to] = marks[from]; write(MARKS_KEY, marks); }
  const pos = read(POS_KEY, {});
  if(pos[from] && !pos[to]){ pos[to] = pos[from]; write(POS_KEY, pos); }
  const hl = read(HL_KEY, {});
  if(hl[from] && !hl[to]){ hl[to] = hl[from]; write(HL_KEY, hl); }
}
