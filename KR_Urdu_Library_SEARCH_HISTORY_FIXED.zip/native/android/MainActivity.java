package com.kr.urdulibrary;

import android.content.Intent;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KRDownloaderPlugin.class);
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            KRDownloaderPlugin.setPendingIntent(this, getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        KRDownloaderPlugin.setPendingIntent(this, intent);
    }
}
