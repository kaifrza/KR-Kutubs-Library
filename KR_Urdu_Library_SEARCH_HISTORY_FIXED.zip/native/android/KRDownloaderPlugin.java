package com.kr.urdulibrary;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;

@CapacitorPlugin(name = "KRDownloader")
public class KRDownloaderPlugin extends Plugin {

    // ------------------------------------------------------------------
    // Open files kept open while the in-app reader is using them
    // ------------------------------------------------------------------
    private static final class OpenFile {
        final ParcelFileDescriptor pfd;
        final FileInputStream in;
        final FileChannel channel;
        final long size;

        OpenFile(ParcelFileDescriptor pfd, FileInputStream in, FileChannel channel, long size) {
            this.pfd = pfd;
            this.in = in;
            this.channel = channel;
            this.size = size;
        }

        void close() {
            try { channel.close(); } catch (Exception ignored) { }
            try { in.close(); } catch (Exception ignored) { }
            try { pfd.close(); } catch (Exception ignored) { }
        }
    }

    private final Map<Integer, OpenFile> openFiles = new HashMap<>();
    private int nextHandle = 1;

    // ------------------------------------------------------------------
    // "Open with" support: MainActivity stores the incoming PDF here
    // ------------------------------------------------------------------
    private static String pendingUri = null;
    private static String pendingName = null;

    static synchronized void setPendingIntent(Context context, Intent intent) {
        if (intent == null) return;
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null) return;
        pendingUri = uri.toString();
        pendingName = displayName(context, uri);
    }

    private static String displayName(Context context, Uri uri) {
        Cursor c = null;
        try {
            c = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !c.isNull(i)) return c.getString(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "PDF" : last;
    }

    private long querySize(Uri uri) {
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) return c.getLong(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private DownloadManager manager() {
        return (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
    }

    private String msg(Exception e, String fallback) {
        return e.getMessage() != null ? e.getMessage() : fallback;
    }

    // ------------------------------------------------------------------
    // Downloading (Android DownloadManager -> public Downloads folder)
    // ------------------------------------------------------------------
    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url");
        String filename = call.getString("filename", "book.pdf");
        String title = call.getString("title", filename);
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            request.setDescription("KR Urdu Library");
            request.setMimeType("application/pdf");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            request.addRequestHeader("x-kr-client", "KR-URDU-LIBRARY-PDF-V1");
            long id = manager().enqueue(request);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not start download"));
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        Cursor c = null;
        try {
            JSObject ret = new JSObject();
            c = manager().query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()) {
                ret.put("found", true);
                ret.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                ret.put("downloaded", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                ret.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                ret.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                String uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                ret.put("uri", uri == null ? "" : uri);
            } else {
                ret.put("found", false);
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not read download status"));
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not cancel download"));
        }
    }

    // ------------------------------------------------------------------
    // Reading a file straight from storage (no copy is made)
    // ------------------------------------------------------------------
    @PluginMethod
    public void openFile(PluginCall call) {
        try {
            JSObject data = call.getData();
            String uriStr = data.optString("uri", "");
            ParcelFileDescriptor pfd;
            if (uriStr != null && !uriStr.isEmpty()) {
                pfd = getContext().getContentResolver().openFileDescriptor(Uri.parse(uriStr), "r");
            } else {
                long id = data.optLong("id", -1);
                pfd = manager().openDownloadedFile(id);
            }
            if (pfd == null) {
                call.reject("Cannot open file");
                return;
            }
            long size = pfd.getStatSize();
            if (size <= 0 && uriStr != null && !uriStr.isEmpty()) {
                size = querySize(Uri.parse(uriStr));
            }
            if (size <= 0) {
                pfd.close();
                call.reject("File size is unknown");
                return;
            }
            FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
            FileChannel channel = in.getChannel();
            int handle;
            synchronized (openFiles) {
                handle = nextHandle++;
                openFiles.put(handle, new OpenFile(pfd, in, channel, size));
            }
            JSObject ret = new JSObject();
            ret.put("handle", handle);
            ret.put("size", size);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("openFile failed: " + msg(e, "unknown error"));
        }
    }

    @PluginMethod
    public void readChunk(PluginCall call) {
        try {
            JSObject data = call.getData();
            int handle = data.optInt("handle", -1);
            long offset = data.optLong("offset", 0);
            int length = data.optInt("length", 0);
            OpenFile f;
            synchronized (openFiles) {
                f = openFiles.get(handle);
            }
            if (f == null) {
                call.reject("File is not open");
                return;
            }
            JSObject ret = new JSObject();
            if (length <= 0 || offset < 0 || offset >= f.size) {
                ret.put("data", "");
                ret.put("bytes", 0);
                call.resolve(ret);
                return;
            }
            if (length > 1048576) length = 1048576;
            if (offset + length > f.size) length = (int) (f.size - offset);
            ByteBuffer buf = ByteBuffer.allocate(length);
            int total = 0;
            synchronized (f) {
                while (total < length) {
                    int n = f.channel.read(buf, offset + total);
                    if (n < 0) break;
                    total += n;
                }
            }
            ret.put("data", Base64.encodeToString(buf.array(), 0, total, Base64.NO_WRAP));
            ret.put("bytes", total);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("readChunk failed: " + msg(e, "unknown error"));
        }
    }

    @PluginMethod
    public void closeFile(PluginCall call) {
        int handle = call.getData().optInt("handle", -1);
        OpenFile f;
        synchronized (openFiles) {
            f = openFiles.remove(handle);
        }
        if (f != null) f.close();
        call.resolve();
    }

    @PluginMethod
    public void fileInfo(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        JSObject ret = new JSObject();
        ret.put("exists", false);
        ParcelFileDescriptor pfd = null;
        try {
            pfd = manager().openDownloadedFile(id);
            if (pfd != null) {
                ret.put("exists", true);
                ret.put("size", pfd.getStatSize());
            }
        } catch (Exception ignored) {
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) { }
            }
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void deleteDownload(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not delete file"));
        }
    }

    // ------------------------------------------------------------------
    // "Open with" hand-over to the web layer
    // ------------------------------------------------------------------
    @PluginMethod
    public void getPendingOpen(PluginCall call) {
        JSObject ret = new JSObject();
        synchronized (KRDownloaderPlugin.class) {
            if (pendingUri != null) {
                ret.put("uri", pendingUri);
                ret.put("name", pendingName == null ? "" : pendingName);
                pendingUri = null;
                pendingName = null;
            }
        }
        call.resolve(ret);
    }
}
