import { navigate } from "../router.js";

export function renderBottomNav(active, lang) {
  const labels = lang === "ur"
    ? [["home","fa-house","گھر"],["classes","fa-book-open","جماعتیں"],["categories","fa-layer-group","زمرے"],["favorites","fa-heart","پسندیدہ"],["more","fa-ellipsis","مزید"]]
    : [["home","fa-house","Home"],["classes","fa-book-open","Classes"],["categories","fa-layer-group","Categories"],["favorites","fa-heart","Favorites"],["more","fa-ellipsis","More"]];

  const nav = document.createElement("nav");
  nav.className = "bottom-nav";
  nav.setAttribute("aria-label", lang === "ur" ? "مرکزی نیویگیشن" : "Main navigation");
  labels.forEach(([route, icon, label]) => {
    const b = document.createElement("button");
    b.className = `nav-item ${active === route ? "active" : ""}`;
    if (active === route) b.setAttribute("aria-current", "page");
    b.innerHTML = `<span class="nav-icon" aria-hidden="true"><i class="fa-solid ${icon}"></i></span><span>${label}</span>`;
    b.addEventListener("click", () => navigate(route));
    nav.appendChild(b);
  });
  return nav;
}
