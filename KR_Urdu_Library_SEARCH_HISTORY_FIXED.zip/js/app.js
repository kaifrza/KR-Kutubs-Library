import { loadLibraryData, loadNextBookPage, ensureAllBooksLoaded, searchBooksPage, mergeBooksIntoLibrary, getLibraryCacheInfo, loadClassStats } from "./data/data-loader.js";
import { state } from "./state.js";
import { readRoute, navigate, replaceRoute, ensureAppHistory, isAppHistoryEntry, syncHashNavigation } from "./router.js";
import { renderBottomNav } from "./components/bottom-nav.js";
import { bookCard } from "./components/book-card.js";
import { searchBooks } from "./features/search.js";
import { applyTheme, changeTheme, watchSystemTheme } from "./features/theme.js";
import {
  getFavorites, toggleFavorite, addHistory, getHistory, clearHistory,
  getBookProgress, setProgress, clearProgress, getLanguage, setLanguage
} from "./utils/storage.js";
import { escapeHTML, formatPages } from "./utils/helpers.js";
import { coverMarkup, wireCover } from "./utils/cover.js";
import { SUPABASE_URL } from "./data/supabase.js";
import { downloadManager, DOWNLOAD_STATES, nativeDiagnostics, getNativePlugin } from "./features/download-manager.js";
import { loadPdfJs } from "./features/pdfjs-loader.js";
import { renderLocalReader, cleanupLocalReader } from "./features/local-reader.js";
import { getDownloads, getDownloadRecord, removeDownloadRecord } from "./features/downloads-store.js";
import { createReaderNetworkMonitor } from "./features/reader-network-monitor.js";
import { getCachedPdf, hasCachedPdf, getPdfCacheInfo, clearPdfCache } from "./features/pdf-cache.js";

const app = document.querySelector("#app");
let data;
const t = {
  ur: {
    brand:"KR Urdu Library", tagline:"اردو و اسلامی کتب کا ڈیجیٹل کتب خانہ", search:"کتاب، مصنف یا لفظ تلاش کریں",
    classes:"جماعت کے لحاظ سے", featured:"منتخب کتب", recent:"حال ہی میں شامل کتب", continue:"جہاں چھوڑا تھا",
    available:"دستیاب", back:"واپس", read:"پڑھیں", download:"ڈاؤنلوڈ", fav:"پسندیدہ کتب", source:"اصل ماخذ",
    openSource:"اصل ویب سائٹ دیکھیں", report:"مسئلہ رپورٹ کریں", more:"مزید", empty:"ابھی کوئی کتاب موجود نہیں۔",
    clearHistory:"مطالعہ کی تاریخ صاف کریں", clearData:"مقامی ڈیٹا صاف کریں", clearOffline:"محفوظ شدہ کتب صاف کریں", confirmClear:"پسندیدہ، مطالعہ کی تاریخ اور پیش رفت صاف کر دیں؟",
    cleared:"مقامی ڈیٹا صاف کر دیا گیا۔", theme:"ظاہری انداز", language:"زبان", rights:"ذرائع اور حقوق",
    browse:"سب جماعتیں دیکھیں", allBooks:"تمام کتب", searchResults:"تلاش کے نتائج", noSearch:"کوئی کتاب نہیں ملی",
    noSearchHint:"عنوان، مصنف یا کوئی دوسرا لفظ آزما کر دیکھیں۔", noClassBooks:"اس جماعت میں ابھی کوئی کتاب دستیاب نہیں۔", noCategoryBooks:"اس زمرے میں ابھی کوئی کتاب دستیاب نہیں۔", noFavorites:"ابھی کوئی پسندیدہ کتاب نہیں۔", filterAll:"تمام کتب", filterMatn:"متون", filterSharah:"شروحات", continueAction:"مطالعہ جاری رکھیں", pageOf:"صفحہ",
    reportSoon:"رپورٹ فیچر ابھی دستیاب نہیں ہے۔", related:"ملتی جلتی کتب", relatedHint:"اسی جماعت یا زمرے کی مزید کتب", sourceMissing:"اس کتاب کا PDF ماخذ ابھی دستیاب نہیں ہے۔", favoriteAdded:"کتاب پسندیدہ میں شامل ہوگئی۔", favoriteRemoved:"کتاب پسندیدہ سے ہٹا دی گئی۔",
    historyCleared:"مطالعہ کی تاریخ صاف کر دی گئی۔", dataCleared:"مقامی ڈیٹا صاف کر دیا گیا۔", quickClasses:"جماعتیں", quickCategories:"زمرے",
    quickFavorites:"پسندیدہ", quickHistory:"حالیہ مطالعہ", about:"مختصر تعارف", unavailable:"فی الحال دستیاب نہیں", moreIntro:"آپ کی لائبریری کے اہم اختیارات ایک جگہ", quickSettings:"فوری ترتیبات", librarySection:"لائبریری", offlineSection:"آف لائن کتب", personalSection:"ذاتی لائبریری", dataSection:"ڈیٹا اور اسٹوریج", appearanceShort:"ظاہری انداز", languageShort:"زبان", catalogueCount:"کتب", savedBooks:"محفوظ شدہ کتب", storageUsed:"استعمال شدہ جگہ", clearHistoryShort:"مطالعہ کی تاریخ صاف کریں", clearDataShort:"تمام مقامی ڈیٹا صاف کریں", clearOfflineShort:"محفوظ شدہ آف لائن کتب صاف کریں", recentCount:"حالیہ مطالعہ", favouritesCount:"پسندیدہ کتب", sourceRightsShort:"ذرائع اور حقوق", aboutApp:"KR Urdu Library کے بارے میں", systemTheme:"سسٹم", lightTheme:"لائٹ", darkTheme:"ڈارک",
    offline:"آپ آف لائن ہیں؛ محفوظ شدہ کتب دکھائی جا رہی ہیں۔", online:"انٹرنیٹ بحال ہوگیا۔", cached:"محفوظ شدہ ڈیٹا استعمال ہو رہا ہے۔", readerLoading:"کتاب لوڈ ہو رہی ہے…", readerPageError:"صفحہ دکھایا نہیں جا سکا", readerLoadError:"PDF لوڈ نہیں ہو سکی",
    openPdf:"PDF کھولیں", readerSource:"اصل ماخذ کھولیں", previous:"پچھلا صفحہ", next:"اگلا صفحہ", zoomOut:"زوم کم کریں",
    zoomIn:"زوم بڑھائیں", fullscreen:"مکمل اسکرین", hideControls:"کنٹرول چھپائیں", showControls:"کنٹرول دکھائیں", retry:"دوبارہ کوشش کریں", alternateReader:"متبادل ریڈر استعمال کریں", readerViewerHint:"اگر PDF یہاں نظر نہ آئے تو متبادل ریڈر استعمال کریں۔", readerClosed:"مطالعہ بند کر دیا گیا۔", refresh:"تازہ کریں", refreshing:"کتب تازہ کی جا رہی ہیں…", refreshed:"کتب تازہ ہوگئیں۔", refreshFailed:"تازہ کاری ناکام ہوگئی۔"
  },
  en: {
    brand:"KR Urdu Library", tagline:"A Digital Home for Urdu & Islamic Books", search:"Search books, authors or keywords",
    classes:"Browse by Class", featured:"Featured Books", recent:"Recently Added", continue:"Continue Reading",
    available:"Available", back:"Back", read:"Read", download:"Download", fav:"Favorites", source:"Original Source",
    openSource:"View Original Source", report:"Report a Problem", more:"More", empty:"No books found.",
    clearHistory:"Clear reading history", clearData:"Clear local data", clearOffline:"Clear saved offline books", confirmClear:"Clear favorites, reading history and reading progress?",
    cleared:"Local data cleared.", theme:"Appearance", language:"Language", rights:"Sources & Rights",
    browse:"View all classes", allBooks:"All books", searchResults:"Search results", noSearch:"No books found",
    noSearchHint:"Try a different title, author, or keyword.", noClassBooks:"No books are available in this class yet.", noCategoryBooks:"No books are available in this category yet.", noFavorites:"No favorite books yet.", filterAll:"All books", filterMatn:"Matn", filterSharah:"Commentary", continueAction:"Continue reading", pageOf:"Page",
    reportSoon:"Reporting is not available yet.", related:"Related books", relatedHint:"More books from the same class or category", sourceMissing:"A PDF source is not currently available for this book.", favoriteAdded:"Book added to favorites.", favoriteRemoved:"Book removed from favorites.",
    historyCleared:"Reading history cleared.", dataCleared:"Local data cleared.", quickClasses:"Classes", quickCategories:"Categories",
    quickFavorites:"Favorites", quickHistory:"Recent", about:"About this book", unavailable:"Currently unavailable", moreIntro:"Your essential library controls, all in one place", quickSettings:"Quick settings", librarySection:"Library", offlineSection:"Offline books", personalSection:"Your library", dataSection:"Data & storage", appearanceShort:"Appearance", languageShort:"Language", catalogueCount:"books", savedBooks:"Saved books", storageUsed:"Storage used", clearHistoryShort:"Clear reading history", clearDataShort:"Clear all local data", clearOfflineShort:"Clear saved offline books", recentCount:"Recent reading", favouritesCount:"Favorite books", sourceRightsShort:"Sources & Rights", aboutApp:"About KR Urdu Library", systemTheme:"System", lightTheme:"Light", darkTheme:"Dark",
    offline:"You are offline; showing cached library data.", online:"Internet connection restored.", cached:"Using cached library data.", readerLoading:"Loading book…", readerPageError:"Page could not be rendered", readerLoadError:"Unable to load PDF",
    openPdf:"Open PDF", readerSource:"Open Source", previous:"Previous page", next:"Next page", zoomOut:"Zoom out",
    zoomIn:"Zoom in", fullscreen:"Fullscreen", hideControls:"Hide controls", showControls:"Show controls", retry:"Retry", alternateReader:"Use alternate reader", readerViewerHint:"If the PDF does not appear here, use the alternate reader.", readerClosed:"Reading closed.", refresh:"Refresh", refreshing:"Refreshing library…", refreshed:"Library refreshed.", refreshFailed:"Refresh failed."
  }
};

const langName = (c, lang) => lang === "ur" ? c.name : (c.nameEn || c.name);
function currentLang(){ return state.language; }
function setDirection(){
  const rtl = currentLang() === "ur";
  document.documentElement.lang = rtl ? "ur" : "en";
  document.documentElement.dir = rtl ? "rtl" : "ltr";
}
function validExternalUrl(url){ try { const u = new URL(url, location.href); return ["http:","https:"].includes(u.protocol); } catch { return false; } }
function openExternal(url){ if(validExternalUrl(url)) window.open(url, "_blank", "noopener,noreferrer"); }
function archiveIdentifierFromUrl(url){
  try{
    const u=new URL(url,location.href);
    if(!/(^|\.)archive\.org$/i.test(u.hostname))return null;
    const parts=u.pathname.split('/').filter(Boolean);
    for(const marker of ['download','details','embed']){
      const i=parts.indexOf(marker);
      if(i>=0&&parts[i+1])return decodeURIComponent(parts[i+1]);
    }
  }catch{}
  return null;
}

function readerSourceForBook(book){
  const type=String(book?.pdfSourceType||'').toLowerCase();
  const driveId=String(book?.driveFileId||'').trim();
  if(type==='drive' || driveId){
    if(driveId)return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/preview`};
  }
  // Be resilient to older records where a Drive /file/{id}/view URL was
  // stored in pdfUrl without a separate drive_file_id. The canonical reader
  // still remains Drive preview; this does not create a second source.
  for(const candidate of [book?.source?.pageUrl,book?.pdfUrl]){
    try{
      const u=new URL(candidate,location.href);
      const m=u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i);
      if(/(^|\.)drive\.google\.com$/i.test(u.hostname) && m?.[1]){
        return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(m[1])}/preview`};
      }
    }catch{}

    const identifier=archiveIdentifierFromUrl(candidate);
    if(identifier)return {kind:'archive',url:`https://archive.org/embed/${encodeURIComponent(identifier)}`};
  }
  if(validExternalUrl(book?.pdfUrl))return {kind:'external',url:book.pdfUrl};
  return null;
}
// PDF.js fallback fetches through the gateway because third-party hosts such as Archive.org and
// Google Drive are not expected to expose the CORS contract needed by PDF.js. The primary reader
// is source-specific: Archive.org uses its /embed/{identifier} viewer and public Drive books use
// the Drive /file/{id}/preview viewer. Only the fallback path uses the gateway + PDF.js.
const PDF_GATEWAY_CLIENT = "KR-URDU-LIBRARY-PDF-V1";
function pdfGatewayUrl(bookId){
  return `${SUPABASE_URL}/functions/v1/pdf-gateway?book_id=${encodeURIComponent(bookId)}&client=${PDF_GATEWAY_CLIENT}`;
}

function formatDownloadBytes(bytes){
  if(!Number.isFinite(bytes) || bytes < 0) return "—";
  const units=["B","KB","MB","GB"];
  let n=bytes, i=0;
  while(n>=1024 && i<units.length-1){ n/=1024; i++; }
  const digits=i===0?0:(n>=100?0:n>=10?1:2);
  return `${n.toFixed(digits)} ${units[i]}`;
}

function formatDownloadSpeed(bytesPerSecond){
  return Number.isFinite(bytesPerSecond) && bytesPerSecond > 0 ? `${formatDownloadBytes(bytesPerSecond)}/s` : "";
}

function formatDownloadEta(seconds){
  if(!Number.isFinite(seconds) || seconds < 0) return "";
  const total=Math.ceil(seconds);
  if(total < 60) return `${total}s`;
  const minutes=Math.floor(total/60);
  const secs=total%60;
  if(minutes < 60) return `${minutes}m ${secs}s`;
  const hours=Math.floor(minutes/60);
  return `${hours}h ${minutes%60}m`;
}

function ensureDownloadStatus(){
  let region=document.querySelector(".download-status-region");
  if(!region){
    region=document.createElement("div");
    region.className="download-status-region";
    region.setAttribute("aria-live","polite");
    region.setAttribute("aria-atomic","false");
    document.body.appendChild(region);
  }
  return region;
}

function updateDownloadStatus(payload){
  const region=ensureDownloadStatus();
  if(payload.state===DOWNLOAD_STATES.IDLE || !payload.bookId) return;

  const key=String(payload.bookId).replace(/[^A-Za-z0-9_-]/g,"_");
  let card=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
  if(!card){
    card=document.createElement("section");
    card.className="download-status";
    card.dataset.downloadId=String(payload.bookId);
    region.appendChild(card);
  }

  const title=payload.filename ? payload.filename.replace(/\.pdf$/i,"") : (currentLang()==="ur" ? "کتاب" : "Book");
  const ur=currentLang()==="ur";
  let statusText=ur ? "ڈاؤن لوڈ ہو رہی ہے…" : "Downloading…";
  if(payload.state===DOWNLOAD_STATES.PREPARING) statusText=ur ? "ڈاؤن لوڈ تیار ہو رہا ہے…" : "Preparing download…";
  if(payload.state===DOWNLOAD_STATES.COMPLETING) statusText=ur ? "فائل تیار ہو رہی ہے…" : "Finishing…";
  if(payload.state===DOWNLOAD_STATES.CANCELLING) statusText=ur ? "ڈاؤن لوڈ منسوخ ہو رہا ہے…" : "Cancelling download…";
  if(payload.state===DOWNLOAD_STATES.HANDING_OFF) statusText=ur ? "فائل براؤزر کے حوالے کی جا رہی ہے…" : "Handing download to browser…";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF) statusText=ur ? "ڈاؤن لوڈ براؤزر کے حوالے ہوگیا ✓" : "Download handed to browser ✓";
  if(payload.state===DOWNLOAD_STATES.COMPLETED) statusText=ur ? "ڈاؤن لوڈ مکمل ہوگیا ✓" : "Download complete ✓";
  if(payload.state===DOWNLOAD_STATES.FAILED) statusText=ur ? "ڈاؤن لوڈ ناکام ہوگیا" : "Download failed";
  if(payload.state===DOWNLOAD_STATES.CANCELLED) statusText=ur ? "ڈاؤن لوڈ منسوخ ہوگیا" : "Download cancelled";

  const percent=Number.isFinite(payload.percentage) ? Math.max(0,Math.min(100,payload.percentage)) : null;
  const hasTotal=Number.isFinite(payload.totalBytes) && payload.totalBytes>0;
  let bytesLine;
  if(hasTotal) bytesLine=formatDownloadBytes(payload.downloadedBytes||0)+" / "+formatDownloadBytes(payload.totalBytes);
  else if(Number.isFinite(payload.downloadedBytes)) bytesLine=formatDownloadBytes(payload.downloadedBytes)+" · "+(ur ? "کل سائز معلوم نہیں" : "size unknown");
  else bytesLine=ur ? "سائز معلوم کیا جا رہا ہے" : "Checking file size…";

  const progressLabel=percent===null ? "" : percent.toFixed(percent>=10 ? 0 : 1)+"%";
  const speed=formatDownloadSpeed(payload.speedBytesPerSecond);
  const eta=formatDownloadEta(payload.etaSeconds);
  let details=speed;
  if(eta) details+=(details ? " · " : "")+(ur ? "باقی " : "left ")+eta;
  if(payload.state===DOWNLOAD_STATES.FAILED && payload.errorMessage) details=payload.errorMessage;
  if(payload.state===DOWNLOAD_STATES.CANCELLED) details=ur ? "آپ دوبارہ کوشش کر سکتے ہیں۔" : "You can retry this download.";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF) details=(ur ? "براؤزر اب فائل محفوظ کرے گا۔" : "Your browser is handling the file save.")+" ["+(payload.nativeFallbackReason ? payload.nativeFallbackReason+" | " : "")+nativeDiagnostics()+"]";
  if(payload.state===DOWNLOAD_STATES.COMPLETED && payload.mode==="native") details=ur ? "فائل ڈاؤن لوڈز فولڈر میں محفوظ ہوگئی۔" : "Saved to your Downloads folder.";

  const canCancel=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING].includes(payload.state);
  const cancelLabel=ur ? "ڈاؤن لوڈ منسوخ کریں" : "Cancel download";
  const cancelMarkup=canCancel ? '<button type="button" class="download-status-cancel" aria-label="'+escapeHTML(cancelLabel)+'"><i class="fa-solid fa-xmark"></i></button>' : "";
  const canRetry=[DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state) && downloadManager.canRetry(payload.bookId);
  const retryMarkup=canRetry ? '<button type="button" class="download-status-retry">'+escapeHTML(ur ? "دوبارہ کوشش کریں" : "Retry")+'</button>' : "";
  let progressMarkup;
  if(percent!==null) progressMarkup='<div class="download-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+percent.toFixed(1)+'"><span style="width:'+percent+'%"></span></div>';
  else progressMarkup='<div class="download-progress-track indeterminate"><span></span></div>';
  const detailsMarkup=details ? '<div class="download-status-sub">'+escapeHTML(details)+'</div>' : "";
  const cancellingClass=payload.state===DOWNLOAD_STATES.CANCELLING ? " is-cancelling" : "";
  const busyAttr=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING,DOWNLOAD_STATES.CANCELLING,DOWNLOAD_STATES.HANDING_OFF].includes(payload.state) ? ' aria-busy="true"' : "";
  card.className="download-status"+cancellingClass;
  card.setAttribute("role","status");
  if(busyAttr) card.setAttribute("aria-busy","true"); else card.removeAttribute("aria-busy");
  card.innerHTML='<div class="download-status-head"><div class="download-status-title"><i class="fa-solid fa-download"></i><span>'+escapeHTML(statusText)+'</span></div>'+cancelMarkup+'</div>'
    +'<div class="download-status-book" title="'+escapeHTML(title)+'">'+escapeHTML(title)+'</div>'
    +progressMarkup
    +'<div class="download-status-meta"><span>'+escapeHTML(bytesLine)+'</span><strong>'+escapeHTML(progressLabel)+'</strong></div>'
    +detailsMarkup+retryMarkup;

  const cancel=card.querySelector(".download-status-cancel");
  if(cancel) cancel.onclick=()=>downloadManager.cancel(payload.bookId);
  const retry=card.querySelector(".download-status-retry");
  if(retry){ retry.onclick=async()=>{ retry.disabled=true; try{ await downloadManager.retry(payload.bookId); }catch(err){ console.error("KR Urdu Library PDF retry failed",err); } }; }

  if([DOWNLOAD_STATES.COMPLETED,DOWNLOAD_STATES.HANDED_OFF,DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state)){
    const timerKey="timer_"+key;
    clearTimeout(updateDownloadStatus[timerKey]);
    updateDownloadStatus[timerKey]=setTimeout(()=>{
      const target=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
      if(target) target.remove();
      if(!region.children.length) region.remove();
    }, payload.state===DOWNLOAD_STATES.COMPLETED ? 3200 : (payload.state===DOWNLOAD_STATES.HANDED_OFF ? 20000 : 4500));
  }
}
downloadManager.subscribe(updateDownloadStatus);

function showToast(message){
  let region=document.querySelector(".toast-region");
  if(!region){ region=document.createElement("div"); region.className="toast-region"; region.setAttribute("aria-live","polite"); region.setAttribute("aria-atomic","true"); document.body.appendChild(region); }
  region.innerHTML=`<div class="toast" role="status">${escapeHTML(message)}</div>`;
  clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>region.remove(),2600);
}

function confirmDialog(title, message, confirmLabel, danger=false){
  return new Promise(resolve=>{
    const backdrop=document.createElement("div"); backdrop.className="modal-backdrop";
    backdrop.innerHTML=`<section class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><h2 id="modalTitle">${escapeHTML(title)}</h2><p>${escapeHTML(message)}</p><div class="modal-actions"><button class="btn" id="modalCancel">${currentLang()==="ur"?"منسوخ":"Cancel"}</button><button class="btn ${danger?"danger":"primary"}" id="modalConfirm">${escapeHTML(confirmLabel)}</button></div></section>`;
    document.body.appendChild(backdrop);
    const onKey=e=>{if(e.key==="Escape")finish(false);};
    const finish=value=>{document.removeEventListener("keydown",onKey);backdrop.remove();resolve(value);};
    backdrop.querySelector("#modalCancel").onclick=()=>finish(false);
    backdrop.querySelector("#modalConfirm").onclick=()=>finish(true);
    backdrop.addEventListener("click",e=>{if(e.target===backdrop)finish(false);});
    document.addEventListener("keydown",onKey);
    backdrop.querySelector("#modalConfirm").focus();
  });
}

function goBackInApp() {
  // Always keep Back inside the library when possible. A direct/deep link is
  // seeded with Home by ensureAppHistory(), so history.back() is safe here.
  if (isAppHistoryEntry() && history.length > 1) history.back();
  else navigate("home", {}, { replace: true });
}

let networkStatusTimer = null;
function updateNetworkStatus(mode = null) {
  const offline = mode === "offline" || (mode === null && typeof navigator !== "undefined" && navigator.onLine === false);
  const nodes = document.querySelectorAll(".network-status");
  nodes.forEach(node => {
    node.dataset.state = offline ? "offline" : "online";
    node.hidden = !offline;
    node.textContent = offline ? t[currentLang()].offline : "";
  });
}

function announceNetworkStatus(mode) {
  if (mode === "offline") {
    showToast(t[currentLang()].offline);
    updateNetworkStatus("offline");
    return;
  }
  updateNetworkStatus("online");
  if (networkStatusTimer) clearTimeout(networkStatusTimer);
  const message = t[currentLang()].online;
  showToast(message);
  networkStatusTimer = window.setTimeout(() => updateNetworkStatus(null), 2600);
}

function shell(title, content, active){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const top = document.createElement("header"); top.className = `topbar ${state.route === "home" ? "topbar-home" : ""}`;
  top.innerHTML = `<a class="brand" href="#home" aria-label="${escapeHTML(t[lang].brand)}"><span class="brand-mark">KR</span><span class="brand-copy"><span class="brand-name">${escapeHTML(t[lang].brand)}</span><span class="brand-context">${title}</span></span></a>
    <div class="topbar-actions"><span class="network-status" data-state="online" hidden role="status" aria-live="polite"></span>${state.route !== "reader" ? `<button class="icon-btn" id="refreshBtn" type="button" aria-label="${escapeHTML(t[lang].refresh)}" title="${escapeHTML(t[lang].refresh)}"><i class="fa-solid fa-arrows-rotate"></i></button>` : ""}<button class="icon-btn" id="downloadsBtn" type="button" aria-label="${escapeHTML(lang==="ur"?"ڈاؤنلوڈز":"Downloads")}" title="${escapeHTML(lang==="ur"?"ڈاؤنلوڈز":"Downloads")}"><i class="fa-solid fa-download"></i></button></div>`;
  app.appendChild(top);
  updateNetworkStatus(null);
  const page = document.createElement("main"); page.className = "page"; page.innerHTML = content; app.appendChild(page);
  if(state.route !== "reader") app.appendChild(renderBottomNav(active, lang));
  const downloadsBtn = top.querySelector("#downloadsBtn");
  if(downloadsBtn) downloadsBtn.onclick = () => navigate("downloads");
  const refreshBtn = top.querySelector("#refreshBtn");
  if(refreshBtn) refreshBtn.onclick = () => refreshLibrary({ source: "button" });
  return page;
}

function progressCard(book, lang){
  const title=lang==="ur"?book.title:(book.titleEn||book.title), progress=getBookProgress(book.id), percent=Math.max(0,Math.min(100,Number(progress?.percent)||0)), pageNo=Number(progress?.page)||0, total=Number(progress?.totalPages)||Number(book.pages)||0;
  const el=document.createElement("article"); el.className="progress-card";
  el.tabIndex=0;
  el.setAttribute("role","link");
  const ariaText=lang==="ur" ? "مطالعہ جاری رکھیں: "+title : "Continue reading: "+title;
  el.setAttribute("aria-label",escapeHTML(ariaText));
  const pageLabel=total ? (lang==="ur" ? "صفحہ "+pageNo+" از "+total : "Page "+pageNo+" of "+total) : (lang==="ur" ? percent+"% مکمل" : percent+"% complete");
  el.innerHTML="<div class=\"progress-cover\">"+coverMarkup(book.cover?escapeHTML(book.cover):"",escapeHTML(title))+"</div><div class=\"progress-copy\"><strong>"+escapeHTML(title)+"</strong><small>"+escapeHTML(pageLabel)+"</small><div class=\"progress-bar\" aria-label=\""+percent+"%\"><span style=\"width:"+percent+"%\"></span></div><button class=\"progress-action\" type=\"button\">"+escapeHTML(t[lang].continueAction)+" <i class=\"fa-solid fa-arrow-"+(lang==="ur"?"left":"right")+"\"></i></button></div>";
  wireCover(el.querySelector(".progress-cover"));
  const openReader=()=>navigate("reader",{id:book.id});
  el.addEventListener("click",e=>{ if(e.target.closest("button")) return; openReader(); });
  el.addEventListener("keydown",e=>{ if((e.key==="Enter"||e.key===" ")&&e.target===el){ e.preventDefault(); openReader(); } });
  el.querySelector(".progress-action").onclick=(e)=>{ e.stopPropagation(); openReader(); };
  return el;
}

let refreshInFlight = null;
let refreshTouchStartY = 0;
let refreshTouchStartX = 0;
let refreshPullDistance = 0;
let refreshTracking = false;
let refreshFailSafeTimer = null;
const REFRESH_TRIGGER = 72;
const REFRESH_MAX = 120;
const REFRESH_FAILSAFE_MS = 2500;

function showRefreshIndicator(stateName){
  let indicator = document.querySelector(".pull-refresh-indicator");
  if(!indicator){
    indicator = document.createElement("div");
    indicator.className = "pull-refresh-indicator";
    indicator.setAttribute("role", "status");
    indicator.setAttribute("aria-live", "polite");
    document.body.appendChild(indicator);
  }
  const lang=currentLang(), L=t[lang];
  const labels={pull:lang==="ur"?"تازہ کرنے کے لیے نیچے کھینچیں":"Pull to refresh",release:lang==="ur"?"تازہ کرنے کے لیے چھوڑ دیں":"Release to refresh",refreshing:L.refreshing,done:L.refreshed,error:L.refreshFailed};
  indicator.dataset.state=stateName;
  indicator.innerHTML = `<span class="pull-refresh-icon" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span>${escapeHTML(labels[stateName] || labels.pull)}</span>`;
  if(stateName === "done" || stateName === "error"){
    window.setTimeout(()=>{ if(indicator.dataset.state===stateName) indicator.remove(); }, 1300);
  }
  return indicator;
}

async function refreshLibrary({source="pull"}={}){
  if(refreshInFlight) return refreshInFlight;
  if(state.route === "reader") return;
  const startedAt=Date.now();
  const button=document.querySelector("#refreshBtn");
  refreshInFlight=(async()=>{
    if(button){ button.disabled=true; button.classList.add("is-spinning"); button.setAttribute("aria-busy","true"); }
    showRefreshIndicator("refreshing");
    try{
      const next=await loadLibraryData({force:true});
      data=next;
      state.dataReady=true;
      updateNetworkStatus(null);
      lastRenderedRoute="";
      await renderRouteOnce();
      const elapsed=Date.now()-startedAt;
      if(elapsed<500) await new Promise(r=>setTimeout(r,500-elapsed));
      showRefreshIndicator("done");
      return {ok:true};
    }catch(error){
      console.error("KR Urdu Library refresh failed",error);
      showRefreshIndicator("error");
      showToast(t[currentLang()].refreshFailed);
      return {ok:false,error};
    }finally{
      const currentButton=document.querySelector("#refreshBtn");
      if(currentButton){ currentButton.disabled=false; currentButton.classList.remove("is-spinning"); currentButton.removeAttribute("aria-busy"); }
      refreshInFlight=null;
    }
  })();
  return refreshInFlight;
}

function installPullToRefresh(){
  if(window.__krPullRefreshInstalled) return;
  window.__krPullRefreshInstalled=true;
  const clearPullRefreshState = (removeIndicator=true) => {
    refreshTracking=false;
    refreshPullDistance=0;
    if(refreshFailSafeTimer){ window.clearTimeout(refreshFailSafeTimer); refreshFailSafeTimer=null; }
    const indicator=document.querySelector(".pull-refresh-indicator");
    if(indicator){
      indicator.style.transform="translate(-50%, 0)";
      if(removeIndicator && indicator.dataset.state!=="refreshing") indicator.remove();
    }
  };
  const armFailSafe = () => {
    if(refreshFailSafeTimer) window.clearTimeout(refreshFailSafeTimer);
    refreshFailSafeTimer=window.setTimeout(()=>{
      if(refreshTracking) clearPullRefreshState(true);
    }, REFRESH_FAILSAFE_MS);
  };
  document.addEventListener("touchstart",e=>{
    if(state.route === "reader" || refreshInFlight || e.touches.length!==1) return;
    const touch=e.touches[0];
    if(window.scrollY>2) return;
    refreshTouchStartY=touch.clientY;
    refreshTouchStartX=touch.clientX;
    refreshPullDistance=0;
    refreshTracking=true;
    armFailSafe();
  },{passive:true});
  document.addEventListener("touchmove",e=>{
    if(!refreshTracking || state.route === "reader" || refreshInFlight || e.touches.length!==1) return;
    const touch=e.touches[0];
    const dy=touch.clientY-refreshTouchStartY;
    const dx=touch.clientX-refreshTouchStartX;
    if(dy<=0 || Math.abs(dx)>Math.abs(dy)*1.15){
      refreshTracking=false;
      return;
    }
    refreshPullDistance=Math.min(REFRESH_MAX,dy*0.55);
    const indicator=showRefreshIndicator(refreshPullDistance>=REFRESH_TRIGGER?"release":"pull");
    indicator.style.transform=`translate(-50%, ${Math.min(58,refreshPullDistance)}px)`;
    armFailSafe();
    if(refreshPullDistance>=12) e.preventDefault();
  },{passive:false});
  const finishPull = () => {
    if(!refreshTracking) return;
    const shouldRefresh=refreshPullDistance>=REFRESH_TRIGGER;
    clearPullRefreshState(!shouldRefresh);
    if(shouldRefresh) refreshLibrary({source:"pull"});
  };
  document.addEventListener("touchend",finishPull,{passive:true});
  document.addEventListener("touchcancel",()=>clearPullRefreshState(true),{passive:true});
  window.addEventListener("touchend",finishPull,{passive:true});
  window.addEventListener("touchcancel",()=>clearPullRefreshState(true),{passive:true});
}

let recentObserver = null;
let recentLoadInFlight = null;
let searchObserver = null;
let searchLoadInFlight = null;
let searchRequestToken = 0;

function setRecentLoader(page, lang, mode){
  const loader = page.querySelector('#recentLoader');
  const text = page.querySelector('#recentLoaderText');
  const retry = page.querySelector('#recentRetry');
  if(!loader || !text) return;
  loader.dataset.state = mode;
  text.textContent = mode === 'loading'
    ? (lang === 'ur' ? 'مزید کتب لوڈ ہو رہی ہیں…' : 'Loading more books…')
    : mode === 'done'
      ? (lang === 'ur' ? 'تمام کتب دکھا دی گئی ہیں۔' : 'All books loaded.')
      : mode === 'error'
        ? (lang === 'ur' ? 'مزید کتب لوڈ نہیں ہو سکیں۔' : 'Could not load more books.')
        : '';
  if(retry){
    retry.hidden = mode !== 'error';
    retry.disabled = mode === 'loading';
    retry.textContent = lang === 'ur' ? 'دوبارہ کوشش کریں' : 'Try again';
  }
}

function installRecentInfiniteScroll(page, lang){
  recentObserver?.disconnect();
  recentObserver = null;
  const sentinel = page.querySelector('#recentLoader');
  if(!sentinel) return;
  setRecentLoader(page, lang, 'idle');
  let appendNext;
  appendNext = async () => {
    if(recentLoadInFlight || !state.dataReady || state.route !== 'home' || !page.isConnected) return;
    recentLoadInFlight = (async () => {
      setRecentLoader(page, lang, 'loading');
      try {
        let result = null;
        // A page can contain only books already rendered (for example after a cache merge).
        // Advance a few pages in that case so the sentinel cannot silently stall.
        for(let attempt = 0; attempt < 5; attempt++){
          result = await loadNextBookPage();
          if(result.done || result.added.length) break;
        }
        if(state.route !== 'home' || !page.isConnected) return;
        const target = page.querySelector('#recent');
        if(!target || !result) return;
        result.added.forEach(book => {
          if(target.querySelector(`[data-book-id=\"${CSS.escape(String(book.id))}\"]`)) return;
          target.appendChild(bookCard(book, lang, (a,id)=>a==='book'?navigate('book',{id}):null));
        });
        if(result.done) {
          setRecentLoader(page, lang, 'done');
          recentObserver?.disconnect();
          recentObserver = null;
        } else {
          setRecentLoader(page, lang, 'idle');
          // If the sentinel is already visible, IntersectionObserver may not emit another
          // callback after the DOM mutation. Explicitly continue in that case.
          const rect = sentinel.getBoundingClientRect();
          if(rect.top <= window.innerHeight + 420 && !result.added.length) {
            setTimeout(() => appendNext(), 0);
          }
        }
      } catch(error) {
        console.error('KR Urdu Library recent pagination failed', error);
        setRecentLoader(page, lang, 'error');
      } finally { recentLoadInFlight = null; }
    })();
    return recentLoadInFlight;
  };
  const retry = page.querySelector('#recentRetry');
  retry?.addEventListener('click', () => {
    if(recentLoadInFlight || state.route !== 'home') return;
    appendNext();
  });
  recentObserver = new IntersectionObserver(entries => {
    if(entries.some(entry => entry.isIntersecting)) appendNext();
  }, { root:null, rootMargin:'0px 0px 420px 0px', threshold:0.01 });
  recentObserver.observe(sentinel);
}

function renderHome(){
  const lang=currentLang(), L=t[lang];
  const recent=(data.recentBooks || data.books);
  const historyBooks=getHistory().map(id=>data.byId?.get(id) || data.books.find(b=>b.id===id)).filter(Boolean).slice(0,3);
  const page=shell(L.brand, `<section class="hero"><span class="hero-kicker"><i class="fa-solid fa-book-open"></i> ${lang==="ur"?"کتب کا مطالعہ":"Your library"}</span><h1>${L.brand}</h1><p>${L.tagline}</p>
    <form class="search-box" id="searchForm"><span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span><input id="searchInput" autocomplete="off" enterkeyhint="search" aria-label="${L.search}" placeholder="${L.search}"></form>
    <div class="quick-actions" aria-label="${lang==="ur"?"فوری رسائی":"Quick access"}"><button class="quick-action" id="quickClasses"><i class="fa-solid fa-book-open"></i><span>${L.quickClasses}</span></button><button class="quick-action" id="quickCategories"><i class="fa-solid fa-layer-group"></i><span>${L.quickCategories}</span></button><button class="quick-action" id="quickFavorites"><i class="fa-solid fa-heart"></i><span>${L.quickFavorites}</span></button><button class="quick-action" id="quickHistory"><i class="fa-solid fa-clock-rotate-left"></i><span>${L.quickHistory}</span></button></div></section>
    ${historyBooks.length?`<section class="section continue-section"><div class="section-head"><div><h2 class="section-title">${L.continue}</h2><p class="section-subtitle">${lang==="ur"?"اپنی آخری کتاب سے دوبارہ شروع کریں":"Pick up where you left off"}</p></div></div><div class="grid" id="continue"></div></section>`:""}
    <section class="section"><div class="section-head"><div><h2 class="section-title">${L.classes}</h2><p class="section-subtitle">${lang==="ur"?"اپنی جماعت منتخب کریں":"Choose your class"}</p></div><a class="section-link" href="#classes">${L.browse}</a></div><div class="grid class-grid" id="classGrid"></div></section>
    <section class="section"><div class="section-head"><h2 class="section-title">${L.featured}</h2><a class="section-link" href="#catalogue">${L.allBooks}</a></div><div class="grid book-grid" id="featured"></div></section>
    <section class="section"><div class="section-head"><h2 class="section-title">${L.recent}</h2></div><div class="grid book-grid" id="recent"></div><div class="catalogue-loader" id="recentLoader" aria-live="polite"><span class="catalogue-loader-spinner" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span id="recentLoaderText"></span><button class="btn recent-retry" id="recentRetry" type="button" hidden></button></div></section>` ,"home");
  const cg=page.querySelector("#classGrid");
  const visibleClasses=data.classes.slice(0,6);
  visibleClasses.forEach((c,i)=>{
    const books=data.byClass?.get(c.id) || [];
    const completeCatalogue = getLibraryCacheInfo().complete;
    const stats = completeCatalogue ? {
      total: books.length,
      matn: books.filter(b=>b.bookType==="matn").length,
      sharah: books.filter(b=>b.bookType==="sharah").length
    } : null;
    const countText = stats
      ? `${stats.total} ${lang==="ur"?"کتب":"books"} · ${lang==="ur"?"متون":"Matn"} ${stats.matn} · ${lang==="ur"?"شروحات":"Commentary"} ${stats.sharah}`
      : `— ${lang==="ur"?"کتب":"books"}`;
    const el=document.createElement("button");
    el.className="class-card";
    el.dataset.classId=c.id;
    el.innerHTML=`<span class="class-number">${i+1}</span><strong>${escapeHTML(langName(c,lang))}</strong><small class="class-count">${countText}</small>`;
    el.onclick=()=>navigate("class",{id:c.id});
    cg.appendChild(el);
  });
  // Home initially loads only one catalogue page. Fetch authoritative class
  // counts separately so the cards never mistake the first 20 books for totals.
  loadClassStats().then(stats=>{
    if(!stats || !page.isConnected) return;
    page.querySelectorAll(".class-card[data-class-id]").forEach(card=>{
      const stat=stats[card.dataset.classId];
      if(!stat) return;
      const count=card.querySelector(".class-count");
      if(count) count.textContent=`${stat.total} ${lang==="ur"?"کتب":"books"} · ${lang==="ur"?"متون":"Matn"} ${stat.matn} · ${lang==="ur"?"شروحات":"Commentary"} ${stat.sharah}`;
    });
  }).catch(error=>console.warn('KR Urdu Library class stats unavailable.', error));
  if(historyBooks.length){ const target=page.querySelector("#continue"); historyBooks.forEach(b=>target.appendChild(progressCard(b,lang))); }
  const renderBooks=(selector,books)=>{ const target=page.querySelector(selector); if(!target)return; books.forEach(b=>target.appendChild(bookCard(b,lang,(a,id)=>a==="book"?navigate("book",{id}):null))); };
  renderBooks("#featured",data.books.slice(0,5)); renderBooks("#recent",recent);
  installRecentInfiniteScroll(page, lang);
  page.querySelector("#searchForm").onsubmit=e=>{e.preventDefault();const q=page.querySelector("#searchInput").value.trim();if(q)navigate("search",{q});};
  page.querySelector("#quickClasses").onclick=()=>navigate("classes"); page.querySelector("#quickCategories").onclick=()=>navigate("categories"); page.querySelector("#quickFavorites").onclick=()=>navigate("favorites"); page.querySelector("#quickHistory").onclick=()=>{ if(historyBooks.length) page.querySelector(".continue-section")?.scrollIntoView({behavior:"smooth",block:"start"}); else showToast(lang==="ur"?"ابھی مطالعہ کی تاریخ خالی ہے۔":"No recent reading yet."); };
}

function classShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="classBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="classSearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="classSearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="classSearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="classSearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="classSearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="classSearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

function categoryShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar category-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="categoryBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="categorySearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="categorySearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="categorySearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="categorySearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="categorySearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="categorySearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page category-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

function renderClass(id){
  const lang=currentLang(), L=t[lang], c=data.classes.find(x=>x.id===id); if(!c)return navigate("classes");
  const classBooks=data.byClass?.get(id) || data.books.filter(b=>(b.classIds||[b.classId]).includes(id));
  const routeParams=readRoute().params;
  const initialType=routeParams.type==="matn" || routeParams.type==="sharah" ? routeParams.type : null;
  const initialQuery=String(routeParams.q||"");
  const {page,header}=classShell(langName(c,lang), `<div class="class-intro"><div><h1 class="section-title">${escapeHTML(langName(c,lang))}</h1><div class="muted" id="classBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-book-open"></i></div></div><div class="actions discovery-filters" role="group" aria-label="${lang==="ur"?"کتب کی قسم":"Book type"}"><button class="btn active" id="all" aria-pressed="true"><i class="fa-solid fa-layer-group"></i> ${L.filterAll}</button><button class="btn" id="matn" aria-pressed="false"><i class="fa-solid fa-book-open"></i> ${L.filterMatn}</button><button class="btn" id="sharah" aria-pressed="false"><i class="fa-solid fa-book"></i> ${L.filterSharah}</button></div><section class="section class-books-section"><div class="section-head"><h2 class="section-title" id="bookHeading">${L.filterAll}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const filters=[...page.querySelectorAll(".discovery-filters .btn")];
  const searchInput=header.querySelector("#classSearchInput");
  const searchPanel=header.querySelector("#classSearchPanel");
  const searchToggle=header.querySelector("#classSearchToggle");
  const searchClear=header.querySelector("#classSearchClear");
  let searchTimer=0;
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams={id}; if(type)nextParams.type=type;
      replaceRoute("class",nextParams);
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open")) return;
    if(!history.state?.classSearchOpen){
      history.pushState({...history.state,classSearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true}); searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.classSearchOpen);
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams={id}; if(type)nextParams.type=type;
      replaceRoute("class",nextParams);
    }
    if(hadSearchHistory && history.length>1) history.back();
    else closeSearchPanel();
  };
  window.__krClassSearchClose = closeSearchPanel;
  const filtersType=()=>readRoute().params.type||initialType;
  const render=(type=initialType,{updateUrl=true,query=searchInput.value.trim()}={})=>{
    const normalizedQuery=query.trim();
    const scopedBooks=classBooks.filter(b=>!type||b.bookType===type);
    const books=searchBooks(scopedBooks,normalizedQuery);
    const target=page.querySelector("#books"); target.innerHTML="";
    filters.forEach(btn=>{const active=btn.id===(type||"all");btn.classList.toggle("active",active);btn.setAttribute("aria-pressed",String(active));});
    page.querySelector("#bookHeading").textContent=type==="matn"?L.filterMatn:type==="sharah"?L.filterSharah:L.filterAll;
    page.querySelector("#classBookCount").textContent=`${books.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams={id}; if(type)nextParams.type=type; if(normalizedQuery)nextParams.q=normalizedQuery;
      navigate("class",nextParams,{replace:true});
    }
    if(!books.length){target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-book-open"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noClassBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا فلٹر منتخب کر کے دیکھیں۔":"Try another filter or browse another class."))}</p></div>`;return;}
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,fromClass:id,type:type||"",q:normalizedQuery}):null)));
  };
  header.querySelector("#classBack").onclick=()=>{ if(searchPanel.classList.contains("is-open")){ closeSearchViaBack(); return; } goBackInApp(); };
  searchToggle.onclick=()=>{ if(searchPanel.classList.contains("is-open")) closeSearchViaBack(); else openSearchPanel(); };
  searchClear.onclick=()=>closeSearchViaBack();
  page.querySelector("#all").onclick=()=>render(null);
  page.querySelector("#matn").onclick=()=>render("matn");
  page.querySelector("#sharah").onclick=()=>render("sharah");
  header.querySelector("#classSearchForm").onsubmit=e=>{e.preventDefault();render(filtersType(),{query:searchInput.value});};
  searchInput.addEventListener("input",()=>{
    clearTimeout(searchTimer);
    searchTimer=setTimeout(()=>{
      const type=filtersType();
      const normalizedQuery=searchInput.value.trim();
      render(type,{updateUrl:false,query:searchInput.value});
      const nextParams={id}; if(type) nextParams.type=type; if(normalizedQuery) nextParams.q=normalizedQuery;
      replaceRoute("class",nextParams);
      if(searchPanel.classList.contains("is-open")) history.replaceState({...history.state,classSearchOpen:true},"",location.href);
    },180);
  });
  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialType,{updateUrl:false,query:initialQuery});
}

function renderCatalogue(){
  const lang=currentLang(), L=t[lang];
  const params=readRoute().params;
  const initialType=params.type==="matn" || params.type==="sharah" ? params.type : null;
  const initialQuery=String(params.q||"");
  const page=shell(L.catalogue, `<div class="catalogue-head"><div><button class="context-back" id="catalogueBack" type="button"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i><span>${L.back}</span></button><h1 class="section-title">${L.catalogue}</h1><p class="section-subtitle">${lang==="ur"?"لائبریری کی تمام دستیاب کتب ایک جگہ":"Browse the complete library catalogue in one place"}</p></div><span class="catalogue-count" id="catalogueCount"></span></div><form class="search-box contextual-search" id="catalogueSearchForm"><span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span><input id="catalogueSearchInput" value="${escapeHTML(initialQuery)}" autocomplete="off" enterkeyhint="search" aria-label="${L.search}" placeholder="${L.search}"></form><div class="actions discovery-filters" id="catalogueFilters" role="group" aria-label="${lang==="ur"?"کتب کی قسم":"Book type"}"><button class="btn active" data-type="all" aria-pressed="true"><i class="fa-solid fa-layer-group"></i> ${L.filterAll}</button><button class="btn" data-type="matn" aria-pressed="false"><i class="fa-solid fa-book-open"></i> ${L.filterMatn}</button><button class="btn" data-type="sharah" aria-pressed="false"><i class="fa-solid fa-book"></i> ${L.filterSharah}</button></div><div class="grid book-grid" id="catalogueBooks"></div><div class="catalogue-empty" id="catalogueEmpty" hidden></div>`, "home");
  const input=page.querySelector("#catalogueSearchInput");
  const filters=[...page.querySelectorAll("#catalogueFilters .btn")];
  const target=page.querySelector("#catalogueBooks");
  const empty=page.querySelector("#catalogueEmpty");
  const count=page.querySelector("#catalogueCount");
  const render=(type=initialType, query=input.value.trim(), updateUrl=true)=>{
    const normalized=query.trim();
    const scoped=(data.books||[]).filter(b=>!type||b.bookType===type);
    const books=searchBooks(scoped,normalized);
    target.innerHTML="";
    filters.forEach(btn=>{const active=btn.dataset.type===(type||"all");btn.classList.toggle("active",active);btn.setAttribute("aria-pressed",String(active));});
    count.textContent=`${books.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){const next={};if(type)next.type=type;if(normalized)next.q=normalized;replaceRoute("catalogue",next);}
    if(!books.length){
      empty.hidden=false;
      empty.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-book-open"></i><strong>${escapeHTML(normalized?L.noSearch:L.empty)}</strong><p>${escapeHTML(normalized?(lang==="ur"?`“${normalized}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalized}”.`):(lang==="ur"?"دستیاب کتب یہاں ظاہر ہوں گی۔":"Available books will appear here."))}</p></div>`;
      return;
    }
    empty.hidden=true;
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,id)=>a==="book"?navigate("book",{id,fromCatalogue:"1",type:type||"",q:normalized}):null)));
  };
  page.querySelector("#catalogueBack").onclick=()=>goBackInApp();
  filters.forEach(btn=>btn.onclick=()=>render(btn.dataset.type==="all"?null:btn.dataset.type));
  page.querySelector("#catalogueSearchForm").onsubmit=e=>{e.preventDefault();render(readRoute().params.type||initialType,input.value);};
  let timer=0;
  input.addEventListener("input",()=>{
    clearTimeout(timer);
    timer=setTimeout(()=>render(readRoute().params.type||initialType,input.value),160);
  });
  render(initialType,initialQuery,false);
}

function renderClasses(){
  const lang=currentLang(), L=t[lang], page=shell(L.classes,`<div class="discovery-head"><div><h1 class="section-title">${L.classes}</h1><p class="section-subtitle">${lang==="ur"?"اپنی جماعت منتخب کریں اور متعلقہ کتب دیکھیں":"Choose a class to browse its books"}</p></div><a class="section-link" href="#catalogue">${L.allBooks}</a></div><div class="grid class-grid" id="classes"></div>`,"classes");
  data.classes.forEach((c,i)=>{const count=(data.byClass?.get(c.id) || []).length;const el=document.createElement("button");el.className="class-card";el.innerHTML=`<span class="discovery-icon" aria-hidden="true"><i class="fa-solid fa-graduation-cap"></i></span><span class="class-number">${String(i+1).padStart(2,"0")}</span><strong>${escapeHTML(langName(c,lang))}</strong><small>${count} ${lang==="ur"?"کتب":"books"}</small>`;el.onclick=()=>navigate("class",{id:c.id});page.querySelector("#classes").appendChild(el);});
}
function renderCategories(){
  const lang=currentLang(), L=t[lang], page=shell(lang==="ur"?"زمرے":"Categories",`<h1 class="section-title">${lang==="ur"?"زمرے":"Categories"}</h1><div class="grid class-grid" id="cats"></div>`,"categories");
  const icons={"quran-tafseer":"fa-book-quran",hadith:"fa-book-open",fiqh:"fa-scale-balanced",aqeedah:"fa-star-and-crescent",seerah:"fa-landmark",history:"fa-clock-rotate-left","urdu-adab":"fa-feather-pointed"};
  data.categories.forEach(c=>{const count=(data.byCategory?.get(c.id) || []).length;const el=document.createElement("button");el.className="class-card";el.innerHTML=`<span class="discovery-icon" aria-hidden="true"><i class="fa-solid ${icons[c.id]||"fa-layer-group"}"></i></span><strong>${escapeHTML(langName(c,lang))}</strong><small>${count} ${lang==="ur"?"کتب":"books"}</small>`;el.onclick=()=>navigate("category",{id:c.id});page.querySelector("#cats").appendChild(el);});
}

function renderCategory(id){
  const lang=currentLang(),L=t[lang],c=data.categories.find(x=>x.id===id);
  if(!c)return navigate("categories");
  const books=data.byCategory?.get(id) || data.books.filter(b=>(b.categoryIds||[]).includes(id));
  const routeParams=readRoute().params,initialQuery=String(routeParams.q||"");
  const {page,header}=categoryShell(langName(c,lang),`<div class="class-intro category-intro"><div><h1 class="section-title">${escapeHTML(langName(c,lang))}</h1><div class="muted" id="categoryBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-layer-group"></i></div></div><section class="section category-books-section"><div class="section-head"><h2 class="section-title">${L.catalogue}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const searchInput=header.querySelector("#categorySearchInput");
  const searchPanel=header.querySelector("#categorySearchPanel");
  const searchToggle=header.querySelector("#categorySearchToggle");
  const searchClear=header.querySelector("#categorySearchClear");
  let timer=0;

  const baseParams=()=>({id});
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open"))return;
    if(!history.state?.categorySearchOpen){
      history.pushState({...history.state,categorySearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true});searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.categorySearchOpen);
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
    if(hadSearchHistory && history.length>1)history.back();
    else closeSearchPanel();
  };
  window.__krCategorySearchClose=closeSearchPanel;

  const render=(query=searchInput.value.trim(),updateUrl=true)=>{
    const normalizedQuery=query.trim(),filtered=searchBooks(books,normalizedQuery),target=page.querySelector("#books");
    target.innerHTML="";
    page.querySelector("#categoryBookCount").textContent=`${filtered.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      navigate("category",nextParams,{replace:true});
    }
    if(!filtered.length){
      target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-layer-group"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noCategoryBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا زمرہ منتخب کر کے دیکھیں۔":"Browse another category to find more books."))}</p></div>`;
      return;
    }
    filtered.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,fromCategory:id,q:normalizedQuery}):null)));
  };

  header.querySelector("#categoryBack").onclick=()=>{
    if(searchPanel.classList.contains("is-open")){closeSearchViaBack();return;}
    goBackInApp();
  };
  searchToggle.onclick=()=>{
    if(searchPanel.classList.contains("is-open"))closeSearchViaBack();
    else openSearchPanel();
  };
  searchClear.onclick=()=>closeSearchViaBack();
  header.querySelector("#categorySearchForm").onsubmit=e=>{e.preventDefault();render(searchInput.value);};
  searchInput.addEventListener("input",()=>{
    clearTimeout(timer);
    timer=setTimeout(()=>{
      const normalizedQuery=searchInput.value.trim();
      render(searchInput.value,false);
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      replaceRoute("category",nextParams);
      if(searchPanel.classList.contains("is-open"))history.replaceState({...history.state,categorySearchOpen:true},"",location.href);
    },180);
  });

  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialQuery,false);
}
function renderSearch(q){
  const lang=currentLang(),L=t[lang];
  const page=shell(L.searchResults,`<button class="context-back" id="searchBack" type="button"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i><span>${L.back}</span></button><section class="search-page-head"><form class="search-box" id="searchForm"><span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span><input id="searchInput" value="${escapeHTML(q)}" autocomplete="off" enterkeyhint="search" aria-label="${L.search}" placeholder="${L.search}"></form><div class="section-head search-summary"><div><h1 class="section-title">${L.searchResults}</h1><p class="section-subtitle" id="searchSummary">${lang==="ur"?"نتائج تلاش کی جا رہی ہیں…":"Searching…"}</p></div></div></section><div class="grid book-grid" id="books"></div><div class="catalogue-loader" id="searchLoader" aria-live="polite"><span class="catalogue-loader-spinner" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span id="searchLoaderText"></span></div>` ,"home");
  searchObserver?.disconnect(); searchObserver=null;
  page.querySelector("#searchBack").onclick=()=>goBackInApp();
  page.querySelector("#searchForm").onsubmit=e=>{e.preventDefault();const next=page.querySelector("#searchInput").value.trim();if(next)navigate("search",{q:next});};
  if(!q){ page.querySelector("#searchSummary").textContent=lang==="ur"?"تلاش کے لیے اوپر لکھیں":"Enter a search above"; return; }

  const token=++searchRequestToken;
  const target=page.querySelector("#books");
  const loader=page.querySelector("#searchLoader");
  const loaderText=page.querySelector("#searchLoaderText");
  const setLoader=(mode)=>{
    if(!loader||!loaderText)return;
    loader.dataset.state=mode;
    loaderText.textContent=mode==="loading"?(lang==="ur"?"مزید نتائج لوڈ ہو رہے ہیں…":"Loading more results…"):
      mode==="done"?(lang==="ur"?"تمام نتائج دکھا دیے گئے ہیں۔":"All matching results loaded."):
      mode==="error"?(lang==="ur"?"نتائج لوڈ نہیں ہو سکے۔ دوبارہ کوشش کریں۔":"Could not load search results. Try again."):"";
  };
  const updateSummary=(count)=>{
    page.querySelector("#searchSummary").textContent = `${count}${count===20?"+":""} ${lang==="ur"?"کتب":"books"}`;
  };
  const loadMore=async()=>{
    if(token!==searchRequestToken || searchLoadInFlight || state.route!=="search" || !page.isConnected)return;
    searchLoadInFlight=(async()=>{
      setLoader("loading");
      try{
        let result;
        try{
          result=await searchBooksPage(q,{pageSize:20});
        }catch(remoteError){
          console.warn("KR Urdu Library server search unavailable; using cached catalogue.",remoteError);
          const fallback=searchBooks(data.books,q).slice(0,20);
          result={results:fallback,done:true};
        }
        if(token!==searchRequestToken || !page.isConnected)return;
        if(result.results?.length){
          mergeBooksIntoLibrary(result.results);
          const freshResults=searchBooks(result.results,q);
          freshResults.forEach(b=>target.appendChild(bookCard(b,lang,(a,id)=>a==="book"?navigate("book",{id}):null)));
        }
        const count=target.querySelectorAll(".book-card").length;
        updateSummary(count);
        if(!count && result.done){
          target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-magnifying-glass"></i><strong>${escapeHTML(L.noSearch)}</strong><p>${escapeHTML(lang==="ur"?`“${q}” کے لیے کوئی نتیجہ نہیں ملا۔ ${L.noSearchHint}`:`No results for “${q}”. ${L.noSearchHint}`)}</p></div>`;
        }
        if(result.done){
          setLoader("done"); searchObserver?.disconnect(); searchObserver=null;
        }else setLoader("idle");
      }catch(error){
        console.error("KR Urdu Library search failed",error);
        setLoader("error");
        const retry=()=>loadMore();
        loader?.addEventListener("click",retry,{once:true});
      }finally{searchLoadInFlight=null;}
    })();
    return searchLoadInFlight;
  };
  searchObserver=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting))loadMore();},{root:null,rootMargin:"0px 0px 500px 0px",threshold:0.01});
  searchObserver.observe(loader);
  loadMore();
}

function renderFavorites(){
  const lang=currentLang(),L=t[lang],ids=new Set(getFavorites()),books=data.books.filter(b=>ids.has(b.id)),page=shell(t[lang].fav,`<h1 class="section-title">${t[lang].fav}</h1><div class="grid book-grid" id="books"></div>`,"favorites");
  const target=page.querySelector("#books");
  const emptyMarkup=()=>`<div class="empty contextual-empty"><i class="fa-regular fa-heart"></i><strong>${escapeHTML(L.noFavorites)}</strong><p>${escapeHTML(lang==="ur"?"کتاب پر دل کے آئیکن سے اسے یہاں محفوظ کریں۔":"Tap the heart on a book to save it here.")}</p></div>`;
  if(!books.length){target.innerHTML=emptyMarkup();return;}
  books.forEach(b=>{
    const card=bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x}):null);
    card.addEventListener("favoritechange",e=>{
      if(e.detail?.favorite) return;
      card.remove();
      if(!target.querySelector(".book-card")) target.innerHTML=emptyMarkup();
    });
    target.appendChild(card);
  });
}
function getRelatedBooks(book, limit = 4){
  const classIds = new Set(Array.isArray(book.classIds) ? book.classIds : (book.classId ? [book.classId] : []));
  const categoryIds = new Set(Array.isArray(book.categoryIds) ? book.categoryIds : []);
  return data.books
    .filter(candidate => candidate.id !== book.id && candidate.status === "available")
    .map(candidate => {
      const candidateClasses = Array.isArray(candidate.classIds) ? candidate.classIds : (candidate.classId ? [candidate.classId] : []);
      const candidateCategories = Array.isArray(candidate.categoryIds) ? candidate.categoryIds : [];
      let score = 0;
      if (candidateClasses.some(id => classIds.has(id))) score += 4;
      if (candidateCategories.some(id => categoryIds.has(id))) score += 3;
      if (candidate.bookType === book.bookType) score += 1;
      return { candidate, score };
    })
    .filter(item => item.score > 0)
    .sort((a,b) => b.score - a.score || String(b.candidate.addedAt || "").localeCompare(String(a.candidate.addedAt || "")))
    .slice(0, limit)
    .map(item => item.candidate);
}

function renderBook(id){
  const lang=currentLang(),L=t[lang],b=data.byId?.get(id) || data.books.find(x=>x.id===id);if(!b)return navigate("home");
  const title=lang==="ur"?b.title:(b.titleEn||b.title), fav=getFavorites().includes(b.id), progress=getBookProgress(b.id);
  const percent=Math.max(0,Math.min(100,Number(progress?.percent)||0));
  const hasPdf=b.status==="available" && (validExternalUrl(b.pdfUrl) || Boolean(b.driveFileId)), hasSource=validExternalUrl(b.source?.pageUrl);
  const meta=[
    `<span class="pill"><i class="fa-regular fa-file-pdf"></i> PDF</span>`,
    b.pages?`<span class="pill"><i class="fa-regular fa-file-lines"></i> ${escapeHTML(formatPages(b.pages,lang))}</span>`:"",
    `<span class="pill ${b.status==="available"?"pill-available":"pill-unavailable"}"><i class="fa-solid fa-circle"></i> ${b.status==="available"?L.available:L.unavailable}</span>`
  ].filter(Boolean).join("");
  const resume=progress?.openedAt?`<div class="book-progress" aria-label="${lang==="ur"?`${percent}% مطالعہ مکمل`:`${percent}% read`}"><div class="book-progress-head"><span><i class="fa-solid fa-clock-rotate-left"></i> ${lang==="ur"?"مطالعہ کی پیش رفت":"Reading progress"}</span><strong>${percent}%</strong></div><div class="book-progress-track"><span style="width:${percent}%"></span></div><button class="progress-action" id="resume">${L.continueAction} <i class="fa-solid ${lang==="ur"?"fa-arrow-left":"fa-arrow-right"}"></i></button></div>`:"";
  const related=getRelatedBooks(b,4);
  const relatedMarkup=related.length ? `<section class="detail-section related-books-section"><div class="section-head"><div><h2 class="section-title">${L.related}</h2><p class="section-subtitle">${L.relatedHint}</p></div></div><div class="grid book-grid related-books-grid" id="relatedBooks"></div></section>` : "";
  const downloadNote=!hasPdf ? `<p class="action-note" role="status"><i class="fa-solid fa-circle-info"></i> ${escapeHTML(L.sourceMissing)}</p>` : "";
  const page=shell(title,`<button class="context-back" id="bookBack" type="button"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i><span>${L.back}</span></button><article class="book-detail"><div class="book-detail-main"><div class="detail-cover-wrap"><div class="detail-cover">${coverMarkup(b.cover?escapeHTML(b.cover):"",`${escapeHTML(title)} cover`)}</div></div><div class="book-detail-info"><h1 class="detail-title">${escapeHTML(title)}</h1><p class="detail-author">${escapeHTML(b.author||"")}</p><div class="chips" aria-label="${lang==="ur"?"کتاب کی معلومات":"Book information"}">${meta}</div>${resume}<div class="detail-actions"><button class="btn primary" id="read" ${b.status!=="available"?"disabled":""}><i class="fa-solid fa-book-open"></i> ${L.read}</button><button class="btn" id="download" ${!hasPdf?"disabled":""}><i class="fa-solid fa-download"></i> ${L.download}</button></div>${downloadNote}<button class="btn detail-favorite ${fav?"active":""}" id="fav" aria-pressed="${fav}"><i class="fa-${fav?"solid":"regular"} fa-heart"></i><span>${L.fav}</span></button></div></div><div class="book-detail-sections"><section class="detail-section"><h2 class="section-title">${L.about}</h2><p class="muted">${escapeHTML(b.description||"")}</p></section>${relatedMarkup}<section class="detail-section"><h2 class="section-title">${L.source}</h2>${b.source?.name?`<p class="source-name">${escapeHTML(b.source.name)}</p>`:""}${hasSource?`<button class="btn" id="source"><i class="fa-solid fa-arrow-up-right-from-square"></i> ${L.openSource}</button>`:`<p class="muted source-unavailable">${lang==="ur"?"اصل ماخذ دستیاب نہیں ہے۔":"Original source is not available."}</p>`}</section><section class="detail-section detail-report"><button class="btn danger" id="report"><i class="fa-solid fa-triangle-exclamation"></i> ${L.report}</button></section></div></article>`,"");
  page.classList.add("book-detail-page");
  page.querySelector("#bookBack")?.addEventListener("click",()=>goBackInApp());
  wireCover(page.querySelector(".detail-cover"));
  // Book details are a fresh view: never inherit a previous document scroll position.
  requestAnimationFrame(() => window.scrollTo({ top: 0, left: 0, behavior: "auto" }));
  page.querySelector("#read").onclick=()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});navigate("reader",{id});};
  page.querySelector("#resume")?.addEventListener("click",()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});navigate("reader",{id});});
  page.querySelector("#download")?.addEventListener("click",async()=>{
    await downloadBookPdf(b);
  });
  hasCachedPdf(b.id).then(cached=>{
    if(!cached || !page.isConnected) return;
    const actions=page.querySelector(".detail-actions");
    if(!actions || actions.querySelector(".cached-book-badge")) return;
    const badge=document.createElement("span");
    badge.className="cached-book-badge";
    badge.setAttribute("role","status");
    badge.innerHTML='<i class="fa-solid fa-cloud-arrow-down"></i> '+escapeHTML(lang==="ur"?"آف لائن مطالعے کے لیے محفوظ":"Saved for offline reading");
    actions.appendChild(badge);
  });
  page.querySelector("#fav").onclick=()=>{
    const was=fav;
    const result=toggleFavorite(id);
    const nowFavorite=Array.isArray(result) ? result.includes(id) : Boolean(result);
    const button=page.querySelector("#fav");
    button.classList.toggle("active",nowFavorite);
    button.setAttribute("aria-pressed",String(nowFavorite));
    const icon=button.querySelector("i");
    if(icon){icon.classList.toggle("fa-solid",nowFavorite);icon.classList.toggle("fa-regular",!nowFavorite);}
    showToast(was?L.favoriteRemoved:L.favoriteAdded);
  };
  page.querySelector("#source")?.addEventListener("click",()=>openExternal(b.source.pageUrl));
  page.querySelector("#report").onclick=()=>showToast(L.reportSoon);
  if(related.length){
    const target=page.querySelector("#relatedBooks");
    related.forEach(book=>target.appendChild(bookCard(book,lang,(action,id)=>action==="book"?navigate("book",{id}):null)));
  }
}

function renderMore(){
  const lang=currentLang(),L=t[lang],theme=state.theme;
  const catalogueInfo=getLibraryCacheInfo();
  const catalogueLabel=catalogueInfo.source==="supabase" ? L.catalogueOnline : catalogueInfo.source==="persistent-cache" ? L.catalogueCache : L.catalogueFallback;
  const catalogueCompleteness=catalogueInfo.complete ? L.catalogueComplete : L.cataloguePartial;
  const favorites=getFavorites().length;
  const history=getHistory().length;
  const page=shell(L.more,`<div class="more-dashboard">
    <section class="more-hero" aria-labelledby="moreTitle">
      <div class="more-hero-copy">
        <span class="more-eyebrow"><i class="fa-solid fa-sliders"></i> ${escapeHTML(L.more)}</span>
        <h1 id="moreTitle">${escapeHTML(L.brand)}</h1>
        <p>${escapeHTML(L.moreIntro)}</p>
      </div>
      <div class="more-hero-mark" aria-hidden="true"><i class="fa-solid fa-book-open"></i></div>
    </section>

    <section class="more-section" aria-labelledby="quickSettingsTitle">
      <div class="more-section-head"><div><h2 id="quickSettingsTitle">${escapeHTML(L.quickSettings)}</h2></div></div>
      <div class="quick-settings-grid">
        <div class="quick-setting-card">
          <div class="quick-setting-icon"><i class="fa-solid fa-circle-half-stroke"></i></div>
          <div class="quick-setting-copy"><strong>${escapeHTML(L.appearanceShort)}</strong><span>${escapeHTML(theme==="system"?L.systemTheme:theme==="dark"?L.darkTheme:L.lightTheme)}</span></div>
          <div class="quick-setting-options" role="group" aria-label="${escapeHTML(L.appearanceShort)}">
            <button type="button" class="setting-chip ${theme==="system"?"active":""}" data-theme="system">${escapeHTML(L.systemTheme)}</button>
            <button type="button" class="setting-chip ${theme==="light"?"active":""}" data-theme="light">${escapeHTML(L.lightTheme)}</button>
            <button type="button" class="setting-chip ${theme==="dark"?"active":""}" data-theme="dark">${escapeHTML(L.darkTheme)}</button>
          </div>
        </div>
        <div class="quick-setting-card">
          <div class="quick-setting-icon"><i class="fa-solid fa-language"></i></div>
          <div class="quick-setting-copy"><strong>${escapeHTML(L.languageShort)}</strong><span>${lang==="ur"?"اردو":"English"}</span></div>
          <div class="quick-setting-options" role="group" aria-label="${escapeHTML(L.languageShort)}">
            <button type="button" class="setting-chip ${lang==="ur"?"active":""}" id="ur">اردو</button>
            <button type="button" class="setting-chip ${lang==="en"?"active":""}" id="en">English</button>
          </div>
        </div>
      </div>
    </section>

    <section class="more-section" aria-labelledby="librarySectionTitle">
      <div class="more-section-head"><h2 id="librarySectionTitle">${escapeHTML(L.librarySection)}</h2></div>
      <div class="more-card-list">
        <button class="more-action-card" id="openCatalogue" type="button">
          <span class="more-action-icon"><i class="fa-solid fa-book-open"></i></span>
          <span class="more-action-copy"><strong>${escapeHTML(L.catalogue)}</strong><small>${catalogueInfo.books} ${escapeHTML(L.catalogueCount)} · ${escapeHTML(catalogueLabel)} · ${escapeHTML(catalogueCompleteness)}</small></span>
          <i class="fa-solid fa-chevron-${lang==="ur"?"left":"right"} more-action-arrow" aria-hidden="true"></i>
        </button>
      </div>
    </section>

    <section class="more-section" aria-labelledby="personalSectionTitle">
      <div class="more-section-head"><h2 id="personalSectionTitle">${escapeHTML(L.personalSection)}</h2></div>
      <div class="personal-shortcuts">
        <button class="personal-card" id="openFavorites" type="button"><span class="personal-icon favorite"><i class="fa-solid fa-heart"></i></span><strong>${escapeHTML(L.favouritesCount)}</strong><small>${favorites} ${escapeHTML(L.catalogueCount)}</small></button>
        <button class="personal-card" id="openRecent" type="button"><span class="personal-icon recent"><i class="fa-solid fa-clock-rotate-left"></i></span><strong>${escapeHTML(L.recentCount)}</strong><small>${history} ${escapeHTML(L.catalogueCount)}</small></button>
      </div>
    </section>

    <section class="more-section" aria-labelledby="offlineSectionTitle">
      <div class="more-section-head"><h2 id="offlineSectionTitle">${escapeHTML(L.offlineSection)}</h2></div>
      <div class="storage-card">
        <div class="storage-card-top"><span class="storage-icon"><i class="fa-solid fa-hard-drive"></i></span><div><strong>${escapeHTML(L.savedBooks)}</strong><small id="pdfCacheSummary">${lang==="ur"?"محفوظ شدہ کتب چیک کی جا رہی ہیں…":"Checking saved offline books…"}</small></div></div>
        <div class="storage-meter" aria-hidden="true"><span id="pdfCacheMeter" style="width:0%"></span></div>
        <div class="storage-card-footer"><span id="pdfCacheUsage">${escapeHTML(L.storageUsed)}</span><button class="text-danger-action" id="clearOffline" type="button"><i class="fa-solid fa-trash-can"></i> ${escapeHTML(L.clearOfflineShort)}</button></div>
      </div>
    </section>

    <section class="more-section more-collapsible-section" aria-labelledby="dataSectionTitle">
      <button class="more-collapse-toggle" id="dataSectionToggle" type="button" aria-expanded="false" aria-controls="dataSectionPanel"><span><i class="fa-solid fa-database"></i><strong id="dataSectionTitle">${escapeHTML(L.dataSection)}</strong></span><i class="fa-solid fa-chevron-down collapse-chevron" aria-hidden="true"></i></button>
      <div class="more-collapse-panel" id="dataSectionPanel" hidden>
        <p class="muted">${escapeHTML(lang==="ur"?"پسندیدہ، مطالعہ کی تاریخ اور پیش رفت اسی ڈیوائس پر محفوظ ہوتی ہے۔":"Favorites, reading history and progress are stored locally on this device.")}</p>
        <div class="data-actions">
          <button class="btn" id="clearHistory" type="button"><i class="fa-solid fa-clock-rotate-left"></i> ${escapeHTML(L.clearHistoryShort)}</button>
          <button class="btn danger" id="clearData" type="button"><i class="fa-solid fa-trash"></i> ${escapeHTML(L.clearDataShort)}</button>
        </div>
      </div>
    </section>

    <section class="more-info-list" aria-label="${escapeHTML(L.more)}">
      <button class="more-info-row" id="openRights" type="button"><span><i class="fa-solid fa-scale-balanced"></i><strong>${escapeHTML(L.sourceRightsShort)}</strong></span><i class="fa-solid fa-chevron-${lang==="ur"?"left":"right"}" aria-hidden="true"></i></button>
      <button class="more-info-row" id="openAbout" type="button"><span><i class="fa-solid fa-circle-info"></i><strong>${escapeHTML(L.aboutApp)}</strong></span><i class="fa-solid fa-chevron-${lang==="ur"?"left":"right"}" aria-hidden="true"></i></button>
    </section>

    <footer class="more-footer"><strong>${escapeHTML(L.brand)}</strong><span>${escapeHTML(L.tagline)}</span></footer>
  </div>`,"more");
  page.classList.add("more-page");

  page.querySelectorAll("[data-theme]").forEach(b=>b.onclick=()=>{state.theme=b.dataset.theme;changeTheme(state.theme);render();});
  page.querySelector("#ur").onclick=()=>{state.language="ur";setLanguage("ur");render();};
  page.querySelector("#en").onclick=()=>{state.language="en";setLanguage("en");render();};
  page.querySelector("#openCatalogue").onclick=()=>navigate("catalogue");
  page.querySelector("#openFavorites").onclick=()=>navigate("favorites");
  page.querySelector("#openRecent").onclick=()=>navigate("home");
  page.querySelector("#openRights").onclick=()=>showInfoSheet(
    lang==="ur"?"ذرائع اور حقوق":"Sources & Rights",
    lang==="ur"?"ہر کتاب کے اصل ماخذ کو جہاں ممکن ہو نمایاں کیا جاتا ہے۔ مواد کو خودکار طور پر دوبارہ ہوسٹ نہیں کیا جاتا۔":"Each listing identifies its original source where available. Content is linked from external sources rather than automatically re-hosted."
  );
  page.querySelector("#openAbout").onclick=()=>showInfoSheet(L.aboutApp,L.tagline);

  const toggle=page.querySelector("#dataSectionToggle"), panel=page.querySelector("#dataSectionPanel");
  toggle.onclick=()=>{const open=toggle.getAttribute("aria-expanded")==="true";toggle.setAttribute("aria-expanded",String(!open));panel.hidden=open;toggle.classList.toggle("open",!open);};

  page.querySelector("#clearHistory").onclick=async()=>{const ok=await confirmDialog(L.clearHistory,lang==="ur"?"اس ڈیوائس سے مطالعہ کی تاریخ صاف کر دی جائے؟":"Clear reading history from this device?",lang==="ur"?"صاف کریں":"Clear",true);if(ok){clearHistory();showToast(L.historyCleared);render();}};
  page.querySelector("#clearData").onclick=async()=>{const ok=await confirmDialog(L.clearData,L.confirmClear,lang==="ur"?"سب صاف کریں":"Clear all",true);if(ok){localStorage.removeItem("krul:v1:favorites");clearHistory();clearProgress();showToast(L.dataCleared);render();}};

  getPdfCacheInfo().then(info=>{
    if(!page.isConnected)return;
    const summary=page.querySelector("#pdfCacheSummary"),usage=page.querySelector("#pdfCacheUsage"),meter=page.querySelector("#pdfCacheMeter");
    if(!summary)return;
    const bytes=Number(info.bytes||0),mb=(bytes/(1024*1024)).toFixed(1),max=Number(info.maxBytes||512*1024*1024),percent=Math.max(0,Math.min(100,(bytes/max)*100));
    summary.textContent=lang==="ur"?`${info.count} ${info.count===1?"محفوظ شدہ کتاب":"محفوظ شدہ کتب"} · ${mb} MB`: `${info.count} saved ${info.count===1?"book":"books"} · ${mb} MB`;
    if(usage)usage.textContent=lang==="ur"?`${mb} MB / 512 MB`:`${mb} MB / 512 MB`;
    if(meter)meter.style.width=`${percent}%`;
  });
  page.querySelector("#clearOffline").onclick=async()=>{
    const ok=await confirmDialog(L.clearOffline,lang==="ur"?"اس ڈیوائس سے تمام محفوظ شدہ آف لائن کتب حذف کر دی جائیں؟":"Delete all saved offline books from this device?",lang==="ur"?"حذف کریں":"Delete",true);
    if(!ok)return;
    const cleared=await clearPdfCache();
    showToast(cleared?(lang==="ur"?"محفوظ شدہ آف لائن کتب صاف ہوگئیں۔":"Saved offline books cleared."):(lang==="ur"?"آف لائن کیش صاف نہیں ہو سکی۔":"Could not clear offline cache."));
    render();
  };
}

function formatBytes(n){
  n=Number(n)||0;
  if(n>=1073741824)return (n/1073741824).toFixed(1)+" GB";
  if(n>=1048576)return (n/1048576).toFixed(1)+" MB";
  if(n>=1024)return Math.round(n/1024)+" KB";
  return n+" B";
}
function formatSavedDate(ts,lang){
  try{return new Date(ts).toLocaleDateString(lang==="ur"?"ur-PK":"en-GB",{day:"numeric",month:"short",year:"numeric"});}catch{return "";}
}

function renderDownloads(){
  const lang=currentLang(), ur=lang==="ur";
  const T=ur?{
    title:"ڈاؤنلوڈز", intro:"جو کتابیں آپ نے اس ایپ سے ڈاؤنلوڈ کی ہیں، وہ یہاں ملیں گی اور آف لائن پڑھی جا سکتی ہیں۔",
    emptyTitle:"ابھی کوئی ڈاؤنلوڈ نہیں", emptyText:"کسی کتاب کا ڈاؤنلوڈ بٹن دبائیں، وہ یہاں نظر آئے گی۔",
    missing:"فائل نہیں ملی", del:"حذف کریں", delTitle:"فائل حذف کریں؟", delMsg:"یہ کتاب آپ کے فون کے ڈاؤنلوڈز فولڈر سے بھی حذف ہو جائے گی۔",
    deleted:"کتاب حذف ہوگئی۔", again:"دوبارہ ڈاؤنلوڈ کریں", againMsg:"یہ فائل فون میں موجود نہیں۔ کیا دوبارہ ڈاؤنلوڈ کریں؟",
    androidOnly:"ڈاؤنلوڈز کی فہرست صرف اینڈرائیڈ ایپ میں کام کرتی ہے۔"
  }:{
    title:"Downloads", intro:"Books you download from this app appear here and can be read offline.",
    emptyTitle:"No downloads yet", emptyText:"Tap Download on any book and it will show up here.",
    missing:"File not found", del:"Delete", delTitle:"Delete this file?", delMsg:"The book will also be removed from your phone's Downloads folder.",
    deleted:"Book deleted.", again:"Download again", againMsg:"This file is no longer on your phone. Download it again?",
    androidOnly:"The downloads list works in the Android app only."
  };
  const records=getDownloads();
  const cards=records.map(rec=>{
    const b=data.books.find(x=>x.id===rec.bookId);
    const name=ur?(b?.title||rec.title):(b?.titleEn||rec.titleEn||b?.title||rec.title);
    const author=ur?(b?.author||rec.author):(b?.authorEn||rec.authorEn||b?.author||rec.author);
    const cover=b?.cover||rec.cover||"";
    return `<article class="dl-card" data-book="${escapeHTML(rec.bookId)}">
      <button class="dl-main" type="button" data-read="${escapeHTML(rec.bookId)}">
        <div class="book-cover dl-cover">${coverMarkup(cover?escapeHTML(cover):"")}</div>
        <div class="dl-info">
          <strong>${escapeHTML(name||"")}</strong>
          <span>${escapeHTML(author||"")}</span>
          <small class="dl-meta">${escapeHTML(formatBytes(rec.size))} · ${escapeHTML(formatSavedDate(rec.savedAt,lang))}</small>
          <small class="dl-state" data-state></small>
        </div>
      </button>
      <button class="icon-btn dl-delete" type="button" data-delete="${escapeHTML(rec.bookId)}" aria-label="${T.del}" title="${T.del}"><i class="fa-solid fa-trash-can"></i></button>
    </article>`;
  }).join("");
  const empty=`<div class="dl-empty"><i class="fa-solid fa-download"></i><strong>${T.emptyTitle}</strong><span>${T.emptyText}</span></div>`;
  const page=shell(T.title,`<section class="dl-page">
    <div class="dl-head"><h1>${T.title}</h1><p>${T.intro}</p></div>
    ${records.length?`<div class="dl-list">${cards}</div>`:empty}
  </section>`,"downloads");
  page.querySelectorAll(".dl-cover").forEach(wireCover);

  const plugin=getNativePlugin();
  const missing=new Set();
  if(plugin){
    records.forEach(async rec=>{
      try{
        const info=await plugin.fileInfo({id:rec.downloadId});
        if(info?.exists)return;
        const card=page.querySelector(`.dl-card[data-book="${CSS.escape(rec.bookId)}"]`);
        if(!card)return;
        missing.add(rec.bookId);
        card.classList.add("is-missing");
        card.querySelector("[data-state]").textContent=T.missing;
      }catch{}
    });
  }else if(records.length){
    showToast(T.androidOnly);
  }

  page.querySelectorAll("[data-read]").forEach(btn=>btn.onclick=async()=>{
    const id=btn.dataset.read;
    if(missing.has(id)){
      const b=data.books.find(x=>x.id===id);
      if(!b){removeDownloadRecord(id);render();return;}
      const ok=await confirmDialog(T.missing,T.againMsg,T.again,false);
      if(ok)downloadBookPdf(b);
      return;
    }
    navigate("local",{book:id});
  });
  page.querySelectorAll("[data-delete]").forEach(btn=>btn.onclick=async()=>{
    const id=btn.dataset.delete;
    const rec=getDownloadRecord(id);
    if(!rec)return;
    const ok=await confirmDialog(T.delTitle,T.delMsg,T.del,true);
    if(!ok)return;
    try{await plugin?.deleteDownload({id:rec.downloadId});}catch{}
    removeDownloadRecord(id);
    showToast(T.deleted);
    render();
  });
}

function renderLocal(params){
  const lang=currentLang();
  if(params.book){
    const rec=getDownloadRecord(params.book);
    if(!rec)return navigate("downloads",{},{replace:true});
    const b=data.books.find(x=>x.id===rec.bookId);
    const title=lang==="ur"?(b?.title||rec.title):(b?.titleEn||rec.titleEn||b?.title||rec.title);
    if(b)addHistory(b.id);
    return renderLocalReader(app,{lang,title,source:{id:rec.downloadId},progressKey:rec.bookId});
  }
  if(params.uri){
    const name=(params.name||"PDF").replace(/\.pdf$/i,"");
    return renderLocalReader(app,{lang,title:name,source:{uri:params.uri},progressKey:`file:${name}`});
  }
  navigate("downloads",{},{replace:true});
}

// "Open with" -> another app (file manager, WhatsApp...) handed us a PDF.
async function checkPendingOpen(){
  const plugin=getNativePlugin();
  if(!plugin)return;
  try{
    const res=await plugin.getPendingOpen();
    if(res?.uri)navigate("local",{uri:res.uri,name:res.name||"PDF"});
  }catch{}
}
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")checkPendingOpen();});

function showInfoSheet(title,message){
  const lang=currentLang();
  const existing=document.querySelector(".more-info-dialog");
  existing?.remove();
  const dialog=document.createElement("div");
  dialog.className="more-info-dialog";
  dialog.innerHTML=`<div class="more-info-dialog-backdrop" data-close></div><section class="more-info-dialog-panel" role="dialog" aria-modal="true" aria-labelledby="moreInfoTitle"><div class="more-info-dialog-head"><h2 id="moreInfoTitle">${escapeHTML(title)}</h2><button class="icon-btn" type="button" data-close aria-label="${escapeHTML(lang==="ur"?"بند کریں":"Close")}"><i class="fa-solid fa-xmark"></i></button></div><p>${escapeHTML(message)}</p></section>`;
  document.body.appendChild(dialog);
  const close=()=>dialog.remove();
  dialog.querySelectorAll("[data-close]").forEach(el=>el.addEventListener("click",close));
  requestAnimationFrame(()=>dialog.classList.add("is-open"));
}

let readerCleanup = null;
async function loadReaderPdfJs(){ return loadPdfJs(); }


async function downloadBookPdf(book){
  const title=(book?.titleEn||book?.title||"KR Urdu Library Book")
    .replace(/[\\/:*?"<>|]/g," ")
    .replace(/\s+/g," ")
    .trim()
    .replace(/[. ]+$/g,"") || "KR Urdu Library Book";
  const filename=`${title}.pdf`;
  // The gateway owns the final .pdf extension. Sending the extension again can
  // produce names such as "Book.pdf.pdf" when Content-Disposition is applied.
  const gatewayFilename=title;
  const url=pdfGatewayUrl(book.id)+"&download=1&filename="+encodeURIComponent(gatewayFilename);
  const ua=navigator.userAgent||"";
  const embeddedWebView=/;\s*wv\)/i.test(ua) || (/Android/i.test(ua) && /Version\/4\.0/i.test(ua) && /Chrome\//i.test(ua));

  try{
    if(typeof navigator !== "undefined" && navigator.onLine === false){
      const offlineError=new Error("You appear to be offline.");
      offlineError.code="OFFLINE";
      offlineError.retryable=true;
      throw offlineError;
    }
    return await downloadManager.download(book,url,{
      nativeDownload:embeddedWebView,
      allowLargeFileHandoff:true,
      largeFileThresholdBytes:100*1024*1024
    });
  }catch(err){
    // The Download Manager owns failure, retry, cancellation, and UI state.
    // Do not start a second hidden download here: doing so bypasses the
    // retry/recovery state machine and can create duplicate downloads.
    console.error("KR Urdu Library PDF download failed",{bookId:book?.id,error:err});
    throw err;
  }
}

function renderReader(id){
  if(readerCleanup) { readerCleanup(); readerCleanup = null; }
  const lang=currentLang(), L=t[lang], b=data.books.find(x=>x.id===id);
  if(!b || b.status!=="available") return navigate("book",{id});
  addHistory(id);

  const title=lang==="ur"?b.title:(b.titleEn||b.title), saved=getBookProgress(id);
  let pdf=null, loadingTask=null, currentPage=Math.max(1,Number(saved?.page)||1), scale=1, fitToWidth=true;
  const networkDebug=new URLSearchParams(location.hash.split("?")[1]||"").get("networkDebug")==="1";
  let networkMonitor=null;
  let rendering=false, destroyed=false, controlsHidden=false, resizeTimer=null, lastSavedPage=currentPage, cachedObjectUrl=null, activePdfSource=null;

  const prevIcon=lang==="ur"?"fa-chevron-right":"fa-chevron-left";
  const nextIcon=lang==="ur"?"fa-chevron-left":"fa-chevron-right";
  const labels = lang==="ur" ? {
    more:"مزید", download:"ڈاؤنلوڈ", jump:"صفحہ پر جائیں", source:"اصل ماخذ کھولیں",
    details:"کتاب کی تفصیل", alternateReader:"متبادل ریڈر استعمال کریں", fullscreen:"مکمل اسکرین", zoomIn:"زوم بڑھائیں", zoomOut:"زوم کم کریں",
    close:"بند کریں", go:"جائیں", page:"صفحہ", of:"از", invalid:"درست صفحہ نمبر درج کریں۔",
    loading:"کتاب لوڈ ہو رہی ہے…", openPdf:"PDF کھولیں"
  } : {
    more:"More", download:"Download", jump:"Jump to page", source:"Open source",
    details:"Book details", alternateReader:"Use alternate reader", fullscreen:"Fullscreen", zoomIn:"Zoom in", zoomOut:"Zoom out",
    close:"Close", go:"Go", page:"Page", of:"of", invalid:"Enter a valid page number.",
    loading:"Loading book…", openPdf:"Open PDF"
  };

  app.innerHTML=`<main class="reader-shell" aria-label="${escapeHTML(title)}">
    <header class="reader-top">
      <button class="icon-btn" id="back" aria-label="${L.back}">
        <i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i>
      </button>
      <strong class="reader-title" title="${escapeHTML(title)}">${escapeHTML(title)}</strong>
      <div class="reader-more-wrap">
        <button class="icon-btn" id="more" aria-label="${labels.more}" aria-haspopup="menu" aria-expanded="false">
          <i class="fa-solid fa-ellipsis-vertical"></i>
        </button>
        <div class="reader-more-menu" id="readerMoreMenu" role="menu" hidden>
          <button type="button" role="menuitem" data-action="download"><i class="fa-solid fa-download"></i><span>${labels.download}</span></button>
          <button type="button" role="menuitem" data-action="jump"><i class="fa-solid fa-arrow-right-to-bracket"></i><span>${labels.jump}</span></button>
          <button type="button" role="menuitem" data-action="source"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>${labels.source}</span></button>
          <button type="button" role="menuitem" data-action="alternate"><i class="fa-solid fa-layer-group"></i><span>${labels.alternateReader}</span></button>
          <button type="button" role="menuitem" data-action="details"><i class="fa-solid fa-circle-info"></i><span>${labels.details}</span></button>
          <div class="reader-menu-divider"></div>
          <button type="button" role="menuitem" data-action="zoomOut"><i class="fa-solid fa-minus"></i><span>${labels.zoomOut}</span></button>
          <button type="button" role="menuitem" data-action="zoomIn"><i class="fa-solid fa-plus"></i><span>${labels.zoomIn}</span></button>
          <button type="button" role="menuitem" data-action="fullscreen"><i class="fa-solid fa-expand"></i><span>${labels.fullscreen}</span></button>
        </div>
      </div>
    </header>

    <section class="reader-body external-mode" id="readerBody" tabindex="0" aria-label="${escapeHTML(title)}">
      <div class="reader-loading" id="readerLoading">
        <i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>
        <small id="readerViewerHint">${labels.readerViewerHint}</small>
        <div class="detail-actions">
          <button class="btn" id="readerUseAlternate"><i class="fa-solid fa-layer-group"></i>${labels.alternateReader}</button>
        </div>
      </div>
      <iframe id="readerExternalFrame" class="reader-external-frame" title="${escapeHTML(title)}" allow="fullscreen *; autoplay; clipboard-read; clipboard-write" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>
      <canvas id="pdfCanvas" aria-label="${escapeHTML(title)}"></canvas>
    </section>

    <footer class="reader-bottom">
      <div class="reader-controls">
        <div class="reader-primary">
          <button class="icon-btn" id="prev" disabled aria-label="${L.previous}"><i class="fa-solid ${prevIcon}"></i></button>
          <span id="pageInfo" aria-live="polite">—</span>
          <button class="icon-btn" id="next" disabled aria-label="${L.next}"><i class="fa-solid ${nextIcon}"></i></button>
        </div>
      </div>
    </footer>
  </main>`;

  const $r=s=>app.querySelector(s), shellEl=app.querySelector(".reader-shell"),
    body=$r("#readerBody"), loading=$r("#readerLoading"), canvas=$r("#pdfCanvas"),
    externalFrame=$r("#readerExternalFrame"), useAlternate=$r("#readerUseAlternate"),
    bottom=$r(".reader-bottom"), moreBtn=$r("#more"), moreMenu=$r("#readerMoreMenu");

  canvas.hidden=true;
  externalFrame.hidden=false;
  loading.hidden=false;
  body.classList.add("external-mode");
  body.classList.remove("reader-ready");
  bottom.hidden=true;

  const readerSource=readerSourceForBook(b);
  const openGateway=()=>window.open(pdfGatewayUrl(id), "_blank", "noopener,noreferrer");
  const openCachedPdf=async()=>{
    const cached=await getCachedPdf(id);
    if(!cached?.blob) return false;
    try{
      cachedObjectUrl=URL.createObjectURL(cached.blob);
      readerMode="pdfjs";
      activePdfSource=cachedObjectUrl;
      clearExternalTimers();
      syncReaderMenu();
      externalFrame.hidden=true;
      externalFrame.src="about:blank";
      body.classList.remove("external-mode");
      bottom.hidden=false;
      canvas.hidden=true;
      loading.hidden=false;
      loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
      await loadPdf();
      return true;
    }catch(error){
      try{URL.revokeObjectURL(cachedObjectUrl);}catch{}
      cachedObjectUrl=null;
      console.warn("KR Urdu Library cached PDF load failed",error);
      return false;
    }
  };
  const openSource=()=>{
    const url=b.source?.pageUrl || b.pdfUrl || readerSource?.url;
    if(url)openExternal(url);
  };

  const saveProgress=()=>{
    if(!pdf?.numPages)return;
    setProgress(id,{
      page:currentPage,totalPages:pdf.numPages,
      percent:Math.round(currentPage/pdf.numPages*100)
    });
    lastSavedPage=currentPage;
  };

  const closeMore=()=>{
    moreMenu.hidden=true;
    moreBtn.setAttribute("aria-expanded","false");
  };
  const toggleMore=()=>{
    const open=moreMenu.hidden;
    moreMenu.hidden=!open;
    moreBtn.setAttribute("aria-expanded",String(open));
    if(open) moreMenu.querySelector("button")?.focus();
  };

  let externalLoaded=false, externalHintTimer=null, readerMode="external";

  const clearExternalTimers=()=>{
    clearTimeout(externalHintTimer);
    externalHintTimer=null;
  };

  const syncReaderMenu=()=>{
    for(const action of ['jump','zoomOut','zoomIn']){
      const item=moreMenu.querySelector(`[data-action="${action}"]`);
      if(item)item.hidden=readerMode!=="pdfjs";
    }
    const alternateItem=moreMenu.querySelector('[data-action="alternate"]');
    if(alternateItem) alternateItem.hidden=readerMode!=="external";
  };

  const showExternalHint=()=>{
    if(destroyed || readerMode!=="external" || externalLoaded)return;
    const hint=$r("#readerViewerHint");
    if(hint)hint.textContent=labels.readerViewerHint;
  };

  const switchToPdfJs=()=>{
    if(destroyed || readerMode==="pdfjs")return;
    readerMode="pdfjs";
    activePdfSource=pdfGatewayUrl(id);
    clearExternalTimers();
    syncReaderMenu();
    externalFrame.hidden=true;
    externalFrame.src="about:blank";
    body.classList.remove("external-mode");
    bottom.hidden=false;
    canvas.hidden=true;
    loading.hidden=false;
    loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
    loadPdf();
  };

  useAlternate.addEventListener("click",switchToPdfJs);
  externalFrame.addEventListener("load",()=>{
    if(destroyed || readerMode!=="external")return;
    externalLoaded=true;
    clearTimeout(externalHintTimer);
    // Cross-origin iframe load only proves that the embedded document loaded;
    // it cannot prove that the Archive/Drive viewer successfully rendered the PDF.
    // Keep the alternate-reader action available in the More menu for the full
    // lifetime of the external reader instead of treating load as a health check.
    loading.hidden=true;
    body.classList.add("reader-ready");
    syncReaderMenu();
  });
  externalFrame.addEventListener("error",()=>switchToPdfJs());

  const startExternalReader=()=>{
    readerMode="external";
    syncReaderMenu();
    externalLoaded=false;
    clearExternalTimers();
    body.classList.add("external-mode");
    bottom.hidden=true;
    canvas.hidden=true;
    externalFrame.hidden=false;
    loading.hidden=false;
    if(!readerSource){
      switchToPdfJs();
      return;
    }
    externalFrame.src=readerSource.url;
    const sourceLabel=readerSource.kind==='archive'
      ? (lang==='ur'?'Archive.org ka embedded reader':'Archive.org embedded reader')
      : readerSource.kind==='drive'
        ? (lang==='ur'?'Google Drive viewer':'Google Drive viewer')
        : (lang==='ur'?'External PDF viewer':'External PDF viewer');
    const hint=$r("#readerViewerHint");
    if(hint)hint.textContent=sourceLabel;
    // The embedded viewer is the primary reader. Cross-origin iframe load
    // cannot be inspected from the parent page, so a timeout must never
    // replace a working embedded viewer with PDF.js. PDF.js remains an
    // explicit/manual alternate reader (or a true iframe error fallback).
    externalHintTimer=setTimeout(showExternalHint,5000);
  };

  const showLoading=(message, actions=false)=>{
    loading.hidden=false;
    body.setAttribute("aria-busy","false");
    loading.innerHTML=`<i class="fa-solid fa-triangle-exclamation"></i>
      <strong>${escapeHTML(message)}</strong>
      <small>${lang==="ur"?"انٹرنیٹ کنکشن چیک کریں یا دوبارہ کوشش کریں۔":"Check your connection or try again."}</small>
      ${actions?`<div class="detail-actions">
        <button class="btn primary" id="readerRetry">${L.retry}</button>
        <button class="btn" id="readerOpenPdf">${labels.openPdf}</button>
      </div>`:""}`;
    $r("#readerRetry")?.addEventListener("click",()=>{
      canvas.hidden=true; body.classList.remove("reader-ready");
      loading.hidden=false;
      loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
      loadPdf();
    });
    $r("#readerOpenPdf")?.addEventListener("click",openGateway);
  };

  const openJumpDialog=()=>{
    closeMore();
    const old=document.querySelector(".reader-jump-backdrop");
    old?.remove();

    const backdrop=document.createElement("div");
    backdrop.className="modal-backdrop reader-jump-backdrop";
    backdrop.innerHTML=`<section class="modal reader-jump-dialog" role="dialog" aria-modal="true" aria-labelledby="readerJumpTitle">
      <h2 id="readerJumpTitle">${labels.jump}</h2>
      <p>${labels.page} <span id="readerJumpTotal">${pdf?.numPages||"—"}</span> ${labels.of}</p>
      <input id="readerJumpInput" class="search-box" type="number" inputmode="numeric" min="1" max="${pdf?.numPages||1}" value="${currentPage}" aria-label="${labels.jump}">
      <small class="reader-jump-error" id="readerJumpError" hidden>${labels.invalid}</small>
      <div class="modal-actions">
        <button class="btn" id="readerJumpCancel">${labels.close}</button>
        <button class="btn primary" id="readerJumpGo">${labels.go}</button>
      </div>
    </section>`;
    document.body.appendChild(backdrop);

    const input=backdrop.querySelector("#readerJumpInput");
    const error=backdrop.querySelector("#readerJumpError");
    const finish=()=>backdrop.remove();
    const go=async()=>{
      const n=Number(input.value);
      if(!pdf || !Number.isInteger(n) || n<1 || n>pdf.numPages){
        error.hidden=false; input.focus(); return;
      }
      finish();
      currentPage=n;
      await renderPage();
      body.scrollTo({top:0,behavior:"smooth"});
    };
    backdrop.querySelector("#readerJumpCancel").onclick=finish;
    backdrop.querySelector("#readerJumpGo").onclick=go;
    backdrop.addEventListener("click",e=>{if(e.target===backdrop)finish();});
    input.addEventListener("keydown",e=>{if(e.key==="Enter")go(); if(e.key==="Escape")finish();});
    input.addEventListener("input",()=>error.hidden=true);
    requestAnimationFrame(()=>{input.focus();input.select();});
  };

  $r("#back").onclick=()=>{
    closeMore(); saveProgress();
    history.back();
  };

  moreBtn.onclick=(e)=>{e.stopPropagation();toggleMore();};

  moreMenu.addEventListener("click",async e=>{
    const item=e.target.closest("[data-action]");
    if(!item)return;
    const action=item.dataset.action;
    if(action==="download"){
      closeMore();
      await downloadBookPdf(b);
    } else if(action==="jump") {
      closeMore();
      if(readerMode==="pdfjs") openJumpDialog();
    }
    else if(action==="source") openSource();
    else if(action==="alternate") { closeMore(); switchToPdfJs(); return; }
    else if(action==="details"){ closeMore(); saveProgress(); history.back(); return; }
    else if(action==="zoomIn"){
      closeMore();
      if(pdf&&!rendering){fitToWidth=false;scale=Math.min(3,Math.round((scale+.2)*10)/10);await renderPage();}
    } else if(action==="zoomOut"){
      closeMore();
      if(pdf&&!rendering){fitToWidth=false;scale=Math.max(.5,Math.round((scale-.2)*10)/10);await renderPage();}
    } else if(action==="fullscreen"){
      closeMore();
      const fallbackActive=shellEl.classList.contains("reader-fullscreen-fallback");
      if(document.fullscreenElement || fallbackActive){
        try{if(document.fullscreenElement) await document.exitFullscreen?.();}catch{}
        shellEl.classList.remove("reader-fullscreen-fallback");
        document.documentElement.classList.remove("reader-fullscreen-fallback-active");
        document.body.classList.remove("reader-fullscreen-fallback-active");
        onFullscreen();
        return;
      }
      try{
        if(typeof shellEl.requestFullscreen!=="function") throw new Error("Fullscreen API unavailable");
        await shellEl.requestFullscreen();
      }catch{
        shellEl.classList.add("reader-fullscreen-fallback");
        document.documentElement.classList.add("reader-fullscreen-fallback-active");
        document.body.classList.add("reader-fullscreen-fallback-active");
        onFullscreen();
      }
    }
  });

  const onOutside=e=>{
    if(!e.target.closest(".reader-more-wrap"))closeMore();
  };
  document.addEventListener("click",onOutside);

  async function renderPage(){
    if(!pdf || destroyed || rendering)return;
    rendering=true;
    let page=null;
    try{
      currentPage=Math.min(pdf.numPages,Math.max(1,currentPage));
      page=await pdf.getPage(currentPage);
      if(destroyed)return;

      let viewport=page.getViewport({scale:1});
      if(fitToWidth){
        const available=Math.max(260,body.clientWidth-20);
        scale=Math.min(3,Math.max(.5,available/viewport.width));
        body.classList.add("fit-width");
      }else{
        body.classList.remove("fit-width");
      }

      viewport=page.getViewport({scale});
      const ctx=canvas.getContext("2d",{alpha:false});
      canvas.width=Math.ceil(viewport.width);
      canvas.height=Math.ceil(viewport.height);
      canvas.style.width=`${Math.ceil(viewport.width)}px`;
      canvas.style.height=`${Math.ceil(viewport.height)}px`;

      await page.render({canvasContext:ctx,viewport}).promise;
      if(destroyed)return;

      $r("#pageInfo").textContent=`${currentPage} / ${pdf.numPages}`;
      $r("#pageInfo").setAttribute("aria-label", lang==="ur" ? `${labels.page} ${currentPage} ${labels.of} ${pdf.numPages}` : `${labels.page} ${currentPage} ${labels.of} ${pdf.numPages}`);
      $r("#prev").disabled=currentPage<=1;
      $r("#next").disabled=currentPage>=pdf.numPages;
      setProgress(id,{page:currentPage,totalPages:pdf.numPages,percent:Math.round(currentPage/pdf.numPages*100)});
      lastSavedPage=currentPage;

      canvas.hidden=false;
      body.classList.add("reader-ready");
      body.setAttribute("aria-busy","false");
      loading.hidden=true;
    }catch(err){
      canvas.hidden=true;
      body.classList.remove("reader-ready");
      if(!destroyed)showLoading(L.readerPageError,false);
    }finally{
      try{page?.cleanup?.();}catch{}
      rendering=false;
    }
  }

  const go=async delta=>{
    if(!pdf||rendering)return;
    const next=Math.min(pdf.numPages,Math.max(1,currentPage+delta));
    if(next!==currentPage){currentPage=next;await renderPage();}
  };

  $r("#prev").onclick=()=>go(-1);
  $r("#next").onclick=()=>go(1);

  let touchX=0,touchY=0,touchMoved=false;
  body.addEventListener("click",e=>{
    if(e.target.closest("button")||touchMoved){touchMoved=false;return;}
    controlsHidden=!controlsHidden;
    shellEl.classList.toggle("controls-hidden",controlsHidden);
  });

  body.addEventListener("dblclick",async e=>{
    if(e.target.closest("button")||!pdf||rendering)return;
    fitToWidth=false;
    scale=scale<1.5?1.6:1;
    await renderPage();
  });

  body.addEventListener("touchstart",e=>{
    const t=e.changedTouches[0];touchX=t.clientX;touchY=t.clientY;touchMoved=false;
  },{passive:true});

  body.addEventListener("touchmove",e=>{
    const t=e.changedTouches[0];
    if(Math.abs(t.clientX-touchX)>12||Math.abs(t.clientY-touchY)>12)touchMoved=true;
  },{passive:true});

  body.addEventListener("touchend",e=>{
    const t=e.changedTouches[0],dx=t.clientX-touchX,dy=t.clientY-touchY;
    if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.25&&!rendering){
      touchMoved=true;
      if((lang==="ur"&&dx>0)||(lang!=="ur"&&dx<0))go(1);else go(-1);
    }
  },{passive:true});

  const onResize=()=>{
    clearTimeout(resizeTimer);
    resizeTimer=setTimeout(()=>{if(pdf&&!destroyed&&fitToWidth)renderPage();},160);
  };
  window.addEventListener("resize",onResize,{passive:true});

  const onFullscreen=()=>{
    const active=Boolean(document.fullscreenElement) || shellEl.classList.contains("reader-fullscreen-fallback");
    const item=moreMenu.querySelector('[data-action="fullscreen"]');
    if(item)item.querySelector("span").textContent=active
      ? (lang==="ur"?"اسکرین سے باہر":"Exit fullscreen")
      : labels.fullscreen;
    const icon=item?.querySelector("i");
    if(icon)icon.className=`fa-solid ${active?"fa-compress":"fa-expand"}`;
  };
  document.addEventListener("fullscreenchange",onFullscreen);

  const onVisibility=()=>{if(document.visibilityState!=="visible")saveProgress();};
  const onPageHide=()=>saveProgress();
  document.addEventListener("visibilitychange",onVisibility);
  window.addEventListener("pagehide",onPageHide);

  const onKey=async e=>{
    if(state.route!=="reader"){cleanup();return;}
    if(e.key==="Escape"&&!moreMenu.hidden){closeMore();return;}
    if(e.key==="Escape"&&shellEl.classList.contains("reader-fullscreen-fallback")){
      shellEl.classList.remove("reader-fullscreen-fallback");
      document.documentElement.classList.remove("reader-fullscreen-fallback-active");
      document.body.classList.remove("reader-fullscreen-fallback-active");
      onFullscreen();
      return;
    }
    if(e.key==="Escape"&&controlsHidden){controlsHidden=false;shellEl.classList.remove("controls-hidden");return;}
    if(["ArrowRight","ArrowLeft","PageDown","PageUp","+","-","="].includes(e.key))e.preventDefault();
    if(e.key==="ArrowRight")await go(lang==="ur"?-1:1);
    else if(e.key==="ArrowLeft")await go(lang==="ur"?1:-1);
    else if(e.key==="PageDown")await go(1);
    else if(e.key==="PageUp")await go(-1);
    else if(e.key==="+"||e.key==="="){
      fitToWidth=false;
      if(!rendering){scale=Math.min(3,Math.round((scale+.2)*10)/10);await renderPage();}
    }else if(e.key==="-"){
      fitToWidth=false;
      if(!rendering){scale=Math.max(.5,Math.round((scale-.2)*10)/10);await renderPage();}
    }
  };

  const cleanup=()=>{
    destroyed=true;saveProgress();clearTimeout(resizeTimer);
    if(cachedObjectUrl){ try{URL.revokeObjectURL(cachedObjectUrl);}catch{} cachedObjectUrl=null; }
    window.removeEventListener("resize",onResize);
    document.removeEventListener("keydown",onKey);
    document.removeEventListener("fullscreenchange",onFullscreen);
    document.removeEventListener("visibilitychange",onVisibility);
    document.removeEventListener("click",onOutside);
    window.removeEventListener("pagehide",onPageHide);
    clearExternalTimers();
    try{if(document.fullscreenElement) document.exitFullscreen?.();}catch{}
    shellEl.classList.remove("reader-fullscreen-fallback");
    document.documentElement.classList.remove("reader-fullscreen-fallback-active");
    document.body.classList.remove("reader-fullscreen-fallback-active");
    try{externalFrame.src="about:blank";}catch{}
    try{loadingTask?.destroy?.();}catch{}
    try{pdf?.destroy?.();}catch{}
    try{networkMonitor?.log?.();networkMonitor?.restore?.();}catch{}
    networkMonitor=null;
  };

  readerCleanup=cleanup;
  document.addEventListener("keydown",onKey);

  const isReaderAbortError=(err)=>{
    const name=String(err?.name||"").toLowerCase();
    const message=String(err?.message||err||"").toLowerCase();
    return name==="aborterror" || name==="abortexception" || message.includes("aborted") || message.includes("abort");
  };

  async function loadPdf(attempt=0){
    if(destroyed || readerMode!=="pdfjs")return;
    loading.hidden=false;canvas.hidden=true;body.classList.remove("reader-ready"); body.setAttribute("aria-busy","true");
    try{
      if(pdf){try{pdf.destroy?.();}catch{}pdf=null;}
      const pdfjs=await loadReaderPdfJs();
      if(destroyed)return;
      activePdfSource=activePdfSource || pdfGatewayUrl(id);
      networkMonitor?.restore?.();
      networkMonitor=createReaderNetworkMonitor({bookId:id,gatewayUrl:pdfGatewayUrl(id),debug:networkDebug});
      loadingTask=pdfjs.getDocument({
        url:activePdfSource,
        disableStream:true,
        disableAutoFetch:true,
        disableRange:false,
        // Keep the fallback reader demand-driven. Do not add a custom byte-range
        // cache here: PDF.js/browser HTTP caching remains the source of truth.
        rangeChunkSize:131072
      });
      // PDF.js intentionally aborts an initial streaming/probe request when
      // range loading is available and streaming is disabled. Treat that
      // AbortError as recoverable rather than surfacing it as a reader failure.
      loadingTask.onProgress=({loaded,total})=>{
        networkMonitor?.recordProgress?.(loaded,total);
        // PDF.js reports progress in range/chunk units. With a 128 KiB
        // range size, the cumulative loaded value can legitimately round
        // above the exact file length on the final chunk. It is a measurement
        // signal, not proof that extra bytes were downloaded, so do not emit
        // a false "exceeded advertised size" error. Actual network bytes are
        // measured separately by the reader network monitor.
      };
      try{
        pdf=await loadingTask.promise;
      }catch(err){
        const message=String(err?.message||err||"");
        if(isReaderAbortError(err)){
          // Some PDF.js/browser combinations surface the intentional probe
          // cancellation through loadingTask.promise. Retry once with a fresh
          // task so the real byte-range requests can proceed.
          loadingTask=null;
          if(attempt<1 && !destroyed){
            await new Promise(resolve=>setTimeout(resolve,120));
            return loadPdf(attempt+1);
          }
          if(destroyed)return;
        }
        if(/range|partial|content-range|byte/i.test(message)){
          showLoading(lang==="ur"
            ? "PDF ka range data source se theek nahi mila. Dobara koshish karein ya PDF download karein."
            : "The PDF source did not provide a valid byte-range response. Please retry or download the PDF.",true);
        }
        throw err;
      }
      loadingTask=null;
      if(destroyed){pdf.destroy?.();return;}
      if(!b.pages||Number(b.pages)!==pdf.numPages)b.pages=pdf.numPages;
      currentPage=Math.min(pdf.numPages,Math.max(1,currentPage));
      await renderPage();
    }catch(err){
      loadingTask=null;
      if(isReaderAbortError(err)){
        // Abort during reader startup is a recoverable cancellation, not a
        // useful console error. The retry above handles the first occurrence.
        if(!destroyed)showLoading(L.readerLoadError,true);
        return;
      }
      console.error("KR Urdu Library PDF load failed",{bookId:id,error:err});
      if(!destroyed)showLoading(L.readerLoadError,true);
    }
  }

  // Always prefer the source's native embedded viewer when a source exists.
  // Browser/WebView online state can be stale, and forcing cached PDF.js here
  // can make a valid Archive.org/Drive embed appear to be unavailable.
  // Cache/PDF.js remains the offline recovery path when there is no network.
  if(typeof navigator !== "undefined" && navigator.onLine === false && !readerSource){
    openCachedPdf().then(ok=>{ if(!ok && !destroyed) showLoading(L.readerLoadError,true); });
  } else if(readerSource){
    startExternalReader();
  } else {
    openCachedPdf().then(ok=>{ if(!ok && !destroyed) switchToPdfJs(); });
  }
}

function render(){cleanupLocalReader();setDirection();applyTheme(state.theme);const r=readRoute();state.route=r.route;state.params=r.params;switch(r.route){case"home":renderHome();break;case"catalogue":renderCatalogue();break;case"classes":renderClasses();break;case"class":renderClass(r.params.id);break;case"categories":renderCategories();break;case"category":renderCategory(r.params.id);break;case"favorites":renderFavorites();break;case"search":renderSearch(r.params.q||"");break;case"book":renderBook(r.params.id);break;case"reader":renderReader(r.params.id);break;case"downloads":renderDownloads();break;case"local":renderLocal(r.params);break;case"more":renderMore();break;default:navigate("home",{}, {replace:true});}}
let lastRenderedRoute = "";
async function renderRouteOnce(){
  const raw = location.hash || "#home";
  if(raw === lastRenderedRoute) return;
  lastRenderedRoute = raw;
  const routeName = raw.slice(1).split('?')[0];
  const needsCompleteCatalogue = ['catalogue','classes','class','categories','category','favorites','book','reader'].includes(routeName);
  if(needsCompleteCatalogue) {
    try { await ensureAllBooksLoaded(); } catch(error) { console.error('KR Urdu Library catalogue load failed', error); }
  }
  render();
  // New routes start at the top; a Back/Forward navigation restores the
  // scroll position saved on that history entry.
  if(state.route !== "reader") {
    const savedY = Math.max(0, Number(history.state?.scrollY) || 0);
    requestAnimationFrame(() => window.scrollTo({ top: savedY, left: 0, behavior: "auto" }));
  }
}
window.addEventListener("popstate",e=>{
  const route=readRoute().route;
  const openPanel=document.querySelector(".class-search-panel.is-open");
  if(route==="class" && openPanel && !e.state?.classSearchOpen){
    window.__krClassSearchClose?.();
    return;
  }
  const openCategoryPanel=document.querySelector(".category-topbar .class-search-panel.is-open");
  if(route==="category" && openCategoryPanel && !e.state?.categorySearchOpen){
    window.__krCategorySearchClose?.();
    return;
  }
  window.__krClassSearchClose=null;
  window.__krCategorySearchClose=null;
  renderRouteOnce();
});
window.addEventListener("hashchange",()=>{ syncHashNavigation(); renderRouteOnce(); });
window.addEventListener("DOMContentLoaded",watchSystemTheme);
window.addEventListener("offline",()=>announceNetworkStatus("offline"));
window.addEventListener("online",()=>announceNetworkStatus("online"));
(async function init(){try{ensureAppHistory();installPullToRefresh();data=await loadLibraryData();state.dataReady=true;updateNetworkStatus(null);lastRenderedRoute = "";renderRouteOnce();checkPendingOpen();}catch(err){app.innerHTML=`<div class="page"><div class="empty"><i class="fa-solid fa-triangle-exclamation"></i><br>Failed to load library data.<br><small>${escapeHTML(err.message)}</small></div></div>`;}})();
