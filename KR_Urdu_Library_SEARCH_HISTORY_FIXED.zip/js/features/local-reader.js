// In-app reader for PDFs that live on the phone (Downloads folder / "Open with").
// The file is read in small pieces straight from storage; nothing is copied.
import { escapeHTML } from "../utils/helpers.js";
import { getBookProgress, setProgress } from "../utils/storage.js";
import { loadPdfJs } from "./pdfjs-loader.js";
import { openNativeFile, loadLocalPdf, nativeReaderAvailable } from "./local-file.js";

let activeCleanup = null;

export function cleanupLocalReader(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

export function renderLocalReader(app, { lang = "en", title = "PDF", source, progressKey }){
  cleanupLocalReader();
  const ur = lang === "ur";
  const L = ur ? {
    more:"مزید", jump:"صفحہ پر جائیں", fit:"چوڑائی کے مطابق", zoomIn:"زوم بڑھائیں", zoomOut:"زوم کم کریں",
    close:"بند کریں", go:"جائیں", page:"صفحہ", of:"از", invalid:"درست صفحہ نمبر درج کریں۔",
    loading:"کتاب کھل رہی ہے…", failed:"یہ فائل نہیں کھل سکی۔",
    hint:"ممکن ہے فائل ہٹا دی گئی ہو یا کسی اور جگہ منتقل ہوگئی ہو۔", retry:"دوبارہ کوشش کریں",
    androidOnly:"یہ فیچر صرف اینڈرائیڈ ایپ میں دستیاب ہے۔"
  } : {
    more:"More", jump:"Jump to page", fit:"Fit to width", zoomIn:"Zoom in", zoomOut:"Zoom out",
    close:"Close", go:"Go", page:"Page", of:"of", invalid:"Enter a valid page number.",
    loading:"Opening book…", failed:"This file could not be opened.",
    hint:"It may have been moved or deleted.", retry:"Try again",
    androidOnly:"This feature is only available in the Android app."
  };

  const saved = progressKey ? getBookProgress(progressKey) : null;
  let pdf = null, task = null, file = null;
  let currentPage = Math.max(1, Number(saved?.page) || 1);
  let scale = 1, lastScale = 1, fitToWidth = true;
  let rendering = false, dirty = false, destroyed = false, controlsHidden = false, resizeTimer = null;

  app.innerHTML = `<main class="reader-shell local-reader" aria-label="${escapeHTML(title)}">
    <header class="reader-top">
      <button class="icon-btn" id="lrBack" type="button" aria-label="Back"><i class="fa-solid ${ur ? "fa-arrow-right" : "fa-arrow-left"}"></i></button>
      <strong class="reader-title" title="${escapeHTML(title)}">${escapeHTML(title)}</strong>
      <div class="reader-more-wrap">
        <button class="icon-btn" id="lrMore" type="button" aria-label="${L.more}" aria-haspopup="menu" aria-expanded="false"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        <div class="reader-more-menu" id="lrMenu" role="menu" hidden>
          <button type="button" role="menuitem" data-action="jump"><i class="fa-solid fa-arrow-right-to-bracket"></i><span>${L.jump}</span></button>
          <button type="button" role="menuitem" data-action="fit"><i class="fa-solid fa-left-right"></i><span>${L.fit}</span></button>
          <button type="button" role="menuitem" data-action="zoomOut"><i class="fa-solid fa-minus"></i><span>${L.zoomOut}</span></button>
          <button type="button" role="menuitem" data-action="zoomIn"><i class="fa-solid fa-plus"></i><span>${L.zoomIn}</span></button>
        </div>
      </div>
    </header>
    <section class="reader-body fit-width" id="lrBody" tabindex="0" aria-label="${escapeHTML(title)}" aria-busy="true">
      <div class="reader-loading" id="lrLoading"><i class="fa-solid fa-spinner fa-spin"></i><span>${L.loading}</span></div>
      <canvas id="lrCanvas" hidden></canvas>
    </section>
    <footer class="reader-bottom">
      <div class="reader-controls"><div class="reader-primary">
        <button class="icon-btn" id="lrPrev" type="button" disabled aria-label="Previous"><i class="fa-solid ${ur ? "fa-chevron-right" : "fa-chevron-left"}"></i></button>
        <span id="pageInfo" aria-live="polite">—</span>
        <button class="icon-btn" id="lrNext" type="button" disabled aria-label="Next"><i class="fa-solid ${ur ? "fa-chevron-left" : "fa-chevron-right"}"></i></button>
      </div></div>
    </footer>
  </main>`;

  const $ = s => app.querySelector(s);
  const shellEl = $(".reader-shell"), body = $("#lrBody"), loading = $("#lrLoading"), canvas = $("#lrCanvas");
  const menu = $("#lrMenu"), moreBtn = $("#lrMore"), pageInfo = $("#pageInfo");

  const saveProgress = () => {
    if(!pdf?.numPages || !progressKey) return;
    setProgress(progressKey, {
      page: currentPage, totalPages: pdf.numPages,
      percent: Math.round(currentPage / pdf.numPages * 100)
    });
  };

  const closeMenu = () => { menu.hidden = true; moreBtn.setAttribute("aria-expanded", "false"); };
  const toggleMenu = () => {
    const open = menu.hidden;
    menu.hidden = !open;
    moreBtn.setAttribute("aria-expanded", String(open));
  };

  const showError = err => {
    body.setAttribute("aria-busy", "false");
    canvas.hidden = true;
    loading.hidden = false;
    const friendly = err?.friendly ? err.message : L.failed;
    const detail = err?.friendly ? "" : `<small>${L.hint}</small>`;
    loading.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><strong>${escapeHTML(friendly)}</strong>${detail}
      ${err?.friendly ? "" : `<div class="detail-actions"><button class="btn primary" id="lrRetry" type="button">${L.retry}</button></div>`}`;
    $("#lrRetry")?.addEventListener("click", () => {
      loading.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>${L.loading}</span>`;
      load();
    });
    console.warn("Local reader error:", err);
  };

  async function renderPage(){
    if(!pdf || destroyed) return;
    if(rendering){ dirty = true; return; }
    rendering = true;
    try{
      do{
        dirty = false;
        currentPage = Math.min(pdf.numPages, Math.max(1, currentPage));
        const page = await pdf.getPage(currentPage);
        if(destroyed) return;
        try{
          let viewport = page.getViewport({ scale: 1 });
          if(fitToWidth){
            const available = Math.max(260, body.clientWidth - 20);
            scale = Math.min(4, Math.max(.5, available / viewport.width));
            body.classList.add("fit-width");
          }else{
            body.classList.remove("fit-width");
          }
          lastScale = scale;
          viewport = page.getViewport({ scale });
          let dpr = Math.min(2.5, window.devicePixelRatio || 1);
          const maxPixels = 16000000;
          if(viewport.width * viewport.height * dpr * dpr > maxPixels){
            dpr = Math.max(1, Math.sqrt(maxPixels / (viewport.width * viewport.height)));
          }
          const ctx = canvas.getContext("2d", { alpha: false });
          canvas.width = Math.ceil(viewport.width * dpr);
          canvas.height = Math.ceil(viewport.height * dpr);
          canvas.style.width = `${Math.ceil(viewport.width)}px`;
          canvas.style.height = `${Math.ceil(viewport.height)}px`;
          await page.render({
            canvasContext: ctx, viewport,
            transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined
          }).promise;
        }finally{
          try{ page.cleanup?.(); }catch{}
        }
        if(destroyed) return;
        pageInfo.textContent = `${currentPage} / ${pdf.numPages}`;
        $("#lrPrev").disabled = currentPage <= 1;
        $("#lrNext").disabled = currentPage >= pdf.numPages;
        saveProgress();
        canvas.hidden = false;
        loading.hidden = true;
        body.setAttribute("aria-busy", "false");
        body.scrollTo({ top: 0, left: 0 });
      }while(dirty && !destroyed);
    }catch(err){
      if(!destroyed) showError(err);
    }finally{
      rendering = false;
    }
  }

  const go = delta => {
    if(!pdf) return;
    const next = Math.min(pdf.numPages, Math.max(1, currentPage + delta));
    if(next !== currentPage){ currentPage = next; renderPage(); }
  };

  const zoomBy = step => {
    if(!pdf) return;
    fitToWidth = false;
    scale = Math.min(4, Math.max(.5, Math.round((lastScale + step) * 100) / 100));
    renderPage();
  };

  const openJump = () => {
    closeMenu();
    document.querySelector(".reader-jump-backdrop")?.remove();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop reader-jump-backdrop";
    backdrop.innerHTML = `<section class="modal reader-jump-dialog" role="dialog" aria-modal="true">
      <h2>${L.jump}</h2>
      <p>${L.page} <span>${pdf?.numPages || "—"}</span> ${L.of}</p>
      <input id="lrJumpInput" class="search-box" type="number" inputmode="numeric" min="1" max="${pdf?.numPages || 1}" value="${currentPage}" aria-label="${L.jump}">
      <small class="reader-jump-error" id="lrJumpError" hidden>${L.invalid}</small>
      <div class="modal-actions">
        <button class="btn" id="lrJumpCancel" type="button">${L.close}</button>
        <button class="btn primary" id="lrJumpGo" type="button">${L.go}</button>
      </div>
    </section>`;
    document.body.appendChild(backdrop);
    const input = backdrop.querySelector("#lrJumpInput"), error = backdrop.querySelector("#lrJumpError");
    const finish = () => backdrop.remove();
    const jump = () => {
      const n = Number(input.value);
      if(!pdf || !Number.isInteger(n) || n < 1 || n > pdf.numPages){ error.hidden = false; input.focus(); return; }
      finish(); currentPage = n; renderPage();
    };
    backdrop.querySelector("#lrJumpCancel").onclick = finish;
    backdrop.querySelector("#lrJumpGo").onclick = jump;
    backdrop.addEventListener("click", e => { if(e.target === backdrop) finish(); });
    input.addEventListener("keydown", e => { if(e.key === "Enter") jump(); if(e.key === "Escape") finish(); });
    input.addEventListener("input", () => { error.hidden = true; });
    requestAnimationFrame(() => { input.focus(); input.select(); });
  };

  $("#lrBack").onclick = () => { closeMenu(); saveProgress(); history.back(); };
  moreBtn.onclick = e => { e.stopPropagation(); toggleMenu(); };
  $("#lrPrev").onclick = () => go(-1);
  $("#lrNext").onclick = () => go(1);

  menu.addEventListener("click", e => {
    const item = e.target.closest("[data-action]");
    if(!item) return;
    const action = item.dataset.action;
    closeMenu();
    if(action === "jump") openJump();
    else if(action === "fit"){ fitToWidth = true; renderPage(); }
    else if(action === "zoomIn") zoomBy(.25);
    else if(action === "zoomOut") zoomBy(-.25);
  });

  const onOutside = e => { if(!e.target.closest(".reader-more-wrap")) closeMenu(); };
  document.addEventListener("click", onOutside);

  // Tap toggles controls, double-tap zooms, swipe changes page, pinch zooms.
  let touchX = 0, touchY = 0, touchMoved = false, pinchStart = 0, pinchLast = 0;
  const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  body.addEventListener("click", e => {
    if(e.target.closest("button") || touchMoved){ touchMoved = false; return; }
    controlsHidden = !controlsHidden;
    shellEl.classList.toggle("controls-hidden", controlsHidden);
  });
  body.addEventListener("dblclick", e => {
    if(e.target.closest("button") || !pdf) return;
    if(fitToWidth){ fitToWidth = false; scale = Math.min(4, lastScale * 1.8); renderPage(); }
    else{ fitToWidth = true; renderPage(); }
  });
  body.addEventListener("touchstart", e => {
    if(e.touches.length === 2){ pinchStart = pinchLast = dist(e.touches); touchMoved = true; return; }
    const t = e.changedTouches[0]; touchX = t.clientX; touchY = t.clientY; touchMoved = false;
  }, { passive: true });
  body.addEventListener("touchmove", e => {
    if(e.touches.length === 2){ pinchLast = dist(e.touches); touchMoved = true; return; }
    const t = e.changedTouches[0];
    if(Math.abs(t.clientX - touchX) > 12 || Math.abs(t.clientY - touchY) > 12) touchMoved = true;
  }, { passive: true });
  body.addEventListener("touchend", e => {
    if(pinchStart){
      const ratio = pinchLast / pinchStart;
      pinchStart = pinchLast = 0;
      if(pdf && (ratio > 1.12 || ratio < .89)){
        fitToWidth = false;
        scale = Math.min(4, Math.max(.5, Math.round(lastScale * ratio * 100) / 100));
        renderPage();
      }
      return;
    }
    if(e.touches.length) return;
    const t = e.changedTouches[0], dx = t.clientX - touchX, dy = t.clientY - touchY;
    const canFlip = body.scrollWidth <= body.clientWidth + 2;
    if(canFlip && Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.25){
      touchMoved = true;
      if((ur && dx > 0) || (!ur && dx < 0)) go(1); else go(-1);
    }
  }, { passive: true });

  const onResize = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if(pdf && !destroyed && fitToWidth) renderPage(); }, 160);
  };
  window.addEventListener("resize", onResize, { passive: true });
  const onVisibility = () => { if(document.visibilityState !== "visible") saveProgress(); };
  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("pagehide", saveProgress);

  async function load(){
    try{
      if(!nativeReaderAvailable()){
        throw Object.assign(new Error(L.androidOnly), { friendly: true });
      }
      const pdfjs = await loadPdfJs();
      if(destroyed) return;
      file = await openNativeFile(source);
      if(destroyed){ file.close(); return; }
      const result = await loadLocalPdf(pdfjs, file);
      if(destroyed){ try{ result.task.destroy(); }catch{} return; }
      pdf = result.pdf; task = result.task;
      currentPage = Math.min(pdf.numPages, Math.max(1, currentPage));
      await renderPage();
    }catch(err){
      if(!destroyed) showError(err);
    }
  }

  activeCleanup = () => {
    destroyed = true;
    saveProgress();
    clearTimeout(resizeTimer);
    window.removeEventListener("resize", onResize);
    window.removeEventListener("pagehide", saveProgress);
    document.removeEventListener("visibilitychange", onVisibility);
    document.removeEventListener("click", onOutside);
    document.querySelector(".reader-jump-backdrop")?.remove();
    try{ task?.destroy?.(); }catch{}
    try{ pdf?.destroy?.(); }catch{}
    try{ file?.close?.(); }catch{}
  };

  load();
}
