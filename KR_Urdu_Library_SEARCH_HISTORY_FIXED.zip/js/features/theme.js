import { getTheme, setTheme } from "../utils/storage.js";

function resolve(theme) {
  return theme === "system"
    ? (window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light")
    : theme;
}

export function applyTheme(theme = getTheme()) {
  const actual = resolve(theme);
  document.documentElement.dataset.theme = actual;
  document.documentElement.dataset.themePreference = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = actual === "dark" ? "#101512" : "#f7f7f5";
  return actual;
}

export function changeTheme(theme) {
  if (!setTheme(theme)) return;
  applyTheme(theme);
}

export function watchSystemTheme() {
  const media = window.matchMedia?.("(prefers-color-scheme: dark)");
  if (!media) return;
  const handler = () => { if (getTheme() === "system") applyTheme("system"); };
  media.addEventListener?.("change", handler);
}
