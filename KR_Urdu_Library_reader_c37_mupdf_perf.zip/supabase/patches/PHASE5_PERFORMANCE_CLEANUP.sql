-- KR Urdu Library — Phase 5
-- Redundant single-column status index removed because
-- idx_books_status_added_at(status, added_at DESC) already supports
-- status equality lookups and the catalogue ordering pattern.
DROP INDEX IF EXISTS public.books_status_idx;
