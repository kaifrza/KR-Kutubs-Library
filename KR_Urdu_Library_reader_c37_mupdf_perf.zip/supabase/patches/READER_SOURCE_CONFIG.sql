-- KR Urdu Library — Reader source configuration reference
--
-- IMPORTANT:
-- This patch is intentionally READ-ONLY. It does NOT alter the live backend.
-- The current frontend derives reader URLs at runtime from the existing
-- pdf_source_type / pdf_url / drive_file_id columns.
--
-- Planned reader strategy:
--   Archive.org -> https://archive.org/embed/{identifier}
--   Google Drive -> https://drive.google.com/file/{drive_file_id}/preview
--   Fallback -> existing pdf-gateway + PDF.js
--
-- Run the SELECT below only when you want to inspect the reader mapping.

select
  id,
  title,
  pdf_source_type,
  pdf_url,
  drive_file_id,
  case
    when lower(coalesce(pdf_source_type,'')) = 'drive'
      or nullif(trim(coalesce(drive_file_id,'')), '') is not null
      then 'drive'
    when pdf_url ilike 'https://archive.org/download/%'
      or pdf_url ilike 'https://archive.org/details/%'
      or pdf_url ilike 'https://archive.org/embed/%'
      then 'archive'
    else 'external'
  end as reader_source_kind,
  case
    when lower(coalesce(pdf_source_type,'')) = 'drive'
      or nullif(trim(coalesce(drive_file_id,'')), '') is not null
      then 'https://drive.google.com/file/' || trim(drive_file_id) || '/preview'
    when pdf_url ilike 'https://archive.org/download/%'
      then 'https://archive.org/embed/' || split_part(replace(pdf_url, 'https://archive.org/download/', ''), '/', 1)
    when pdf_url ilike 'https://archive.org/details/%'
      then 'https://archive.org/embed/' || split_part(replace(pdf_url, 'https://archive.org/details/', ''), '/', 1)
    when pdf_url ilike 'https://archive.org/embed/%'
      then pdf_url
    else pdf_url
  end as reader_embed_url
from public.books
where status = 'available'
order by created_at desc nulls last, id;

-- Example only — do NOT execute as an UPDATE yet:
-- Archive.org:
--   pdf_url = 'https://archive.org/download/tadveen-e-quran/<file>.pdf'
--   reader  = 'https://archive.org/embed/tadveen-e-quran'
--
-- Google Drive (public file):
--   pdf_source_type = 'drive'
--   drive_file_id   = '<PUBLIC_DRIVE_FILE_ID>'
--   reader          = 'https://drive.google.com/file/<PUBLIC_DRIVE_FILE_ID>/preview'
--
-- Once the hybrid reader is proven stable, these computed values can be
-- promoted into explicit backend columns if desired.
