-- KR Urdu Library — Phase 4 Security Hardening
-- Applied to live Supabase project: 2026-09-24
--
-- Changes:
-- 1) Make public.is_admin() SECURITY INVOKER.
-- 2) Remove anon/authenticated EXECUTE access from legacy PDF token RPCs.
-- 3) Keep the legacy token RPCs callable only by service_role.
-- 4) Remove two exact duplicate indexes.
--
-- Intentionally NOT included:
-- - private.pdf_gateway_config RLS enablement. The Supabase advisor flags this,
--   but enabling RLS without an explicit policy is a security-sensitive change
--   that must be reviewed separately.
-- - Auth leaked-password protection. This is an Auth dashboard setting, not a
--   database migration.

create or replace function public.is_admin()
returns boolean
language sql
stable
security invoker
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_profiles ap
    where ap.user_id = (select auth.uid())
      and ap.role = 'admin'
  );
$$;

revoke execute on function public.is_admin() from anon, authenticated;
grant execute on function public.is_admin() to authenticated;

revoke execute on function public.issue_pdf_gateway_token(text) from anon, authenticated;
revoke execute on function public.validate_pdf_gateway_token(text,text) from anon, authenticated;
grant execute on function public.issue_pdf_gateway_token(text) to service_role;
grant execute on function public.validate_pdf_gateway_token(text,text) to service_role;

drop index if exists public.idx_book_categories_category_id;
drop index if exists public.idx_books_class_id;
