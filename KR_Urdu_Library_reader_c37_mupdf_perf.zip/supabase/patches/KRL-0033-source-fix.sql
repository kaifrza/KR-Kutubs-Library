-- KR Urdu Library: KRL-0033 source compatibility fix
-- The live Supabase row has already been updated.
-- Run this only if restoring/importing the catalogue elsewhere.
UPDATE public.books
SET pdf_url = 'https://archive.org/download/TadweenEQuran/Tadween%20E%20Quran.pdf'
WHERE id = 'KRL-0033';
