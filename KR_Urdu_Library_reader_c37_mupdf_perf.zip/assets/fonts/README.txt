Offline fonts (recommended for the Android APK)
------------------------------------------------
index.html currently loads Inter + Noto Naskh Arabic from Google Fonts (cached by the browser after first load).
For a fully offline build:
 1. Download "Noto Naskh Arabic" (variable, wght 400-700) and "Inter" as .woff2 from fonts.google.com or fontsource.
 2. Put them in this folder as NotoNaskhArabic.woff2 and Inter.woff2.
 3. Add to css/production.css:
      @font-face{font-family:"Noto Naskh Arabic";src:url(../assets/fonts/NotoNaskhArabic.woff2) format("woff2");font-weight:400 700;font-display:swap}
      @font-face{font-family:Inter;src:url(../assets/fonts/Inter.woff2) format("woff2");font-weight:400 800;font-display:swap}
 4. Delete the fonts.googleapis.com <link> and the two preconnects in index.html.
