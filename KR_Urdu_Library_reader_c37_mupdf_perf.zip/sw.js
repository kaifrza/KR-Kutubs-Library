/*
 * KR Urdu Library no longer uses a service worker (the app ships as an APK).
 * This file exists only so devices that still have the OLD worker installed
 * download it, clean up the old caches, unregister and reload with fresh files.
 */
self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith("krl-final-")).map(key => caches.delete(key)));
    await self.registration.unregister();
    const windows = await self.clients.matchAll({ type: "window" });
    windows.forEach(client => { try { client.navigate(client.url); } catch {} });
  })());
});
