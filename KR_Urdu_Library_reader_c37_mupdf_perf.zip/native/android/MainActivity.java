package com.kr.urdulibrary;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;

import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    // Native pull-to-refresh (SwipeRefreshLayout around the WebView). The web layer decides
    // whether it may be used on the current screen via KRDownloaderPlugin.setPullRefresh().
    static volatile boolean ptrEnabled = false;
    static SwipeRefreshLayout ptr;

    /** SwipeRefreshLayout that ignores mostly-horizontal drags (carousels, chips). */
    static class HLayout extends SwipeRefreshLayout {
        private float dx0, dy0;
        HLayout(android.content.Context c) { super(c); }
        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: dx0 = e.getX(); dy0 = e.getY(); break;
                case MotionEvent.ACTION_MOVE:
                    float dx = Math.abs(e.getX() - dx0), dy = e.getY() - dy0;
                    if (dx > Math.abs(dy) * 0.7f || dy < 0) return false;
                    break;
                default: break;
            }
            return super.onInterceptTouchEvent(e);
        }
    }

    private void installNativePullRefresh() {
        try {
            if (getBridge() == null || getBridge().getWebView() == null) return;
            final WebView wv = getBridge().getWebView();
            final ViewGroup parent = (ViewGroup) wv.getParent();
            if (parent == null || parent instanceof SwipeRefreshLayout) return;
            final int idx = parent.indexOfChild(wv);
            final ViewGroup.LayoutParams lp = wv.getLayoutParams();
            parent.removeView(wv);
            final HLayout srl = new HLayout(this);
            srl.addView(wv, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            parent.addView(srl, idx, lp);
            srl.setDistanceToTriggerSync((int) (110 * getResources().getDisplayMetrics().density));
            srl.setOnChildScrollUpCallback((p, child) -> !ptrEnabled || wv.getScrollY() > 0 || wv.canScrollVertically(-1));
            srl.setOnRefreshListener(() -> {
                wv.evaluateJavascript(
                    "(function(){try{return window.__krNativeRefresh?(window.__krNativeRefresh(),'ok'):'none'}catch(e){return 'none'}})()",
                    v -> { if (v == null || !v.contains("ok")) srl.setRefreshing(false); });
                // safety net: never spin forever
                srl.postDelayed(() -> srl.setRefreshing(false), 20000);
            });
            ptr = srl;
        } catch (Throwable ignored) { }
    }

    static void configurePtr(final boolean enabled, final Integer bg, final Integer fg) {
        ptrEnabled = enabled;
        final SwipeRefreshLayout p = ptr;
        if (p == null) return;
        p.post(() -> {
            if (bg != null) p.setProgressBackgroundColorSchemeColor(bg);
            if (fg != null) p.setColorSchemeColors(fg);
            if (!enabled) p.setRefreshing(false);
        });
    }

    static void finishPtr() {
        final SwipeRefreshLayout p = ptr;
        if (p != null) p.post(() -> p.setRefreshing(false));
    }

    // Must match --bg in css/variables.css
    static final int BG_LIGHT = Color.parseColor("#f7f7f5");
    static final int BG_DARK = Color.parseColor("#101512");

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KRDownloaderPlugin.class);
        super.onCreate(savedInstanceState);
        // Paint the window / status bar / nav bar with the app background right away so no
        // white strip is ever visible. The web layer re-syncs this when the theme changes.
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        applySystemBars(this, night ? BG_DARK : BG_LIGHT, !night);
        installNativePullRefresh();
        // Hardware/gesture Back: let the web layer decide (close dialog, previous screen,
        // double-press to exit). Registered after super.onCreate so it runs before Capacitor's.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                final WebView wv = (getBridge() != null) ? getBridge().getWebView() : null;
                if (wv == null) { finish(); return; }
                wv.evaluateJavascript(
                    "(function(){try{return window.__krBack?window.__krBack():'none'}catch(e){return 'none'}})()",
                    value -> {
                        // "handled" -> stay. "exit"/"none"/null -> leave the app (keep it in recents).
                        if (value != null && value.contains("handled")) return;
                        moveTaskToBack(true);
                    });
            }
        });
        if (savedInstanceState == null) {
            KRDownloaderPlugin.setPendingIntent(this, getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        KRDownloaderPlugin.setPendingIntent(this, intent);
    }

    /** Colours the window behind/around the WebView and the system bars to match the app theme. */
    @SuppressWarnings("deprecation")
    static void applySystemBars(Activity activity, int color, boolean lightBackground) {
        try {
            Window w = activity.getWindow();
            w.setBackgroundDrawable(new ColorDrawable(color));
            try { w.setStatusBarColor(color); } catch (Throwable ignored) { }
            try { w.setNavigationBarColor(color); } catch (Throwable ignored) { }
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            if (c != null) {
                c.setAppearanceLightStatusBars(lightBackground);
                c.setAppearanceLightNavigationBars(lightBackground);
            }
            if (activity instanceof BridgeActivity) {
                BridgeActivity b = (BridgeActivity) activity;
                if (b.getBridge() != null && b.getBridge().getWebView() != null) {
                    b.getBridge().getWebView().setBackgroundColor(color);
                }
            }
        } catch (Throwable ignored) { }
    }
}
