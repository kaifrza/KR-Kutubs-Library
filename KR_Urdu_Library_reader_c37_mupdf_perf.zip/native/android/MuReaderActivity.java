package com.kr.urdulibrary;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Native PDF reader (MuPDF). Launched from KRDownloaderPlugin.openMuReader().
 * All state (position, bookmarks, look) comes in through intent extras and goes back out through
 * the result intent, so the web layer stays the single place where it is stored.
 */
public class MuReaderActivity extends Activity implements MuPdfView.Host {

    // ------------------------------------------------------------ extras
    static final String X_PATH = "path", X_TITLE = "title", X_LANG = "lang", X_PAGE = "page", X_FRAC = "frac",
            X_THEME = "theme", X_DIM = "dim", X_AWAKE = "keepAwake", X_AUTOHIDE = "autoHide", X_MARKS = "marks",
            R_TOTAL = "total", R_ERROR = "error";

    private boolean ur;
    private String title, path;
    private int theme;                 // 0 paper 1 sepia 2 night
    private float dim;
    private boolean keepAwake, autoHide;
    private final TreeSet<Integer> marks = new TreeSet<>();   // 1-based
    private int startPage0;
    private float startFrac;

    // ------------------------------------------------------------ ui
    private MuPdfView view;
    private FrameLayout root;
    private LinearLayout topBar, searchBar, bottomBar;
    private TextView titleView, pageLabel, pill, searchCount;
    private SeekBar seek;
    private IconView markBtn;
    private EditText searchInput;
    private ProgressBar spinner;
    private int topInset = 0, botInset = 0;
    private boolean barsShown = true, opened = false, searching = false;
    private int total = 0;
    private int curPage0 = 0;
    private List<MuPdfView.OutlineItem> outline = new ArrayList<>();
    private float density;
    private Dialog openDialog;

    // theme colours
    private int barBg, barFg, barSub, accent, sheetBg, sheetFg, chipBg;

    // ================================================================= lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        Intent in = getIntent();
        path = in.getStringExtra(X_PATH);
        title = in.getStringExtra(X_TITLE);
        if (title == null) title = "PDF";
        ur = "ur".equals(in.getStringExtra(X_LANG));
        startPage0 = Math.max(0, in.getIntExtra(X_PAGE, 1) - 1);
        startFrac = in.getFloatExtra(X_FRAC, 0f);
        String th = in.getStringExtra(X_THEME);
        theme = "night".equals(th) ? 2 : "sepia".equals(th) ? 1 : 0;
        dim = in.getFloatExtra(X_DIM, 0f);
        keepAwake = in.getBooleanExtra(X_AWAKE, false);
        autoHide = in.getBooleanExtra(X_AUTOHIDE, true);
        int[] m = in.getIntArrayExtra(X_MARKS);
        if (m != null) for (int x : m) if (x > 0) marks.add(x);

        Window w = getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        try { w.setStatusBarColor(Color.TRANSPARENT); w.setNavigationBarColor(Color.TRANSPARENT); } catch (Throwable ignored) { }
        if (keepAwake) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        buildUi();
        applyLook();

        if (path == null || !new File(path).exists()) { finishWith("File not found"); return; }
        view.open(path, null, startPage0, startFrac);
    }

    @Override protected void onPause() {
        super.onPause();
        publishResult(null);
    }

    @Override protected void onDestroy() {
        if (view != null) view.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (searching) { closeSearch(); return; }
        finishWith(null);
    }

    private void finishWith(String error) {
        publishResult(error);
        finish();
    }

    private void publishResult(String error) {
        Intent r = new Intent();
        if (view != null && opened) {
            r.putExtra(X_PAGE, view.currentPage0() + 1);
            r.putExtra(X_FRAC, view.currentFrac());
            r.putExtra(R_TOTAL, total);
        }
        r.putExtra(X_THEME, theme == 2 ? "night" : theme == 1 ? "sepia" : "paper");
        r.putExtra(X_DIM, dim);
        r.putExtra(X_AWAKE, keepAwake);
        int[] arr = new int[marks.size()]; int i = 0; for (int x : marks) arr[i++] = x;
        r.putExtra(X_MARKS, arr);
        if (error != null) r.putExtra(R_ERROR, error);
        setResult(error == null ? RESULT_OK : RESULT_CANCELED, r);
    }

    // ================================================================= strings
    private String s(String key) {
        if (ur) {
            switch (key) {
                case "search": return "تلاش کریں";
                case "contents": return "فہرست";
                case "marks": return "نشانیاں";
                case "look": return "ظاہری شکل";
                case "paper": return "کاغذ";
                case "sepia": return "سیپیا";
                case "night": return "رات";
                case "brightness": return "روشنی";
                case "awake": return "اسکرین جاگتی رکھیں";
                case "fit": return "چوڑائی کے مطابق";
                case "jump": return "صفحے پر جائیں";
                case "go": return "جائیں";
                case "cancel": return "منسوخ";
                case "ok": return "ٹھیک ہے";
                case "pw_title": return "یہ PDF محفوظ ہے";
                case "pw_hint": return "پاس ورڈ";
                case "pw_wrong": return "پاس ورڈ درست نہیں";
                case "nocontents": return "اس کتاب میں فہرست موجود نہیں";
                case "nomarks": return "ابھی کوئی نشانی نہیں لگائی گئی";
                case "added": return "نشانی لگا دی گئی";
                case "removed": return "نشانی ہٹا دی گئی";
                case "noresult": return "کچھ نہیں ملا";
                case "page": return "صفحہ";
                case "pages": return "صفحات";
                case "of": return "از";
                case "loading": return "کھل رہی ہے…";
                default: return key;
            }
        }
        switch (key) {
            case "search": return "Search";
            case "contents": return "Contents";
            case "marks": return "Bookmarks";
            case "look": return "Appearance";
            case "paper": return "Paper";
            case "sepia": return "Sepia";
            case "night": return "Night";
            case "brightness": return "Brightness";
            case "awake": return "Keep screen on";
            case "fit": return "Fit width";
            case "jump": return "Go to page";
            case "go": return "Go";
            case "cancel": return "Cancel";
            case "ok": return "OK";
            case "pw_title": return "This PDF is protected";
            case "pw_hint": return "Password";
            case "pw_wrong": return "Wrong password";
            case "nocontents": return "This book has no table of contents";
            case "nomarks": return "No bookmarks yet";
            case "added": return "Bookmark added";
            case "removed": return "Bookmark removed";
            case "noresult": return "No results";
            case "page": return "Page";
            case "pages": return "pages";
            case "of": return "of";
            case "loading": return "Opening…";
            default: return key;
        }
    }

    // ================================================================= UI construction
    private int dp(float v) { return Math.round(v * density); }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        view = new MuPdfView(this);
        view.setHost(this);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1));

        // ---- top bar
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finishWith(null));
        titleView = new TextView(this);
        titleView.setText(title);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        titleView.setTextSize(16f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleView.setPadding(dp(4), 0, dp(4), 0);
        IconView searchBtn = new IconView(this, IconView.SEARCH);
        searchBtn.setOnClickListener(v -> openSearch());
        markBtn = new IconView(this, IconView.MARK);
        markBtn.setOnClickListener(v -> toggleMark());
        IconView tocBtn = new IconView(this, IconView.LIST);
        tocBtn.setOnClickListener(v -> showContents());
        IconView setBtn = new IconView(this, IconView.SLIDERS);
        setBtn.setOnClickListener(v -> showSettings());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1f));
        topBar.addView(searchBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        topBar.addView(markBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        topBar.addView(tocBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        topBar.addView(setBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- search bar (replaces the top bar while searching)
        searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setVisibility(View.GONE);
        IconView sClose = new IconView(this, IconView.BACK);
        sClose.setOnClickListener(v -> closeSearch());
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint(s("search"));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT);
        searchInput.setTextSize(16f);
        searchInput.setBackground(null);
        searchInput.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        searchInput.setOnEditorActionListener((tv, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { runSearch(); return true; }
            return false;
        });
        searchCount = new TextView(this);
        searchCount.setTextSize(12f);
        searchCount.setPadding(dp(6), 0, dp(6), 0);
        searchCount.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        IconView up = new IconView(this, IconView.UP);
        up.setOnClickListener(v -> { view.nextHit(-1); updateSearchCount(); });
        IconView down = new IconView(this, IconView.DOWN);
        down.setOnClickListener(v -> { view.nextHit(1); updateSearchCount(); });
        searchBar.addView(sClose, new LinearLayout.LayoutParams(dp(48), dp(48)));
        searchBar.addView(searchInput, new LinearLayout.LayoutParams(0, dp(48), 1f));
        searchBar.addView(searchCount, new LinearLayout.LayoutParams(-2, -2));
        searchBar.addView(up, new LinearLayout.LayoutParams(dp(40), dp(48)));
        searchBar.addView(down, new LinearLayout.LayoutParams(dp(40), dp(48)));
        root.addView(searchBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- bottom bar
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        seek = new SeekBar(this);
        seek.setMax(0);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser && total > 0) { view.goToPage(p); setPageText(p); }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        pageLabel = new TextView(this);
        pageLabel.setTextSize(13f);
        pageLabel.setTypeface(Typeface.DEFAULT_BOLD);
        pageLabel.setPadding(dp(8), dp(8), dp(8), dp(8));
        pageLabel.setOnClickListener(v -> showJump());
        bottomBar.addView(seek, new LinearLayout.LayoutParams(0, dp(48), 1f));
        bottomBar.addView(pageLabel, new LinearLayout.LayoutParams(-2, -2));
        bottomBar.setPadding(dp(12), dp(4), dp(8), dp(4));
        root.addView(bottomBar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        // ---- floating page pill (visible while the bars are hidden)
        pill = new TextView(this);
        pill.setTextSize(12f);
        pill.setTypeface(Typeface.DEFAULT_BOLD);
        pill.setPadding(dp(12), dp(5), dp(12), dp(5));
        pill.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pill.setVisibility(View.GONE);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        root.addView(pill, plp);

        spinner = new ProgressBar(this);
        root.addView(spinner, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));

        setContentView(root);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            topInset = sb.top; botInset = sb.bottom;
            topBar.setPadding(sb.left, topInset, sb.right, 0);
            searchBar.setPadding(sb.left, topInset, sb.right, 0);
            bottomBar.setPadding(dp(12) + sb.left, dp(4), dp(8) + sb.right, dp(4) + botInset);
            ((FrameLayout.LayoutParams) pill.getLayoutParams()).bottomMargin = botInset + dp(14);
            pill.requestLayout();
            return insets;
        });
    }

    private void applyLook() {
        if (theme == 2) { barBg = 0xF0151B17; barFg = 0xFFE6ECE8; barSub = 0xFF9AA8A0; accent = 0xFF55B88B; sheetBg = 0xFF171D19; sheetFg = 0xFFE6ECE8; chipBg = 0xFF232B26; }
        else if (theme == 1) { barBg = 0xF0EFE6D2; barFg = 0xFF2B2418; barSub = 0xFF7A6D55; accent = 0xFF176B4D; sheetBg = 0xFFF4ECD8; sheetFg = 0xFF2B2418; chipBg = 0xFFE7DCC2; }
        else { barBg = 0xF0F7F7F5; barFg = 0xFF1C2420; barSub = 0xFF6B7770; accent = 0xFF176B4D; sheetBg = 0xFFFFFFFF; sheetFg = 0xFF1C2420; chipBg = 0xFFEDEDE8; }
        topBar.setBackgroundColor(barBg);
        searchBar.setBackgroundColor(barBg);
        bottomBar.setBackgroundColor(barBg);
        titleView.setTextColor(barFg);
        searchInput.setTextColor(barFg);
        searchInput.setHintTextColor(barSub);
        searchCount.setTextColor(barSub);
        pageLabel.setTextColor(barFg);
        GradientDrawable pg = new GradientDrawable();
        pg.setColor(theme == 2 ? 0xCC232B26 : 0xCC1C2420); pg.setCornerRadius(dp(16));
        pill.setBackground(pg); pill.setTextColor(0xFFFFFFFF);
        recolor(topBar); recolor(searchBar);
        try { seek.getProgressDrawable().setTint(accent); seek.getThumb().setTint(accent); } catch (Throwable ignored) { }
        view.setLook(theme, dim);
        root.setBackgroundColor(view.backgroundColor());
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c != null) { c.setAppearanceLightStatusBars(theme != 2); c.setAppearanceLightNavigationBars(theme != 2); }
        updateMarkIcon();
    }

    private void recolor(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c instanceof IconView) { ((IconView) c).setColor(barFg); }
        }
    }

    // ================================================================= bars
    private void setBars(boolean show) {
        if (barsShown == show) return;
        barsShown = show;
        View top = searching ? searchBar : topBar;
        top.animate().alpha(show ? 1f : 0f).translationY(show ? 0 : -dp(24)).setDuration(160).withEndAction(() -> { if (!barsShown && !searching) top.setVisibility(View.INVISIBLE); }).start();
        if (show) top.setVisibility(View.VISIBLE);
        bottomBar.animate().alpha(show ? 1f : 0f).translationY(show ? 0 : dp(24)).setDuration(160).withEndAction(() -> { if (!barsShown) bottomBar.setVisibility(View.INVISIBLE); }).start();
        if (show) bottomBar.setVisibility(View.VISIBLE);
        pill.setVisibility(show || total == 0 ? View.GONE : View.VISIBLE);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c != null) {
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            if (show) c.show(WindowInsetsCompat.Type.systemBars()); else c.hide(WindowInsetsCompat.Type.systemBars());
        }
    }

    // ================================================================= MuPdfView.Host
    @Override public void onOpened(int pageCount, boolean hasOutline) {
        opened = true; total = pageCount;
        spinner.setVisibility(View.GONE);
        seek.setMax(Math.max(0, pageCount - 1));
        setPageText(Math.max(0, Math.min(pageCount - 1, startPage0)));
    }

    @Override public void onOutline(List<MuPdfView.OutlineItem> items) { outline = items == null ? new ArrayList<MuPdfView.OutlineItem>() : items; }

    @Override public void onOpenFailed(String message) { finishWith(message == null ? "open failed" : message); }

    @Override public void onNeedPassword(boolean wrongBefore) {
        spinner.setVisibility(View.GONE);
        showPasswordSheet(wrongBefore);
    }

    @Override public void onPageChanged(int page0, int pageTotal) {
        curPage0 = page0;
        total = pageTotal;
        seek.setProgress(page0);
        setPageText(page0);
        updateMarkIcon();
    }

    @Override public void onTap() { if (!searching) setBars(!barsShown); else hideKeyboard(); }

    @Override public void onUserScroll() { if (autoHide && barsShown && !searching) setBars(false); }

    @Override public void onExternalLink(String uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri))); } catch (Throwable ignored) { }
    }

    private void setPageText(int page0) {
        String t = (page0 + 1) + " / " + total;
        pageLabel.setText(t);
        pill.setText(t);
    }

    // ================================================================= bookmarks
    private void toggleMark() {
        if (!opened) return;
        int p = view.currentPage0() + 1;
        if (marks.contains(p)) { marks.remove(p); toast(s("removed")); } else { marks.add(p); toast(s("added")); }
        updateMarkIcon();
    }

    private void updateMarkIcon() {
        if (markBtn == null) return;
        markBtn.setFilled(marks.contains(curPage0 + 1));
        markBtn.setColor(marks.contains(curPage0 + 1) ? accent : barFg);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    // ================================================================= search
    private void openSearch() {
        if (!opened) return;
        searching = true;
        topBar.setVisibility(View.GONE);
        searchBar.setAlpha(1f); searchBar.setTranslationY(0); searchBar.setVisibility(View.VISIBLE);
        if (!barsShown) setBars(true);
        searchInput.requestFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(searchInput, 0);
    }

    private void closeSearch() {
        searching = false;
        view.clearSearch();
        searchCount.setText("");
        searchBar.setVisibility(View.GONE);
        topBar.setAlpha(1f); topBar.setTranslationY(0); topBar.setVisibility(View.VISIBLE);
        hideKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
    }

    private void runSearch() {
        String q = searchInput.getText().toString();
        hideKeyboard();
        searchCount.setText("…");
        view.search(q, (hits, done) -> {
            if (done) {
                if (hits == 0) { searchCount.setText("0"); toast(s("noresult")); } else updateSearchCount();
            } else updateSearchCount();
        });
    }

    private void updateSearchCount() {
        int n = view.hitCount();
        searchCount.setText(n == 0 ? "…" : (view.currentHitIndex() + 1) + "/" + n);
    }

    // ================================================================= sheets
    private Dialog newSheet(View content, boolean bottom) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(sheetBg);
        float r = dp(22);
        if (bottom) bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0}); else bg.setCornerRadius(r);
        box.setBackground(bg);
        box.setPadding(dp(18), dp(14), dp(18), dp(18) + (bottom ? botInset : 0));
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            w.setLayout(bottom ? -1 : (int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
            w.setGravity(bottom ? Gravity.BOTTOM : Gravity.CENTER);
            w.setDimAmount(0.45f);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        openDialog = d;
        d.show();
        return d;
    }

    private TextView text(String t, float sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        return v;
    }

    private TextView chip(String t, boolean on) {
        TextView v = text(t, 14f, true, on ? 0xFFFFFFFF : sheetFg);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12)); g.setColor(on ? accent : chipBg);
        v.setBackground(g);
        return v;
    }

    // ---- contents + bookmarks
    private boolean showMarksTab = false;
    private void showContents() {
        if (!opened) return;
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        final ListView list = new ListView(this);
        list.setDivider(null);
        list.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        final TextView empty = text("", 14f, false, barSub);
        empty.setPadding(dp(6), dp(20), dp(6), dp(20));
        col.addView(tabs); col.addView(empty);
        col.addView(list, new LinearLayout.LayoutParams(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.55f)));
        final Dialog d = newSheet(col, true);
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            tabs.removeAllViews();
            TextView t1 = chip(s("contents"), !showMarksTab), t2 = chip(s("marks") + (marks.isEmpty() ? "" : " (" + marks.size() + ")"), showMarksTab);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(0, 0, dp(8), dp(10));
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1f); lp2.setMargins(0, 0, 0, dp(10));
            t1.setOnClickListener(v -> { showMarksTab = false; render[0].run(); });
            t2.setOnClickListener(v -> { showMarksTab = true; render[0].run(); });
            tabs.addView(t1, lp); tabs.addView(t2, lp2);
            final List<String> labels = new ArrayList<>();
            final List<Integer> pages = new ArrayList<>();
            final List<Integer> levels = new ArrayList<>();
            if (showMarksTab) {
                for (int p : marks) { labels.add(s("page") + " " + p); pages.add(p - 1); levels.add(0); }
                empty.setText(s("nomarks"));
            } else {
                for (MuPdfView.OutlineItem it : outline) { labels.add(it.title.isEmpty() ? "—" : it.title); pages.add(it.page0); levels.add(Math.min(it.level, 4)); }
                empty.setText(s("nocontents"));
            }
            empty.setVisibility(labels.isEmpty() ? View.VISIBLE : View.GONE);
            list.setVisibility(labels.isEmpty() ? View.GONE : View.VISIBLE);
            list.setAdapter(new BaseAdapter() {
                @Override public int getCount() { return labels.size(); }
                @Override public Object getItem(int i) { return labels.get(i); }
                @Override public long getItemId(int i) { return i; }
                @Override public View getView(int i, View cv, ViewGroup parent) {
                    LinearLayout row = new LinearLayout(MuReaderActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(4 + levels.get(i) * 16), dp(12), dp(4), dp(12));
                    TextView name = text(labels.get(i), 15f, levels.get(i) == 0, sheetFg);
                    name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END);
                    TextView pg = text(pages.get(i) >= 0 ? String.valueOf(pages.get(i) + 1) : "", 13f, false, barSub);
                    pg.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
                    row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
                    row.addView(pg, new LinearLayout.LayoutParams(-2, -2));
                    return row;
                }
            });
            list.setOnItemClickListener((p, v, i, id) -> {
                if (pages.get(i) >= 0) { view.goToPage(pages.get(i)); d.dismiss(); setBars(false); }
            });
            list.setOnItemLongClickListener((p, v, i, id) -> {
                if (showMarksTab) { marks.remove(pages.get(i) + 1); updateMarkIcon(); render[0].run(); return true; }
                return false;
            });
        };
        render[0].run();
    }

    // ---- appearance
    private void showSettings() {
        if (!opened) return;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("look"), 17f, true, sheetFg));
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.topMargin = dp(12);
        col.addView(row, rp);
        final String[] names = {s("paper"), s("sepia"), s("night")};
        final Runnable[] fill = new Runnable[1];
        final Dialog[] dref = new Dialog[1];
        fill[0] = () -> {
            row.removeAllViews();
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                TextView c = chip(names[i], theme == i);
                c.setOnClickListener(v -> {
                    theme = idx; applyLook();
                    // rebuild the sheet in the new colours
                    if (dref[0] != null) dref[0].dismiss();
                    showSettings();
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.setMargins(i == 0 ? 0 : dp(8), 0, 0, 0);
                row.addView(c, lp);
            }
        };
        fill[0].run();

        TextView bl = text(s("brightness"), 14f, false, sheetFg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2); bp.topMargin = dp(18);
        col.addView(bl, bp);
        SeekBar br = new SeekBar(this);
        br.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        br.setMax(70);
        br.setProgress(70 - Math.round(dim * 100));
        try { br.getProgressDrawable().setTint(accent); br.getThumb().setTint(accent); } catch (Throwable ignored) { }
        br.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) { dim = (70 - p) / 100f; view.setLook(theme, dim); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        col.addView(br, new LinearLayout.LayoutParams(-1, dp(40)));

        LinearLayout awakeRow = new LinearLayout(this);
        awakeRow.setOrientation(LinearLayout.HORIZONTAL);
        awakeRow.setGravity(Gravity.CENTER_VERTICAL);
        awakeRow.addView(text(s("awake"), 14f, false, sheetFg), new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(keepAwake);
        sw.setOnCheckedChangeListener((b, on) -> {
            keepAwake = on;
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        awakeRow.addView(sw);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2); ap.topMargin = dp(10);
        col.addView(awakeRow, ap);

        TextView fit = chip(s("fit") + "  ·  " + Math.round(view.zoom() * 100) + "%", false);
        fit.setOnClickListener(v -> { view.resetZoom(); if (dref[0] != null) dref[0].dismiss(); });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(14);
        col.addView(fit, fp);

        TextView info = text(total + " " + s("pages"), 12f, false, barSub);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(12);
        col.addView(info, ip);
        dref[0] = newSheet(col, true);
    }

    // ---- jump
    private void showJump() {
        if (!opened) return;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("jump") + "  (1 – " + total + ")", 16f, true, sheetFg));
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setSingleLine(true);
        et.setText(String.valueOf(curPage0 + 1));
        et.setSelectAllOnFocus(true);
        et.setTextColor(sheetFg);
        et.setTextSize(20f);
        et.setGravity(Gravity.CENTER);
        et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10);
        col.addView(et, lp);
        TextView go = chip(s("go"), true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(12);
        col.addView(go, gp);
        final Dialog d = newSheet(col, true);
        final Runnable doGo = () -> {
            try {
                int n = Integer.parseInt(et.getText().toString().trim());
                if (n >= 1 && n <= total) { view.goToPage(n - 1); d.dismiss(); setBars(false); return; }
            } catch (Throwable ignored) { }
            et.setError(" ");
        };
        go.setOnClickListener(v -> doGo.run());
        et.setOnEditorActionListener((tv, id, ev) -> { doGo.run(); return true; });
        et.requestFocus();
    }

    // ---- password
    private void showPasswordSheet(boolean wrong) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("pw_title"), 17f, true, sheetFg));
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setSingleLine(true);
        et.setHint(s("pw_hint"));
        et.setTextColor(sheetFg); et.setHintTextColor(barSub);
        et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10);
        col.addView(et, lp);
        if (wrong) {
            TextView err = text(s("pw_wrong"), 13f, false, 0xFFD64545);
            col.addView(err);
        }
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView cancel = chip(s("cancel"), false), ok = chip(s("ok"), true);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 1f); a.setMargins(0, dp(14), dp(8), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, -2, 1f); b.setMargins(0, dp(14), 0, 0);
        btns.addView(cancel, a); btns.addView(ok, b);
        col.addView(btns);
        final Dialog d = newSheet(col, false);
        d.setCancelable(false);
        final Runnable submit = () -> {
            String pw = et.getText().toString();
            d.dismiss();
            spinner.setVisibility(View.VISIBLE);
            view.open(path, pw, startPage0, startFrac);
        };
        ok.setOnClickListener(v -> submit.run());
        cancel.setOnClickListener(v -> { d.dismiss(); finishWith(null); });
        et.setOnEditorActionListener((tv, id, ev) -> { submit.run(); return true; });
        et.requestFocus();
    }

    // ================================================================= icons
    static final class IconView extends View {
        static final int BACK = 0, SEARCH = 1, MARK = 2, LIST = 3, SLIDERS = 4, UP = 5, DOWN = 6;
        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean filled = false;

        IconView(Context c, int kind) {
            super(c);
            this.kind = kind;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(2f * c.getResources().getDisplayMetrics().density);
            p.setColor(Color.BLACK);
            setClickable(true);
            setBackgroundResource(android.R.drawable.list_selector_background);
        }

        void setColor(int c) { p.setColor(c); invalidate(); }
        void setFilled(boolean f) { filled = f; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight()) * 0.5f;       // icon box (24 units)
            float u = s / 24f;
            float ox = (getWidth() - s) / 2f, oy = (getHeight() - s) / 2f;
            cv.save();
            cv.translate(ox, oy);
            cv.scale(u, u);
            float sw = p.getStrokeWidth();
            p.setStrokeWidth(2f * getResources().getDisplayMetrics().density / u);
            Path path = new Path();
            switch (kind) {
                case BACK: {
                    boolean rtl = getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                    if (rtl) { path.moveTo(9, 5); path.lineTo(16, 12); path.lineTo(9, 19); }
                    else { path.moveTo(15, 5); path.lineTo(8, 12); path.lineTo(15, 19); }
                    cv.drawPath(path, p); break;
                }
                case SEARCH:
                    cv.drawCircle(10.5f, 10.5f, 6.5f, p);
                    cv.drawLine(15.3f, 15.3f, 21f, 21f, p); break;
                case MARK: {
                    path.moveTo(6, 3.5f); path.lineTo(18, 3.5f); path.lineTo(18, 21); path.lineTo(12, 16.5f); path.lineTo(6, 21); path.close();
                    Paint.Style st = p.getStyle();
                    if (filled) p.setStyle(Paint.Style.FILL_AND_STROKE);
                    cv.drawPath(path, p);
                    p.setStyle(st); break;
                }
                case LIST:
                    cv.drawLine(8, 6, 21, 6, p); cv.drawLine(8, 12, 21, 12, p); cv.drawLine(8, 18, 21, 18, p);
                    cv.drawPoint(3.5f, 6, p); cv.drawPoint(3.5f, 12, p); cv.drawPoint(3.5f, 18, p); break;
                case SLIDERS:
                    cv.drawLine(4, 7, 20, 7, p); cv.drawLine(4, 17, 20, 17, p);
                    cv.drawCircle(9, 7, 2.4f, p); cv.drawCircle(15, 17, 2.4f, p); break;
                case UP:
                    path.moveTo(6, 15); path.lineTo(12, 9); path.lineTo(18, 15); cv.drawPath(path, p); break;
                case DOWN:
                    path.moveTo(6, 9); path.lineTo(12, 15); path.lineTo(18, 9); cv.drawPath(path, p); break;
                default: break;
            }
            p.setStrokeWidth(sw);
            cv.restore();
        }
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (view != null) view.trimMemory(level);
    }
}
