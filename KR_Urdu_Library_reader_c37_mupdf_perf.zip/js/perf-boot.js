/* Performance tier: the ONE place that decides Lite vs Full.
   Loaded synchronously from <head> (classic script) so html.perf-lite is set before first paint.
   js/features/perf.js is only a thin wrapper around window.__krPerf.

   Mode (localStorage krl_perf): "lite" | "full"; missing = Auto.
   Auto decides, in this order:
     1. measured  - krl_perf_auto = "lite", written by the scroll FPS probe when the phone really janks
     2. device    - krl_dev, written once by the Android plugin (RAM, low-RAM flag, cores, Android version)
     3. web       - navigator.deviceMemory / hardwareConcurrency (first launch, or APK without native info) */
(function () {
  var KEY = "krl_perf", AUTO = "krl_perf_auto", PROBE = "krl_perf_probe", DEV = "krl_dev";
  var root = document.documentElement;

  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function del(k) { try { localStorage.removeItem(k); } catch (e) {} }

  function mode() { var v = get(KEY); return v === "lite" || v === "full" ? v : "auto"; }
  function device() {
    try { var d = JSON.parse(get(DEV)); return d && typeof d.lite === "boolean" ? d : null; } catch (e) { return null; }
  }
  function source() {
    if (get(AUTO) === "lite") return "measured";
    if (device()) return "device";
    return "web";
  }
  function recommended() {
    var s = source();
    if (s === "measured") return "lite";
    if (s === "device") return device().lite ? "lite" : "full";
    var m = navigator.deviceMemory || 4, c = navigator.hardwareConcurrency || 4;
    return (m <= 3 || c <= 4) ? "lite" : "full";
  }
  function effective() { var m = mode(); return m === "auto" ? recommended() : m; }
  function apply() { root.classList.toggle("perf-lite", effective() === "lite"); }
  function setMode(m) {
    if (m === "lite" || m === "full") set(KEY, m);
    else { del(KEY); del(AUTO); del(PROBE); }   // back to Auto: forget old measurements, re-evaluate
    apply();
  }

  window.__krPerf = {
    keys: { MODE: KEY, AUTO: AUTO, PROBE: PROBE, DEV: DEV },
    get: get, set: set, del: del,
    mode: mode, device: device, source: source,
    recommended: recommended, effective: effective, apply: apply, setMode: setMode
  };
  apply();
})();
