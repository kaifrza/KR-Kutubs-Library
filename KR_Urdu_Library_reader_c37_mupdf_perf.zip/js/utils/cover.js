// Shared cover-image markup + persistent cover caching.
// The cache stores cover responses, while each visible <img> gets its own
// object URL. Object URLs are revoked only after their image leaves the DOM,
// so one screen/filter cannot invalidate covers rendered by another screen.

const COVER_CACHE_NAME = 'kr-urdu-library-covers-v1';
const coverInFlight = new Map();
const imageObjectUrls = new Map();
let cleanupObserver = null;

function canUseCoverCache() {
  return typeof window !== 'undefined' && 'caches' in window && typeof fetch === 'function';
}

function revokeImageObjectUrl(img) {
  const url = imageObjectUrls.get(img);
  if (!url) return;
  URL.revokeObjectURL(url);
  imageObjectUrls.delete(img);
}

function ensureCleanupObserver() {
  if (cleanupObserver || typeof MutationObserver === 'undefined' || !document.body) return;
  cleanupObserver = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const removedNode of mutation.removedNodes) {
        if (removedNode.nodeType !== 1) continue;
        if (removedNode.matches?.('img')) revokeImageObjectUrl(removedNode);
        removedNode.querySelectorAll?.('img').forEach(revokeImageObjectUrl);
      }
    }
  });
  cleanupObserver.observe(document.body, { childList: true, subtree: true });
}

async function getCachedCoverBlob(sourceUrl) {
  if (!sourceUrl || !canUseCoverCache()) return null;
  if (coverInFlight.has(sourceUrl)) return coverInFlight.get(sourceUrl);

  const task = (async () => {
    try {
      const cache = await caches.open(COVER_CACHE_NAME);
      const cached = await cache.match(sourceUrl, { ignoreVary: true });
      if (cached) {
        const blob = await cached.blob();
        if (blob && blob.size > 0) return blob;
      }

      const response = await fetch(sourceUrl, { cache: 'default' });
      if (!response.ok) throw new Error(`Cover request failed (${response.status})`);

      // Keep a copy for subsequent app visits. The displayed image still uses
      // the original URL or a per-image object URL, never a shared object URL.
      try { await cache.put(sourceUrl, response.clone()); } catch { /* best effort */ }
      return await response.blob();
    } catch {
      return null;
    } finally {
      coverInFlight.delete(sourceUrl);
    }
  })();

  coverInFlight.set(sourceUrl, task);
  return task;
}

// Returns "" when there is no cover: callers draw their own typeset cover underneath.
export function coverMarkup(coverUrl, alt = "") {
  if (!coverUrl) return "";
  return `<div class="cover-spinner" aria-hidden="true"></div><img loading="lazy" decoding="async" data-cover-src="${coverUrl}" alt="${alt}">`;
}

// Call this once the markup above has been inserted into the DOM.
export function wireCover(container) {
  if (!container) return;
  ensureCleanupObserver();

  const img = container.querySelector("img");
  const spinner = container.querySelector(".cover-spinner");
  if (!img) { spinner?.remove(); return; }

  const sourceUrl = img.dataset.coverSrc;
  if (!sourceUrl) { spinner?.remove(); return; }

  let settled = false;
  const clearSpinner = () => spinner?.remove();
  // A failed image is simply removed: the typeset cover underneath stays visible.
  const dropImage = () => {
    if (settled) return;
    settled = true;
    revokeImageObjectUrl(img);
    clearSpinner();
    img.remove();
  };

  img.addEventListener("load", () => {
    settled = true;
    clearSpinner();
    img.classList.add("is-loaded");
  }, { once: true });
  img.addEventListener("error", dropImage, { once: true });

  // Always resolve from the same canonical source URL. If Cache Storage is
  // available, use its response as a private per-image blob URL; otherwise
  // fall back to the original URL. No shared/revoked object URL is ever reused.
  getCachedCoverBlob(sourceUrl).then((blob) => {
    if (settled || !img.isConnected) return;

    if (blob && typeof URL?.createObjectURL === 'function') {
      try {
        const objectUrl = URL.createObjectURL(blob);
        imageObjectUrls.set(img, objectUrl);
        img.src = objectUrl;
        return;
      } catch { /* fall through to canonical URL */ }
    }

    img.src = sourceUrl;
  }).catch(() => {
    if (!settled && img.isConnected) img.src = sourceUrl;
  });
}

window.addEventListener('pagehide', () => {
  for (const img of imageObjectUrls.keys()) revokeImageObjectUrl(img);
  coverInFlight.clear();
});
