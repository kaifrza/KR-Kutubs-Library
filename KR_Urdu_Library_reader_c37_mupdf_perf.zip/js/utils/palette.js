/* Pulls three vibrant colours out of a cover image so the detail screen can paint a smooth,
   blur-free colour wash behind it. Returns null when the image can't be read (e.g. cross-origin). */

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
  let h = 0, s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
  }
  return [h, s, l];
}

function region(data, w, x0, x1, y0, y1) {
  let r = 0, g = 0, b = 0, total = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const i = (y * w + x) * 4;
      if (data[i + 3] < 200) continue;
      const max = Math.max(data[i], data[i + 1], data[i + 2]), min = Math.min(data[i], data[i + 1], data[i + 2]);
      const sat = max ? (max - min) / max : 0;
      const weight = 0.15 + sat * 1.6;            // favour colourful pixels over white/grey paper
      r += data[i] * weight; g += data[i + 1] * weight; b += data[i + 2] * weight; total += weight;
    }
  }
  if (!total) return null;
  return rgbToHsl(r / total, g / total, b / total);
}

function vibrant([h, s, l]) {
  const sat = Math.min(0.82, Math.max(0.38, s * 1.3));
  const lit = Math.min(0.6, Math.max(0.42, l));
  return `hsl(${Math.round(h)} ${Math.round(sat * 100)}% ${Math.round(lit * 100)}%)`;
}

export function coverPalette(img) {
  try {
    const w = 12, h = 18;
    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, w, h);
    const { data } = ctx.getImageData(0, 0, w, h);
    const a = region(data, w, 0, 7, 0, 9);        // upper area
    const b = region(data, w, 5, 12, 3, 12);      // right / middle
    const c = region(data, w, 2, 10, 8, 18);      // lower area
    if (!a || !b || !c) return null;
    return { "--amb-a": vibrant(a), "--amb-b": vibrant(b), "--amb-c": vibrant(c) };
  } catch {
    return null;
  }
}
