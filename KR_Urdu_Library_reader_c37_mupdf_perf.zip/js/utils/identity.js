/* Automatic look for classes and categories. Nothing is stored in the backend: the colour comes
   from the item's id and the icon from keywords in its id / name (Urdu or English). A brand-new
   class or category therefore gets a stable colour and a sensible icon the moment it is added;
   when no keyword matches it falls back to a generic icon. */
import { icon } from "./icons.js";

const hash = str => { let h = 5381; for (const ch of String(str)) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0; return h; };

// Urdu / Arabic ordinal names used for years of study
const ORDINALS = [["اعدادیہ", 0], ["اولیٰ", 1], ["اولی", 1], ["ثانیہ", 2], ["ثالثہ", 3], ["رابعہ", 4], ["خامسہ", 5], ["سادسہ", 6], ["سابعہ", 7], ["ثامنہ", 8], ["تاسعہ", 9], ["عاشرہ", 10]];

const TOPICS = [
  [/quran|qur'?an|tafs[ei]r|tajw[ei]d|قرآن|قران|تفسیر|تجوید/i, "quran"],
  [/hadi?th|sunn?ah|mishkat|حدیث|سنت/i, "hadith"],
  [/fiqh|fiqah|masail|usool|اصول|فقہ|فقه|مسائل/i, "scale"],
  [/aqee?d|aqaid|akaid|kalam|iman|عقائد|عقیدہ|کلام|ایمان/i, "shield"],
  [/seer|sira|nabi|prophet|سیرت|نبی/i, "crescent"],
  [/histor|tarikh|tareekh|تاریخ/i, "hourglass"],
  [/adab|urdu|liter|poe|shayari|essay|ادب|اردو|شاعری|نثر|مضمون/i, "pen"],
  [/arab|nahw|sarf|grammar|lugh|language|عربی|نحو|صرف|لغت|زبان/i, "globe"],
  [/tasawwuf|akhlaq|tazkiy|suluk|dua|zikr|تصوف|اخلاق|تزکیہ|دعا|ذکر/i, "heart"]
];

export const TONES = 6; // matches .tc-0 … .tc-5 in book-card.css

function classNumber(c) {
  const fromId = /(\d+)\s*$/.exec(String(c.id || ""));
  if (fromId) return Number(fromId[1]);
  const name = String(c.name || "");
  for (const [word, n] of ORDINALS) if (name.includes(word)) return n;
  return null;
}

/** → { tone: 0..5, glyph: html }  for a class or a category */
export function identityFor(kind, item) {
  if (kind === "class") {
    const n = classNumber(item);
    return {
      tone: (n === null ? hash(item.id) : n) % TONES,
      glyph: n ? `<b class="class-num">${n}</b>` : icon("cap")   // no number (or the preparatory year) → cap icon
    };
  }
  const hay = `${item.id} ${item.nameEn || ""} ${item.name || ""}`;
  const hit = TOPICS.find(([re]) => re.test(hay));
  return { tone: hash(item.id) % TONES, glyph: icon(hit ? hit[1] : "layers") };
}
