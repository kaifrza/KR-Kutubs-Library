/* Inline UI icons (no icon-font dependency, so they also work offline in the APK).
   Usage: icon("search") or icon("pdf", "file-glyph"). Styling lives in tab-screens.css (.ico). */

const PATHS = {
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  refresh: '<path d="M4.6 12a7.4 7.4 0 0 1 12.9-5l2 2.1"/><path d="M19.6 4.6v4.8h-4.8"/><path d="M19.4 12a7.4 7.4 0 0 1-12.9 5l-2-2.1"/><path d="M4.4 19.4v-4.8h4.8"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.8c0-.5.4-.8.8-.8h3.4c.4 0 .8.3.8.8V7"/><path d="M6.5 7l.8 11.4c.1.9.8 1.6 1.7 1.6h6c.9 0 1.6-.7 1.7-1.6L17.5 7"/><path d="M10 11v5M14 11v5"/>',
  folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2.2h7a2 2 0 0 1 2 2V17.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
  phone: '<rect x="7" y="2.8" width="10" height="18.4" rx="2.4"/><path d="M11 18.2h2"/>',
  pdf: '<path d="M7 3.5h6.5l5 5V19a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5z"/><path d="M13.5 3.5v5h5"/><path d="M8.7 16.2h6.6M8.7 13h3.4"/>',
  book: '<path d="M12 6.6C10.3 5.3 8 4.7 4.6 4.9c-.3 0-.6.3-.6.6v11.7c0 .3.3.6.6.6 3.3-.2 5.5.4 7.4 1.8 1.9-1.4 4.1-2 7.4-1.8.3 0 .6-.3.6-.6V5.5c0-.3-.3-.6-.6-.6C16 4.7 13.7 5.3 12 6.6z"/><path d="M12 6.8v11.6"/>',
  download: '<path d="M12 4v11"/><path d="M7.5 11.5 12 16l4.5-4.5"/><path d="M5 19.5h14"/>',
  alert: '<path d="M12 4.5 20.5 19h-17z"/><path d="M12 10v4.2"/><path d="M12 16.9h.01"/>',
  arrow: '<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>',
  chevron: '<path d="M9.5 5.5 16 12l-6.5 6.5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M18.5 5.5l-1.7 1.7M7.2 16.8l-1.7 1.7"/>',
  moon: '<path d="M20 14.2A8.2 8.2 0 0 1 9.8 4 8.2 8.2 0 1 0 20 14.2z"/>',
  bolt: '<path d="M13 3 5.5 13.2h5.2L10 21l8-10.4h-5.4z"/>',
  auto: '<rect x="3.5" y="4.5" width="17" height="11.5" rx="2.4"/><path d="M8.5 20h7M12 16v4"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.4 2.4 3.6 5.2 3.6 8.5s-1.2 6.1-3.6 8.5c-2.4-2.4-3.6-5.2-3.6-8.5S9.6 5.9 12 3.5z"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.4a4.3 4.3 0 0 1 7.5 2.4C19.5 15.4 12 20 12 20z"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  disk: '<rect x="3.5" y="13" width="17" height="6.5" rx="2.2"/><path d="M5.5 13l2-7.2c.2-.7.8-1.3 1.6-1.3h5.8c.8 0 1.4.5 1.6 1.3l2 7.2"/><path d="M16.5 16.3h.01M13.5 16.3h.01"/>',
  database: '<ellipse cx="12" cy="6" rx="7.5" ry="2.8"/><path d="M4.5 6v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8V6"/><path d="M4.5 12v6c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-6"/>',
  scale: '<path d="M12 4v16M7 20h10"/><path d="M5 7.5h14"/><path d="M5 7.5 2.8 13a3 3 0 0 0 4.4 0zM19 7.5 16.8 13a3 3 0 0 0 4.4 0z"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5"/><path d="M12 7.9h.01"/>',
  library: '<path d="M4.5 4.5v15M9 4.5v15"/><path d="M13.2 5.6l3.3-1 3.3 12.3-3.3 1z"/>',
  broom: '<path d="M14.5 3.5 20 9"/><path d="M13 7.2l3.8 3.8-5.4 7.4c-.6.8-1.7.9-2.4.2L5 15.6c-.7-.7-.6-1.8.2-2.4z"/><path d="M7 17.5 5 20"/>',
  grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/>',
  list: '<path d="M9 6.5h11M9 12h11M9 17.5h11"/><circle cx="4.8" cy="6.5" r="1"/><circle cx="4.8" cy="12" r="1"/><circle cx="4.8" cy="17.5" r="1"/>',
  quran: '<path d="M12 6.6C10.3 5.3 8 4.7 4.6 4.9c-.3 0-.6.3-.6.6v11.7c0 .3.3.6.6.6 3.3-.2 5.5.4 7.4 1.8 1.9-1.4 4.1-2 7.4-1.8.3 0 .6-.3.6-.6V5.5c0-.3-.3-.6-.6-.6C16 4.7 13.7 5.3 12 6.6z"/><path d="m12 9.4.9 1.9 2 .3-1.5 1.4.4 2-1.8-1-1.8 1 .4-2-1.5-1.4 2-.3z"/>',
  hadith: '<path d="M8 4.5h9.5a1.5 1.5 0 0 1 1.5 1.5v9"/><path d="M5 8a2 2 0 0 1 2-2h7.5a2 2 0 0 1 2 2v10.5a1.5 1.5 0 0 1-1.5 1.5H8.5A3.5 3.5 0 0 1 5 16.5z"/><path d="M8.5 10.5h5M8.5 13.5h5"/>',
  shield: '<path d="M12 3.6 5 6.2v5.4c0 4.2 2.8 7.2 7 8.8 4.2-1.6 7-4.6 7-8.8V6.2z"/><path d="m9 12 2.2 2.2L15.2 10"/>',
  crescent: '<path d="M19.5 14.6A8 8 0 0 1 9.4 4.5a8 8 0 1 0 10.1 10.1z"/><path d="m16.8 5.2.5 1.3 1.3.5-1.3.5-.5 1.3-.5-1.3-1.3-.5 1.3-.5z"/>',
  hourglass: '<path d="M7 4h10M7 20h10"/><path d="M8 4c0 4 2.2 5 4 8-1.8 3-4 4-4 8"/><path d="M16 4c0 4-2.2 5-4 8 1.8 3 4 4 4 8"/>',
  pen: '<path d="m4.5 19.5.9-4L16 4.9a1.8 1.8 0 0 1 2.6 0l.5.5a1.8 1.8 0 0 1 0 2.6L8.5 18.6z"/><path d="m14.2 6.7 3.1 3.1"/>',
  cap: '<path d="M12 4.4 2.9 9.1 12 13.8l9.1-4.7z"/><path d="M6.6 11.7v4.3c0 1.4 2.5 2.8 5.4 2.8s5.4-1.4 5.4-2.8v-4.3"/><path d="M21.1 9.1v5.4"/>',
  layers: '<path d="M12 3.8 3.5 8.3 12 12.8l8.5-4.5z"/><path d="M3.5 12.1 12 16.6l8.5-4.5"/><path d="M3.5 15.9 12 20.4l8.5-4.5"/>',
  more: '<circle cx="5.5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="18.5" cy="12" r="1.5"/>'
};

export function icon(name, cls = "") {
  return `<svg class="ico${cls ? " " + cls : ""}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${PATHS[name] || ""}</svg>`;
}
