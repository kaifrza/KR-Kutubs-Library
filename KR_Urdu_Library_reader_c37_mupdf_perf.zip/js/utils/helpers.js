export function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

export function formatPages(pages, lang) {
  if (!pages) return "";
  return lang === "ur" ? `${pages} صفحات` : `${pages} pages`;
}
