const ROUTES = new Set(["home","catalogue","classes","class","categories","category","favorites","search","book","reader","more","downloads","local"]);
const HISTORY_KEY = "krulRoute";

// SPA views manage their own scroll position; prevent browser history from
// restoring a stale position when returning from reader/book detail.
if ("scrollRestoration" in history) history.scrollRestoration = "manual";

function buildHash(route, params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value) !== "") query.set(key, String(value));
  });
  return query.toString() ? `#${route}?${query}` : `#${route}`;
}

function normalizeState(route, params) {
  return { [HISTORY_KEY]: true, route, params: { ...params } };
}

let scrollSaveLocked = false;
/** While a screen is being re-built after Back, layout shrinks/grows and fires scroll events that must not overwrite the saved position. */
export function lockScrollSave(v) { scrollSaveLocked = Boolean(v); }

export function saveCurrentScrollPosition() {
  if (scrollSaveLocked) return;
  const current = history.state;
  if (!current?.[HISTORY_KEY]) return;
  history.replaceState({ ...current, scrollY: Math.max(0, Math.round(window.scrollY || 0)) }, "");
}

export function replaceRoute(route, params = {}) {
  if (!ROUTES.has(route)) route = "home";
  saveCurrentScrollPosition();
  const hash = buildHash(route, params);
  const current = history.state;
  const state = { ...normalizeState(route, params), scrollY: current?.scrollY || 0 };
  history.replaceState(state, "", hash);
}

export function navigate(route, params = {}, { replace = false } = {}) {
  if (!ROUTES.has(route)) route = "home";
  // Capture the outgoing view before changing history. This lets Back return
  // to the exact place the user left instead of resetting the parent page.
  saveCurrentScrollPosition();
  const hash = buildHash(route, params);
  const state = { ...normalizeState(route, params), scrollY: 0 };
  history[replace ? "replaceState" : "pushState"](state, "", hash);
  window.dispatchEvent(new PopStateEvent("popstate", { state }));
}

let scrollFrame = 0;
window.addEventListener("scroll", () => {
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    saveCurrentScrollPosition();
  });
}, { passive: true });

export function readRoute() {
  const raw = location.hash.replace(/^#/, "") || "home";
  const [routeRaw, queryRaw = ""] = raw.split("?");
  const route = ROUTES.has(routeRaw) ? routeRaw : "home";
  const params = Object.fromEntries(new URLSearchParams(queryRaw));
  return { route, params };
}

/**
 * Seed a safe in-app history entry on a direct/reloaded URL. This means an
 * Android/browser Back from a deep-linked book returns to Home instead of
 * unexpectedly leaving the library. Normal navigation remains native
 * history-based, so forward/back continue to behave predictably.
 */
export function ensureAppHistory() {
  if (history.state?.[HISTORY_KEY]) return;
  const current = readRoute();
  const currentHash = buildHash(current.route, current.params);
  history.replaceState({ ...normalizeState("home", {}), scrollY: 0 }, "", "#home");
  if (currentHash !== "#home") {
    history.pushState({ ...normalizeState(current.route, current.params), scrollY: 0 }, "", currentHash);
  }
}


export function syncHashNavigation() {
  const current = readRoute();
  const state = history.state;
  const sameRoute = state?.[HISTORY_KEY] && state.route === current.route &&
    JSON.stringify(state.params || {}) === JSON.stringify(current.params || {});
  if (sameRoute) return;
  history.replaceState({ ...normalizeState(current.route, current.params), scrollY: 0 }, "");
}

export function isAppHistoryEntry() {
  return Boolean(history.state?.[HISTORY_KEY]);
}

