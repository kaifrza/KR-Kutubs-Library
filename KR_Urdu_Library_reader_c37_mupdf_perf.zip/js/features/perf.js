// Performance mode: "auto" (recommended for this phone), "full" (all effects) or "lite" (flat, lightest).
// All decision logic lives in js/perf-boot.js (window.__krPerf), which runs from <head> before first paint.
// This module only adds what needs the app: native device info and the scroll FPS probe.
import { getNativePlugin } from "./download-manager.js";

const P = window.__krPerf;
const K = P.keys;

export const perfRecommended = () => P.recommended();
export const getPerfMode = () => P.mode();
export const effectivePerf = () => P.effective();
export const perfSource = () => P.source();   // "measured" | "device" | "web"
export const applyPerf = () => P.apply();

export function setPerfMode(mode) {
  P.setMode(mode);
  if (mode === "lite" || mode === "full") stopPerfProbe();
  else startPerfProbe();                       // Auto again: measure afresh
}

// ---- 1) native device info (Android plugin KRDownloader.getDeviceInfo) ----------------------------
// Cached in localStorage so the NEXT launch already has the right tier before first paint.
async function readNativeDevice() {
  const plugin = getNativePlugin();
  if (!plugin || typeof plugin.getDeviceInfo !== "function") return;
  let d;
  try { d = await plugin.getDeviceInfo(); } catch { return; }   // older APK without the method
  if (!d) return;
  const mem = Number(d.totalMemMb) || 0, cores = Number(d.cores) || 0, sdk = Number(d.sdk) || 0;
  const lite = Boolean(d.lowRam)
    || (mem > 0 && mem <= 3300)      // "3 GB" phones report ~2.7-3.0 GB, "4 GB" phones ~3.6+ GB
    || (cores > 0 && cores <= 4)
    || (sdk > 0 && sdk <= 26);       // Android 8.0 or older
  P.set(K.DEV, JSON.stringify({ lite, mem, cores, sdk, hz: Number(d.refreshHz) || 60, lowRam: Boolean(d.lowRam), v: 1 }));
  applyPerf();
}

// ---- 2) scroll FPS probe -------------------------------------------------------------------------
// Catches phones that look strong on paper (e.g. 8 weak cores) but still stutter with blur.
// Only runs in Auto while the effective tier is Full. Measures frame gaps while the user really scrolls,
// in windows of 60 frames. Two bad windows in a row -> Lite (remembered). Three good windows -> "ok", stop.
const WIN = 60, SKIP = 4, JANK_MS = 28;
let stopProbe = null;

export function stopPerfProbe() { if (stopProbe) { const s = stopProbe; stopProbe = null; s(); } }

export function startPerfProbe() {
  stopPerfProbe();
  try {
    if (P.mode() !== "auto" || P.effective() !== "full" || P.get(K.PROBE)) return;
  } catch { return; }

  let last = 0, prev = 0, seen = 0, raf = 0, bad = 0, good = 0, win = [];

  const finish = (verdict) => {
    stopPerfProbe();
    P.set(K.PROBE, verdict);
    if (verdict === "lite") { P.set(K.AUTO, "lite"); applyPerf(); }
  };
  const judge = () => {
    const w = win; win = [];
    const jank = w.filter(d => d > JANK_MS).length / w.length;
    const mean = w.reduce((a, b) => a + b, 0) / w.length;
    if (jank > 0.25 || mean > 26) { bad++; good = 0; } else { good++; bad = 0; }
    if (bad >= 2) finish("lite");
    else if (good >= 3) finish("ok");
  };
  const loop = (t) => {
    raf = 0;
    if (!stopProbe) return;
    if (document.hidden || t - last > 120) { prev = 0; seen = 0; return; }   // scrolling stopped
    if (prev) {
      const dt = t - prev;
      if (dt < 500 && ++seen > SKIP) { win.push(dt); if (win.length >= WIN) judge(); }
    }
    prev = t;
    if (stopProbe) raf = requestAnimationFrame(loop);
  };
  const onScroll = () => { last = performance.now(); if (!raf && stopProbe) raf = requestAnimationFrame(loop); };

  document.addEventListener("scroll", onScroll, { capture: true, passive: true });
  stopProbe = () => {
    document.removeEventListener("scroll", onScroll, true);
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  };
}

// Called once from app init. Never throws.
export function initPerf() {
  try {
    readNativeDevice().catch(() => {});
    setTimeout(() => { try { startPerfProbe(); } catch {} }, 3000);   // let the first screen settle first
  } catch {}
}
