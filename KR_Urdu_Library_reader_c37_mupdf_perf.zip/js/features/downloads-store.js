// Small record of books downloaded through this app (title, size, Android download id).
// The PDF files themselves stay in the phone's Downloads folder; nothing is copied here.
const KEY = "krl_downloads_v1";

export function getDownloads(){
  try{
    const list = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(list) ? list : [];
  }catch{
    return [];
  }
}

function save(list){
  try{ localStorage.setItem(KEY, JSON.stringify(list)); }catch{}
}

export function getDownloadRecord(bookId){
  return getDownloads().find(item => item.bookId === bookId) || null;
}

export function addDownloadRecord(record){
  if(!record || record.downloadId === undefined || record.downloadId === null) return;
  const list = getDownloads().filter(item => item.bookId !== record.bookId);
  list.unshift({ ...record, savedAt: record.savedAt || Date.now() });
  save(list.slice(0, 500));
}

export function removeDownloadRecord(bookId){
  save(getDownloads().filter(item => item.bookId !== bookId));
}
