// Loads PDF.js. Inside the Android app it is bundled with the APK (/vendor/pdfjs),
// so reading works fully offline. In a normal browser it falls back to CDNs.
let pdfPromise = null;

export async function loadPdfJs(){
  if(window.pdfjsLib?.getDocument) return window.pdfjsLib;
  if(!pdfPromise){
    const candidates = [
      ["/vendor/pdfjs/pdf.mjs", "/vendor/pdfjs/pdf.worker.mjs"],
      ["https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.mjs", "https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.mjs"],
      ["https://unpkg.com/pdfjs-dist@4.10.38/build/pdf.mjs", "https://unpkg.com/pdfjs-dist@4.10.38/build/pdf.worker.mjs"],
      ["https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs", "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs"]
    ];
    pdfPromise = (async()=>{
      let lastError;
      for(const [moduleUrl, workerUrl] of candidates){
        try{
          const mod = await import(moduleUrl);
          const pdfjs = mod?.default || mod;
          if(!pdfjs?.getDocument) throw new Error("PDF.js API unavailable.");
          if(pdfjs.GlobalWorkerOptions) pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
          window.pdfjsLib = pdfjs;
          return pdfjs;
        }catch(err){ lastError = err; }
      }
      throw new Error(`PDF.js could not be initialized. ${lastError?.message || "All module sources failed."}`);
    })().catch(err=>{ pdfPromise = null; throw err; });
  }
  return pdfPromise;
}
