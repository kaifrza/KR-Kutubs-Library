// Native MuPDF reader bridge.
// If the APK contains the MuPDF reader (MuReaderActivity) the book opens there; otherwise (older APK,
// MuPDF missing from the build, or the file could not be opened) the caller falls back to the pdf.js reader.
// All reading state still lives in localStorage: we pass it in and save what comes back.
import { getNativePlugin } from "./download-manager.js";
import { getBookProgress, setProgress } from "../utils/storage.js";
import { getReaderPrefs, saveReaderPrefs, getBookmarks, setBookmarks, getReadingPosition, saveReadingPosition, migrateReaderKey } from "./reader-prefs.js";

const ENGINE_KEY = "krl_reader_engine";   // set to "pdfjs" in localStorage to force the old reader

export function nativeReaderWanted(){
  try{ if(localStorage.getItem(ENGINE_KEY) === "pdfjs") return false; }catch{}
  const plugin = getNativePlugin();
  return Boolean(plugin && typeof plugin.openMuReader === "function" && window.__krMuOk !== false);
}

/** Resolves true when the native reader handled (and closed) the book, false when the caller should use pdf.js. */
export async function openInNativeReader({ lang, title, source, progressKey, legacyKey, onFallback }){
  if(!nativeReaderWanted()) return false;
  const plugin = getNativePlugin();
  const key = progressKey;
  if(key && legacyKey){
    migrateReaderKey(legacyKey, key);
    if(!getBookProgress(key)){ const old = getBookProgress(legacyKey); if(old) setProgress(key, old); }
  }
  const prefs = getReaderPrefs();
  const pos = key ? getReadingPosition(key) : null;
  try{
    const r = await plugin.openMuReader({
      ...source,
      title, lang,
      page: pos ? pos.page : 1, frac: pos ? pos.frac : 0,
      theme: prefs.theme, dim: prefs.dim, keepAwake: prefs.keepAwake, autoHide: prefs.autoHide,
      marks: key ? getBookmarks(key) : []
    });
    if(r && r.page && key){
      const total = Number(r.total) || 0;
      if(total) setProgress(key, { page: r.page, totalPages: total, percent: Math.round(r.page / total * 100) });
      saveReadingPosition(key, r.page, Number(r.frac) || 0);
    }
    if(r){
      saveReaderPrefs({ theme: r.theme || prefs.theme, dim: Number.isFinite(r.dim) ? r.dim : prefs.dim, keepAwake: Boolean(r.keepAwake) });
      if(key && Array.isArray(r.marks)) setBookmarks(key, r.marks);
    }
    return true;
  }catch(err){
    console.warn("Native reader unavailable, using pdf.js:", err && (err.message || err));
    // "not implemented"/"unavailable" means this APK has no MuPDF: stop trying for this session
    const m = String(err && (err.message || err.code) || "");
    if(/not implemented|unavailable|not included/i.test(m)) window.__krMuOk = false;
    try{ localStorage.setItem("krl_mu_last_error", m.slice(0, 300)); }catch{}
    try{ onFallback && onFallback(/not implemented|unavailable|not included/i.test(m) ? "not in this APK build" : m); }catch{}
    return false;
  }
}
