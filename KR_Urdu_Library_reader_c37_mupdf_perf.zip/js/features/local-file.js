// Read a PDF straight from phone storage (Downloads folder or an "Open with" file)
// through the native KRDownloader plugin. Nothing is copied into app storage.
import { getNativePlugin } from "./download-manager.js";

const CHUNK = 262144;

function base64ToBytes(b64){
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for(let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function nativeReaderAvailable(){
  return Boolean(getNativePlugin());
}

// source: { id: <Android download id> } or { uri: "content://..." }
export async function openNativeFile(source){
  const plugin = getNativePlugin();
  if(!plugin) throw new Error("Native file access is only available in the Android app.");
  const info = await plugin.openFile(source);
  const handle = info?.handle;
  const size = Number(info?.size);
  if(handle === undefined || !Number.isFinite(size) || size <= 0) throw new Error("Could not open the file.");

  async function readRange(begin, end){
    begin = Math.max(0, Math.floor(begin));
    end = Math.min(size, Math.floor(end));
    const out = new Uint8Array(Math.max(0, end - begin));
    let pos = begin;
    while(pos < end){
      const want = Math.min(CHUNK, end - pos);
      const res = await plugin.readChunk({ handle, offset: pos, length: want });
      const bytes = base64ToBytes(res?.data || "");
      if(!bytes.length) break;
      out.set(bytes, pos - begin);
      pos += bytes.length;
    }
    return out;
  }

  return {
    size,
    readRange,
    close: () => { try{ Promise.resolve(plugin.closeFile({ handle })).catch(() => {}); }catch{} }
  };
}

const withTimeout = (promise, ms) => Promise.race([
  promise,
  new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), ms))
]);

// Preferred: PDF.js asks only for the byte ranges it needs (small memory use, big books OK).
// Fallback: read the whole file into memory once (works for files up to a few hundred MB).
export async function loadLocalPdf(pdfjs, file, password){
  try{
    const head = await file.readRange(0, Math.min(file.size, 131072));
    const transport = new pdfjs.PDFDataRangeTransport(file.size, head, true);
    transport.requestDataRange = (begin, end) => {
      file.readRange(begin, end)
        .then(chunk => transport.onDataRange(begin, chunk))
        .catch(err => console.warn("Range read failed", err));
    };
    const task = pdfjs.getDocument({
      range: transport,
      length: file.size,
      rangeChunkSize: 262144,
      disableStream: true,
      disableAutoFetch: true,
      ...(password ? { password } : {})
    });
    try{
      const pdf = await withTimeout(task.promise, 15000);
      return { pdf, task, mode: "range" };
    }catch(err){
      try{ task.destroy(); }catch{}
      if(err?.name === "PasswordException") throw err;
      console.warn("Range loading failed, reading whole file instead.", err);
    }
  }catch(err){
    if(err?.name === "PasswordException") throw err;
    console.warn("Range setup failed, reading whole file instead.", err);
  }

  const bytes = await file.readRange(0, file.size);
  const task = pdfjs.getDocument({ data: bytes, disableStream: true, disableAutoFetch: true, ...(password ? { password } : {}) });
  const pdf = await task.promise;
  return { pdf, task, mode: "data" };
}
