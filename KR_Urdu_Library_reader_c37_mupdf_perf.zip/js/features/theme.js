import { getTheme, setTheme } from "../utils/storage.js";

function resolve(theme) {
  return theme === "system"
    ? (window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light")
    : theme;
}

const BAR_COLORS = { dark: "#101512", light: "#f7f7f5" }; // keep in sync with --bg

// In the Android APK, colour the native window + status/navigation bars to match the theme
// (otherwise a white strip shows around the WebView). No-op in browsers / SPCK preview.
let lastBars = "";
function syncNativeBars(actual) {
  if (lastBars === actual) return;
  try {
    const cap = window.Capacitor;
    if (!cap || typeof cap.nativePromise !== "function") return;
    if (!(cap.isNativePlatform?.() || cap.getPlatform?.() === "android")) return;
    lastBars = actual;
    Promise.resolve(cap.nativePromise("KRDownloader", "setSystemBars", {
      color: BAR_COLORS[actual] || BAR_COLORS.light,
      light: actual !== "dark"
    })).catch(() => { lastBars = ""; });
  } catch { lastBars = ""; }
}

export function applyTheme(theme = getTheme()) {
  const actual = resolve(theme);
  document.documentElement.dataset.theme = actual;
  document.documentElement.dataset.themePreference = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = actual === "dark" ? "#101512" : "#f7f7f5";
  syncNativeBars(actual);
  return actual;
}

export function changeTheme(theme) {
  if (!setTheme(theme)) return;
  applyTheme(theme);
}

export function watchSystemTheme() {
  const media = window.matchMedia?.("(prefers-color-scheme: dark)");
  if (!media) return;
  const handler = () => { if (getTheme() === "system") applyTheme("system"); };
  media.addEventListener?.("change", handler);
}
