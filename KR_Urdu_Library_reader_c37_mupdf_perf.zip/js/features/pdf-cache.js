/*
 * KR Urdu Library — persistent PDF cache
 *
 * Successfully streamed downloads are kept locally for offline reading.
 * Cache writes are best-effort: they never turn a successful download into a
 * failed one. The cache uses a small metadata store so quota/LRU decisions do
 * not load every PDF Blob into memory.
 */

const DB_NAME = "kr-urdu-library-cache";
const DB_VERSION = 2;
const PDF_STORE = "pdfs";
const META_STORE = "meta";
const MAX_CACHE_BYTES = 512 * 1024 * 1024;
const MAX_SINGLE_FILE_BYTES = 150 * 1024 * 1024;

let dbPromise = null;

function canUseIndexedDB() { return typeof indexedDB !== "undefined"; }

function openDb() {
  if (!canUseIndexedDB()) return Promise.reject(new Error("IndexedDB unavailable"));
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PDF_STORE)) db.createObjectStore(PDF_STORE, { keyPath: "bookId" });
      if (!db.objectStoreNames.contains(META_STORE)) {
        const meta = db.createObjectStore(META_STORE, { keyPath: "bookId" });
        meta.createIndex("lastAccessedAt", "lastAccessedAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open PDF cache"));
  }).catch(error => { dbPromise = null; throw error; });
  return dbPromise;
}

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB request failed"));
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("IndexedDB transaction failed"));
    tx.onabort = () => reject(tx.error || new Error("IndexedDB transaction aborted"));
  });
}

async function getMeta(db, bookId) {
  return req(db.transaction(META_STORE, "readonly").objectStore(META_STORE).get(bookId));
}

async function getAllMeta(db) {
  return req(db.transaction(META_STORE, "readonly").objectStore(META_STORE).getAll());
}

async function deleteBookInternal(db, bookId) {
  const tx = db.transaction([PDF_STORE, META_STORE], "readwrite");
  tx.objectStore(PDF_STORE).delete(bookId);
  tx.objectStore(META_STORE).delete(bookId);
  await txDone(tx);
}

export async function getCachedPdf(bookId) {
  if (!bookId || !canUseIndexedDB()) return null;
  try {
    const db = await openDb();
    const tx = db.transaction([PDF_STORE, META_STORE], "readwrite");
    const record = await req(tx.objectStore(PDF_STORE).get(bookId));
    if (!record?.blob || !record.blob.size) return null;
    const meta = await req(tx.objectStore(META_STORE).get(bookId));
    if (meta) {
      meta.lastAccessedAt = Date.now();
      tx.objectStore(META_STORE).put(meta);
    }
    await txDone(tx);
    return { ...record, ...(meta || {}) };
  } catch (error) {
    console.warn("KR Urdu Library PDF cache read failed", error);
    return null;
  }
}

export async function hasCachedPdf(bookId) {
  if (!bookId || !canUseIndexedDB()) return false;
  try {
    const db = await openDb();
    const meta = await getMeta(db, bookId);
    return !!meta?.size;
  } catch { return false; }
}

export async function cachePdf(bookId, blob, meta = {}) {
  if (!bookId || !(blob instanceof Blob) || !blob.size || !canUseIndexedDB()) return false;
  if (blob.size > MAX_SINGLE_FILE_BYTES || blob.size > MAX_CACHE_BYTES) return false;

  try {
    const db = await openDb();
    const existing = await getMeta(db, bookId);
    const all = await getAllMeta(db);
    let total = all.reduce((sum, item) => sum + (Number(item?.size) || 0), 0) - (Number(existing?.size) || 0);

    const candidates = all
      .filter(item => item?.bookId !== bookId)
      .sort((a, b) => (Number(a?.lastAccessedAt) || 0) - (Number(b?.lastAccessedAt) || 0));
    for (const candidate of candidates) {
      if (total + blob.size <= MAX_CACHE_BYTES) break;
      await deleteBookInternal(db, candidate.bookId);
      total -= Number(candidate?.size) || 0;
    }
    if (total + blob.size > MAX_CACHE_BYTES) return false;

    const now = Date.now();
    const record = {
      bookId: String(bookId),
      blob,
      size: blob.size,
      contentType: blob.type || "application/pdf"
    };
    const metadata = {
      bookId: String(bookId),
      size: blob.size,
      filename: String(meta.filename || "").slice(0, 200),
      sourceEtag: String(meta.etag || "").slice(0, 300),
      sourceLastModified: String(meta.lastModified || "").slice(0, 100),
      cachedAt: existing?.cachedAt || now,
      lastAccessedAt: now
    };

    const tx = db.transaction([PDF_STORE, META_STORE], "readwrite");
    tx.objectStore(PDF_STORE).put(record);
    tx.objectStore(META_STORE).put(metadata);
    await txDone(tx);
    return true;
  } catch (error) {
    console.warn("KR Urdu Library PDF cache write skipped", error);
    return false;
  }
}

export async function removeCachedPdf(bookId) {
  if (!bookId || !canUseIndexedDB()) return false;
  try { await deleteBookInternal(await openDb(), bookId); return true; }
  catch (error) { console.warn("KR Urdu Library PDF cache delete failed", error); return false; }
}

export async function clearPdfCache() {
  if (!canUseIndexedDB()) return false;
  try {
    const db = await openDb();
    const tx = db.transaction([PDF_STORE, META_STORE], "readwrite");
    tx.objectStore(PDF_STORE).clear();
    tx.objectStore(META_STORE).clear();
    await txDone(tx);
    return true;
  } catch (error) { console.warn("KR Urdu Library PDF cache clear failed", error); return false; }
}

export async function getPdfCacheInfo() {
  if (!canUseIndexedDB()) return { count: 0, bytes: 0, maxBytes: MAX_CACHE_BYTES };
  try {
    const db = await openDb();
    const all = await getAllMeta(db);
    return {
      count: all.length,
      bytes: all.reduce((sum, item) => sum + (Number(item?.size) || 0), 0),
      maxBytes: MAX_CACHE_BYTES
    };
  } catch { return { count: 0, bytes: 0, maxBytes: MAX_CACHE_BYTES }; }
}
