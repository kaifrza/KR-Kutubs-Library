// Safe-area insets for the Android app.
// The native plugin measures how far the WebView really extends under the status / navigation bar
// and we publish it as --sat / --sab. Without this, CSS env() could double-count the status bar
// (Android already places the WebView below it) and leave a blank strip at the top of every screen.
// In a normal browser nothing is set, so the CSS falls back to env().
import { getNativePlugin } from "./download-manager.js";

const KEY = "krl_insets_v1";
let timer = 0, last = "";

function apply(top, bottom){
  const sig = `${top}/${bottom}`;
  if(sig === last) return;
  last = sig;
  const root = document.documentElement.style;
  root.setProperty("--sat", `${top}px`);
  root.setProperty("--sab", `${bottom}px`);
  try{ localStorage.setItem(KEY, sig); }catch{}
}

export async function syncInsets(){
  const plugin = getNativePlugin();
  if(!plugin) return;
  try{
    const r = await plugin.getSafeInsets();
    if(r && r.known !== false && Number.isFinite(r.top) && Number.isFinite(r.bottom)){
      apply(Math.max(0, r.top), Math.max(0, r.bottom));
    }
  }catch{ /* older APK without the method: keep the CSS env() fallback */ }
}

export function watchInsets(){
  if(!getNativePlugin()) return;
  // paint with the last known values immediately so there is no jump on start-up
  try{
    const [t, b] = (localStorage.getItem(KEY) || "").split("/").map(Number);
    if(Number.isFinite(t) && Number.isFinite(b)) apply(t, b);
  }catch{}
  const again = () => { clearTimeout(timer); timer = setTimeout(syncInsets, 120); };
  window.addEventListener("resize", again, { passive: true });
  window.addEventListener("orientationchange", again);
  document.addEventListener("visibilitychange", () => { if(document.visibilityState === "visible") again(); });
  syncInsets();
  setTimeout(syncInsets, 600);
  setTimeout(syncInsets, 1800);
}
