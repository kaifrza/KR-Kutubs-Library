// Urdu font safety net. The <link> tags in index.html normally provide Noto Naskh Arabic.
// If they did not deliver (blocked host, offline, editor preview...), load the font directly
// with the FontFace API from backup CDNs, and say clearly in the console what happened.
const FAMILY = "Noto Naskh Arabic";
const SAMPLE = "اردو کتب خانہ";
const CDNS = [
  "https://cdn.jsdelivr.net/npm/@fontsource/noto-naskh-arabic@5/files/",
  "https://unpkg.com/@fontsource/noto-naskh-arabic@5/files/",
  "./vendor/fonts/noto-naskh-arabic/files/"
];
const FILES = { 400: "noto-naskh-arabic-arabic-400-normal.woff2", 700: "noto-naskh-arabic-arabic-700-normal.woff2" };

function linkReport(){
  return [...document.querySelectorAll('link[rel="stylesheet"]')]
    .filter(l => /fonts\.googleapis|data-online-font|fonts\/.*index\.css|fontsource/.test(l.outerHTML))
    .map(l => (l.sheet ? "ok " : "FAILED ") + l.href);
}

async function isLoaded(){
  try{
    const faces = await Promise.race([
      document.fonts.load(`400 16px "${FAMILY}"`, SAMPLE),
      new Promise(r => setTimeout(() => r([]), 4000))
    ]);
    return faces.length > 0;
  }catch{ return false; }
}

async function loadDirect(weight){
  const errors = [];
  for(const base of CDNS){
    try{
      const face = new FontFace(FAMILY, `url(${base}${FILES[weight]}) format("woff2")`, { weight: String(weight), display: "swap" });
      await face.load();
      document.fonts.add(face);
      return { ok: true, from: base };
    }catch(e){ errors.push(base + " -> " + (e && e.message || e)); }
  }
  return { ok: false, errors };
}

export async function ensureUrduFont(onFail){
  const info = { family: FAMILY, links: linkReport(), online: navigator.onLine, via: "stylesheet", ok: false };
  window.__krFontInfo = info;
  try{
    if(!document.fonts){ info.via = "no-FontFace-API"; console.warn("[KR fonts]", info); return; }
    if(await isLoaded()){ info.ok = true; console.info("[KR fonts] Urdu font loaded", info); return; }
    info.via = "direct";
    const r = await Promise.all([loadDirect(400), loadDirect(700)]);
    info.direct = r;
    info.ok = r.some(x => x.ok);
    if(info.ok){ console.info("[KR fonts] stylesheet did not deliver; loaded directly", info); return; }
    console.error("[KR fonts] Urdu font could NOT be loaded", info);
    onFail && onFail(r[0].errors && r[0].errors[0] || "unknown");
  }catch(e){
    info.error = String(e); console.error("[KR fonts] failed", info);
  }
}
