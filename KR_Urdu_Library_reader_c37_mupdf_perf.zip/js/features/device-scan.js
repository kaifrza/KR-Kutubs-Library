// Device PDF scan: the one place that knows about scanning (settings, cache, state, native calls).
// Used by the Library tab (shows the result) and by More (settings + "Scan now").
import { getNativePlugin } from "./download-manager.js";

const CACHE_KEY = "krl_device_scan_v1";   // unchanged, so an existing list keeps working after the update
const MODE_KEY = "krl_scan_mode_v1";      // "auto" (default) | "manual"
const AUTO_MAX_AGE = 10 * 60 * 1000;      // auto: rescan when the list is older than this

let scanning = false, failed = false, granted = null;
const subs = new Set();
const emit = () => subs.forEach(fn => { try{ fn(); }catch{} });

export function onScanChange(fn){ subs.add(fn); return () => subs.delete(fn); }
export const scanSupported = () => Boolean(getNativePlugin());

export function getScanMode(){
  try{ return localStorage.getItem(MODE_KEY) === "manual" ? "manual" : "auto"; }catch{ return "auto"; }
}
export function setScanMode(mode){
  try{ localStorage.setItem(MODE_KEY, mode === "manual" ? "manual" : "auto"); }catch{}
  emit();
}

export function readScanCache(){
  try{
    const v = JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
    if(v && Array.isArray(v.files)) return v;
  }catch{}
  return { files: [], at: 0 };
}
function writeScanCache(files){
  try{
    localStorage.setItem(CACHE_KEY, JSON.stringify({ at: Date.now(), files: files.map(f => ({ p: f.path, n: f.name, s: f.size, m: f.modified })) }));
  }catch{}
}
export function cachedFiles(){
  return readScanCache().files.map(f => ({ path: f.p, name: f.n, size: f.s, modified: f.m }));
}

export function scanInfo(){
  const c = readScanCache();
  return { scanning, failed, granted, at: c.at, count: c.files.length, mode: getScanMode() };
}

// Auto mode: scan when there is no list yet or it is older than AUTO_MAX_AGE. Manual mode: never on its own.
export function needsAutoScan(){
  if(getScanMode() !== "auto") return false;
  const { at } = readScanCache();
  return !at || Date.now() - at > AUTO_MAX_AGE;
}

export async function checkAccess(){
  const plugin = getNativePlugin();
  if(!plugin) return false;
  try{
    const res = await plugin.checkStorageAccess();
    granted = Boolean(res?.granted);
  }catch{}
  emit();
  return granted === true;
}
export function requestAccess(){
  const plugin = getNativePlugin();
  return plugin ? plugin.requestStorageAccess().catch(() => {}) : Promise.resolve();
}

let busy = false;   // covers the permission check too, so two callers can never start two native scans
export async function runScan(){
  const plugin = getNativePlugin();
  if(!plugin || busy) return false;
  busy = true;
  try{
    if(granted !== true && !(await checkAccess())) return false;
    scanning = true; failed = false; emit();
    try{
      const res = await plugin.scanPdfs();
      writeScanCache((res?.files || []).map(f => ({ path: f.path, name: f.name, size: Number(f.size), modified: Number(f.modified) })));
    }catch(err){
      failed = true;
      console.warn("PDF scan failed", err);
    }
    scanning = false; emit();
    return !failed;
  }finally{
    busy = false;
  }
}
