// Floating header behaviour: slides away while reading down the page, comes back as soon as the
// user scrolls up (or reaches the top). Gives the content ~90px more room on small phones.
// Only toggles one class; the movement itself is a compositor-only CSS transform.
let lastY = 0, ticking = false, hidden = false, started = false;
const SHOW_NEAR_TOP = 40, DELTA = 6, HIDE_AFTER = 90;

function scrollTop(target){
  if(target === document || target === document.documentElement || target === document.body)
    return window.pageYOffset || document.documentElement.scrollTop || 0;
  return target.scrollTop || 0;
}

function setHidden(bar, value){
  if(bar.classList.contains("topbar--hidden") === value) return;   // header may have been re-rendered
  hidden = value;
  bar.classList.toggle("topbar--hidden", value);
}

function update(target){
  ticking = false;
  const bar = document.querySelector(".topbar:not(.topbar-reader)");
  const y = scrollTop(target);
  if(!bar){ lastY = y; hidden = false; return; }
  // never hide while something inside the header has focus or a dialog is open
  if(bar.contains(document.activeElement) || document.querySelector(".modal-backdrop, .more-info-dialog")){
    setHidden(bar, false); lastY = y; return;
  }
  const dy = y - lastY;
  if(y <= SHOW_NEAR_TOP){ setHidden(bar, false); lastY = y; return; }
  if(Math.abs(dy) < DELTA) return;
  if(dy > 0 && y > HIDE_AFTER) setHidden(bar, true);
  else if(dy < 0) setHidden(bar, false);
  lastY = y;
}

export function initHeaderBehavior(){
  if(started) return;
  started = true;
  document.addEventListener("scroll", (e) => {
    const t = e.target;
    // react only to the page scroller (horizontal carousels also fire scroll events)
    if(t !== document && t !== document.documentElement && t !== document.body && t.id !== "app") return;
    if(ticking) return;
    ticking = true;
    requestAnimationFrame(() => update(t));
  }, { passive: true, capture: true });
  // a freshly rendered screen always starts with a visible header
  window.addEventListener("hashchange", () => { hidden = false; lastY = 0; });
  window.addEventListener("popstate", () => { hidden = false; lastY = 0; });
}
