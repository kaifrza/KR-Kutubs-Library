package com.kr.urdulibrary;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.OverScroller;

import com.artifex.mupdf.fitz.Document;
import com.artifex.mupdf.fitz.Link;
import com.artifex.mupdf.fitz.Location;
import com.artifex.mupdf.fitz.Outline;
import com.artifex.mupdf.fitz.Page;
import com.artifex.mupdf.fitz.Quad;
import com.artifex.mupdf.fitz.android.AndroidDrawDevice;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Continuous-scroll PDF view backed by MuPDF.
 * - every MuPDF call runs on ONE worker thread (documents are not thread-safe)
 * - pages are drawn from a bitmap cache; when zoomed in only the visible patch is re-rendered
 * - pinch zoom, double tap, fling, links, text search highlights, night / sepia themes
 */
public class MuPdfView extends View {

    public interface Host {
        void onOpened(int pageCount, boolean hasOutline);
        void onOpenFailed(String message);
        void onNeedPassword(boolean wrongBefore);
        void onPageChanged(int page0, int total);
        void onTap();
        void onUserScroll();
        void onExternalLink(String uri);
        void onOutline(List<OutlineItem> items);
    }

    public static final class OutlineItem {
        public final String title; public final int level; public int page0;
        OutlineItem(String t, int l, int p) { title = t; level = l; page0 = p; }
    }

    public static final class Hit {
        public final int page0; public final float x0, y0, x1, y1;
        Hit(int p, float a, float b, float c, float d) { page0 = p; x0 = a; y0 = b; x1 = c; y1 = d; }
    }

    public interface SearchListener { void onProgress(int hits, boolean done); }

    // ---------------------------------------------------------------- worker
    private static final class Task implements Runnable, Comparable<Task> {
        final int prio; final long seq; final Runnable r;
        private static long counter = 0;
        Task(int prio, Runnable r) { this.prio = prio; this.r = r; synchronized (Task.class) { seq = counter++; } }
        @Override public void run() { r.run(); }
        @Override public int compareTo(Task o) { return prio != o.prio ? Integer.compare(prio, o.prio) : Long.compare(seq, o.seq); }
    }

    // Two workers, each with its OWN Document instance (a MuPDF document must never be used by two threads at
    // once). A: opening, page bitmaps, links.  B: sharp zoom patches, page measuring, search.
    // This keeps page bitmaps coming even while a heavy zoom patch or a search is being rendered.
    private final ThreadPoolExecutor exec = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new PriorityBlockingQueue<Runnable>());
    private final ThreadPoolExecutor execB = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new PriorityBlockingQueue<Runnable>());
    private Document docB;
    private String password;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean destroyed = false;

    // ---------------------------------------------------------------- document state
    private Document doc;
    private int pageCount = 0;
    private float[] pw, ph;           // page size in points
    private boolean[] sized;
    private float defaultRatio = 1.414f;
    private Host host;
    private String path;

    // ---------------------------------------------------------------- layout (zoom 1 pixels)
    private float[] top1;             // top of each page at zoom 1
    private float[] h1;               // height of each page at zoom 1
    private float total1 = 0;
    private float pageW1 = 0;         // page width at zoom 1 (<= view width)
    private float gap;
    private float maxPagePx;
    private float zoom = 1f, minZoom = 1f, maxZoom = 5f;
    private float scrollX = 0f, scrollY = 0f;
    private int lastPage0 = -1;

    // anchor kept while pages get measured
    private int pendingAnchorPage = -1; private float pendingAnchorFrac = 0f; private boolean haveSizes0 = false;

    // ---------------------------------------------------------------- bitmaps
    private final LruCache<Integer, Bitmap> cache;
    private final LruCache<Integer, Bitmap> lowCache;      // quick, blurry previews shown while the sharp page renders
    private final java.util.concurrent.atomic.AtomicBoolean pumping = new java.util.concurrent.atomic.AtomicBoolean(false);
    private volatile int scrollDir = 1;
    private static final class Patch { int page0; float zoom; int x, y, w, h; Bitmap bmp; }
    private final Map<Integer, Patch> patches = new HashMap<>();
    private final Set<Integer> pendingPatch = new HashSet<>();
    private volatile int visFirst = 0, visLast = 0;
    private volatile float curZoomForTasks = 1f;

    // ---------------------------------------------------------------- look
    private int theme = 0;            // 0 paper, 1 sepia, 2 night
    private float dim = 0f;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fill = new Paint();
    private final Paint hitPaint = new Paint();
    private final Paint dimPaint = new Paint();
    private int bgColor = 0xFFE9E7E2, pageColor = Color.WHITE;

    // ---------------------------------------------------------------- search
    private final List<Hit> hits = new ArrayList<>();
    private int currentHit = -1;
    private volatile int searchToken = 0;

    // ---------------------------------------------------------------- touch
    private final GestureDetector gd;
    private final ScaleGestureDetector sgd;
    private final OverScroller scroller;
    private boolean scaling = false;

    public MuPdfView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        gap = 10 * d;
        maxPagePx = 900 * d;
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024);
        cache = new LruCache<Integer, Bitmap>(Math.max(16 * 1024, maxKb / 5)) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
        };
        lowCache = new LruCache<Integer, Bitmap>(Math.max(4 * 1024, maxKb / 16)) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
        };
        scroller = new OverScroller(c);
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { scroller.forceFinished(true); return true; }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (scaling) return true;
                scrollBy(dx, dy); host_userScroll(); return true;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (scaling) return true;
                scrollDir = vy < 0 ? 1 : -1;
                scroller.fling((int) scrollX, (int) scrollY, (int) -vx, (int) -vy, 0, (int) maxScrollX(), 0, (int) maxScrollY());
                postInvalidateOnAnimation(); host_userScroll(); return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { handleTap(e.getX(), e.getY()); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                setZoomAround(zoom > 1.3f ? 1f : Math.min(maxZoom, 2.4f), e.getX(), e.getY()); return true;
            }
        });
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) { scaling = true; scroller.forceFinished(true); return true; }
            @Override public boolean onScale(ScaleGestureDetector d) {
                setZoomAround(zoom * d.getScaleFactor(), d.getFocusX(), d.getFocusY()); return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector d) { scaling = false; scheduleDetail(); }
        });
        hitPaint.setStyle(Paint.Style.FILL);
        setLayerType(LAYER_TYPE_NONE, null);
        applyTheme();
    }

    private void submit(Task t) { try { exec.execute(t); } catch (Throwable ignored) { } }
    private void submitB(Task t) { try { execB.execute(t); } catch (Throwable ignored) { } }

    /** Second document instance, only ever touched from the B worker thread. */
    private Document docB() throws Exception {
        if (docB == null) {
            Document d = Document.openDocument(path);
            if (d.needsPassword() && (password == null || !d.authenticatePassword(password))) throw new RuntimeException("locked");
            docB = d;
        }
        return docB;
    }

    public void setHost(Host h) { host = h; }
    private void host_userScroll() { if (host != null) host.onUserScroll(); }

    // ================================================================= opening
    public void open(final String filePath, final String password, final int startPage0, final float startFrac) {
        path = filePath;
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                try {
                    if (doc == null) {
                        doc = Document.openDocument(filePath);
                    }
                    if (doc.needsPassword()) {
                        boolean ok = password != null && doc.authenticatePassword(password);
                        if (!ok) {
                            final boolean wrong = password != null;
                            ui.post(new Runnable() { @Override public void run() { if (host != null) host.onNeedPassword(wrong); } });
                            return;
                        }
                    }
                    MuPdfView.this.password = password;
                    final int n = doc.countPages();
                    if (n <= 0) throw new RuntimeException("Empty document");
                    final float[] w = new float[n], h = new float[n];
                    final boolean[] s = new boolean[n];
                    int first = Math.max(0, Math.min(n - 1, startPage0));
                    measure(0, w, h, s);
                    if (first != 0) measure(first, w, h, s);
                    final List<OutlineItem> items = loadOutlineSafe();
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed) return;
                        pageCount = n; pw = w; ph = h; sized = s;
                        defaultRatio = s[0] ? h[0] / w[0] : 1.414f;
                        haveSizes0 = true;
                        pendingAnchorPage = Math.max(0, Math.min(n - 1, startPage0)); pendingAnchorFrac = startFrac;
                        relayout(false);
                        if (top1 != null) { restoreAnchor(pendingAnchorPage, pendingAnchorFrac); pendingAnchorPage = -1; }
                        if (host != null) { host.onOpened(n, items != null && !items.isEmpty()); host.onOutline(items); }
                        invalidate();
                        measureRest(n);
                    } });
                } catch (final Throwable t) {
                    ui.post(new Runnable() { @Override public void run() { if (host != null) host.onOpenFailed(String.valueOf(t.getMessage())); } });
                }
            }
        }));
    }

    private void measure(int i, float[] w, float[] h, boolean[] s) {
        Page p = null;
        try {
            p = doc.loadPage(i);
            com.artifex.mupdf.fitz.Rect b = p.getBounds();
            float ww = b.x1 - b.x0, hh = b.y1 - b.y0;
            if (ww > 1 && hh > 1) { w[i] = ww; h[i] = hh; s[i] = true; }
        } catch (Throwable ignored) {
        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
    }

    private void measureRest(final int n) {
        final int batch = 24;
        for (int start = 0; start < n; start += batch) {
            final int a = start, b = Math.min(n, start + batch);
            submitB(new Task(5, new Runnable() {
                @Override public void run() {
                    if (destroyed) return;
                    final float[] w = new float[b - a], h = new float[b - a]; final boolean[] s = new boolean[b - a];
                    for (int i = a; i < b; i++) {
                        if (sized[i]) { w[i - a] = pw[i]; h[i - a] = ph[i]; s[i - a] = true; continue; }
                        Page p = null;
                        try {
                            p = docB().loadPage(i);
                            com.artifex.mupdf.fitz.Rect r = p.getBounds();
                            float ww = r.x1 - r.x0, hh = r.y1 - r.y0;
                            if (ww > 1 && hh > 1) { w[i - a] = ww; h[i - a] = hh; s[i - a] = true; }
                        } catch (Throwable ignored) {
                        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed) return;
                        int ap = anchorPage(); float af = anchorFrac(ap);
                        boolean changed = false;
                        for (int i = a; i < b; i++) {
                            if (s[i - a] && (!sized[i] || pw[i] != w[i - a] || ph[i] != h[i - a])) {
                                pw[i] = w[i - a]; ph[i] = h[i - a]; sized[i] = true; changed = true;
                            }
                        }
                        if (changed) { relayout(false); restoreAnchor(ap, af); invalidate(); }
                    } });
                }
            }));
        }
    }

    private List<OutlineItem> loadOutlineSafe() {
        try {
            Outline[] o = doc.loadOutline();
            if (o == null) return new ArrayList<>();
            List<OutlineItem> out = new ArrayList<>();
            flatten(o, 0, out);
            return out;
        } catch (Throwable t) { return new ArrayList<>(); }
    }

    private void flatten(Outline[] arr, int level, List<OutlineItem> out) {
        if (arr == null || out.size() > 3000) return;
        for (Outline o : arr) {
            if (o == null) continue;
            int pg = resolvePage(o, o.uri);
            out.add(new OutlineItem(o.title == null ? "" : o.title.trim(), level, pg));
            if (o.down != null) flatten(o.down, level + 1, out);
        }
    }

    /** Resolves an outline entry or link to a 0-based page. Tolerates API differences between MuPDF versions. */
    private int resolvePage(Object target, String uri) {
        try {
            for (Method m : Document.class.getMethods()) {
                if (!m.getName().equals("resolveLink") || m.getParameterTypes().length != 1) continue;
                Class<?> pt = m.getParameterTypes()[0];
                Object arg = null;
                if (pt != String.class && target != null && pt.isInstance(target)) arg = target;
                else if (pt == String.class && uri != null) arg = uri;
                if (arg == null) continue;
                Object res = m.invoke(doc, arg);
                if (res instanceof Integer) return (Integer) res;
                if (res instanceof Location) {
                    Location l = (Location) res;
                    try { return doc.pageNumberFromLocation(l); } catch (Throwable t) { return l.page; }
                }
            }
        } catch (Throwable ignored) { }
        return -1;
    }

    // ================================================================= layout / scroll maths
    private void relayout(boolean keepAnchor) {
        int ap = keepAnchor ? anchorPage() : 0; float af = keepAnchor ? anchorFrac(ap) : 0f;
        int vw = getWidth();
        if (pageCount == 0 || vw <= 0) return;
        pageW1 = Math.min(vw, maxPagePx);
        if (top1 == null || top1.length != pageCount) { top1 = new float[pageCount]; h1 = new float[pageCount]; }
        float y = gap;
        for (int i = 0; i < pageCount; i++) {
            float ratio = (sized != null && sized[i]) ? ph[i] / pw[i] : defaultRatio;
            top1[i] = y; h1[i] = pageW1 * ratio; y += h1[i] + gap;
        }
        total1 = y;
        clampScroll();
        if (keepAnchor) restoreAnchor(ap, af);
    }

    private float contentW() { return Math.max(getWidth(), pageW1 * zoom); }
    private float contentH() { return total1 * zoom; }
    private float maxScrollX() { return Math.max(0, contentW() - getWidth()); }
    private float maxScrollY() { return Math.max(0, contentH() - getHeight()); }
    private void clampScroll() {
        scrollX = Math.max(0, Math.min(scrollX, maxScrollX()));
        scrollY = Math.max(0, Math.min(scrollY, maxScrollY()));
    }
    private void scrollBy(float dx, float dy) { if (dy != 0) scrollDir = dy > 0 ? 1 : -1; scrollX += dx; scrollY += dy; clampScroll(); onMoved(); }

    private float anchorY() { return getHeight() * 0.35f; }

    private int pageAtContentY(float yz) {
        if (top1 == null || pageCount == 0) return 0;
        float y = yz / zoom;
        int lo = 0, hi = pageCount - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (top1[mid] <= y) lo = mid; else hi = mid - 1;
        }
        return lo;
    }

    private int anchorPage() { return pageAtContentY(scrollY + anchorY()); }
    private float anchorFrac(int p) {
        if (top1 == null || p < 0 || p >= pageCount) return 0f;
        float f = ((scrollY + anchorY()) / zoom - top1[p]) / Math.max(1f, h1[p]);
        return Math.max(0f, Math.min(1f, f));
    }
    private void restoreAnchor(int p, float frac) {
        if (top1 == null || p < 0 || p >= pageCount) return;
        scrollY = (top1[p] + frac * h1[p]) * zoom - anchorY();
        clampScroll(); onMoved();
    }

    public int currentPage0() { return anchorPage(); }
    public float currentFrac() { return anchorFrac(anchorPage()); }
    public int pageCount() { return pageCount; }
    public float zoom() { return zoom; }

    public void goToPage(int p0) {
        if (top1 == null) return;
        p0 = Math.max(0, Math.min(pageCount - 1, p0));
        scroller.forceFinished(true);
        scrollY = top1[p0] * zoom - gap * zoom;
        clampScroll(); onMoved(); invalidate();
    }

    public void resetZoom() { setZoomAround(1f, getWidth() / 2f, getHeight() / 2f); }

    private void setZoomAround(float z, float fx, float fy) {
        z = Math.max(minZoom, Math.min(maxZoom, z));
        if (Math.abs(z - zoom) < 0.0001f) return;
        float cx = (scrollX + fx) / zoom, cy = (scrollY + fy) / zoom;
        zoom = z;
        // horizontally centred when narrower than the view
        scrollX = cx * zoom - fx;
        scrollY = cy * zoom - fy;
        clampScroll(); onMoved(); invalidate();
        if (!scaling) scheduleDetail();
    }

    private void onMoved() {
        if (pageCount == 0) return;
        int p = anchorPage();
        if (p != lastPage0) { lastPage0 = p; if (host != null) host.onPageChanged(p, pageCount); }
    }

    // ================================================================= look
    public void setLook(int themeIdx, float dimAmount) {
        theme = themeIdx; dim = dimAmount; applyTheme();
        synchronized (patches) { patches.clear(); }
        invalidate();
    }

    private void applyTheme() {
        if (theme == 2) { bgColor = 0xFF0B0F0D; pageColor = 0xFF111613; }
        else if (theme == 1) { bgColor = 0xFFD9CFB8; pageColor = 0xFFF4ECD8; }
        else { bgColor = 0xFFE9E7E2; pageColor = Color.WHITE; }
        ColorMatrix cm = new ColorMatrix();
        if (theme == 2) {
            cm.set(new float[]{
                    -0.86f, 0, 0, 0, 255 * 0.86f,
                    0, -0.89f, 0, 0, 255 * 0.89f,
                    0, 0, -0.87f, 0, 255 * 0.87f,
                    0, 0, 0, 1, 0});
            bmpPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        } else if (theme == 1) {
            cm.setScale(0.957f, 0.925f, 0.847f, 1f);
            bmpPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        } else {
            bmpPaint.setColorFilter(null);
        }
        dimPaint.setColor(Color.argb((int) (Math.max(0f, Math.min(0.7f, dim)) * 255), 0, 0, 0));
    }

    public int backgroundColor() { return bgColor; }

    // ================================================================= drawing
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (pageCount > 0) {
            if (w != ow) { synchronized (cache) { cache.evictAll(); } synchronized (lowCache) { lowCache.evictAll(); } synchronized (patches) { patches.clear(); } }
            if (top1 == null && pendingAnchorPage >= 0) {
                relayout(false); restoreAnchor(pendingAnchorPage, pendingAnchorFrac); pendingAnchorPage = -1;
            } else relayout(true);
            invalidate();
        }
    }

    @Override public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollX = scroller.getCurrX(); scrollY = scroller.getCurrY();
            clampScroll(); onMoved(); postInvalidateOnAnimation();
        } else if (scroller.isFinished()) {
            // settled -> sharpen
            if (zoom > 1.15f) scheduleDetail();
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        canvas.drawColor(bgColor);
        if (pageCount == 0 || top1 == null) return;
        int vw = getWidth(), vh = getHeight();
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int first = pageAtContentY(scrollY);
        int last = pageAtContentY(scrollY + vh);
        visFirst = first; visLast = last; curZoomForTasks = zoom;
        for (int i = first; i <= last && i < pageCount; i++) {
            float t = top1[i] * zoom - scrollY;
            float w = pageW1 * zoom, h = h1[i] * zoom;
            RectF dst = new RectF(left0, t, left0 + w, t + h);
            fill.setColor(pageColor);
            canvas.drawRect(dst, fill);
            Bitmap b = cache.get(i);
            if (b == null) b = lowCache.get(i);
            if (b != null) canvas.drawBitmap(b, null, dst, bmpPaint);
            Patch pt;
            synchronized (patches) { pt = patches.get(i); }
            if (pt != null && pt.bmp != null && !pt.bmp.isRecycled()) {
                float k = zoom / pt.zoom;
                float pl = left0 + pt.x * k, ptp = t + pt.y * k;
                canvas.drawBitmap(pt.bmp, null, new RectF(pl, ptp, pl + pt.w * k, ptp + pt.h * k), bmpPaint);
            }
            drawHits(canvas, i, left0, t, w, h);
        }
        if (needsWork()) kickPump();
        if (dim > 0.001f) canvas.drawRect(0, 0, vw, vh, dimPaint);
        if (zoom > 1.15f && !scaling && scroller.isFinished()) scheduleDetail();
    }

    private void drawHits(Canvas canvas, int page0, float left, float top, float w, float h) {
        if (hits.isEmpty() || !sized[page0]) return;
        float sx = w / pw[page0], sy = h / ph[page0];
        for (int k = 0; k < hits.size(); k++) {
            Hit ht = hits.get(k);
            if (ht.page0 != page0) continue;
            hitPaint.setColor(k == currentHit ? 0x77FF8A00 : 0x55FFD800);
            canvas.drawRect(left + ht.x0 * sx, top + ht.y0 * sy, left + ht.x1 * sx, top + ht.y1 * sy, hitPaint);
        }
    }

    // ================================================================= rendering requests
    // ---- page render pump -------------------------------------------------------------------
    // One render per task; before every render it re-decides what is needed *right now* (visible pages
    // first, then the pages in the scroll direction), so a fast fling never works on pages it has left.
    private int[] candidates() {
        int first = visFirst, last = Math.min(pageCount - 1, visLast);
        ArrayList<Integer> c = new ArrayList<>();
        for (int i = first; i <= last; i++) c.add(i);
        int ahead = scrollDir >= 0 ? 1 : -1;
        for (int k = 1; k <= 3; k++) { int i = ahead > 0 ? last + k : first - k; if (i >= 0 && i < pageCount) c.add(i); }
        for (int k = 1; k <= 1; k++) { int i = ahead > 0 ? first - k : last + k; if (i >= 0 && i < pageCount) c.add(i); }
        int[] out = new int[c.size()];
        for (int i = 0; i < out.length; i++) out[i] = c.get(i);
        return out;
    }

    private boolean needsWork() {
        if (pageCount == 0 || destroyed) return false;
        for (int i : candidates()) if (cache.get(i) == null) return true;
        return false;
    }

    private void kickPump() {
        if (destroyed) return;
        if (pumping.compareAndSet(false, true)) submit(new Task(1, pumpTask));
    }

    private final Runnable pumpTask = new Runnable() {
        @Override public void run() {
            boolean more = false;
            try {
                if (destroyed || doc == null) return;
                int[] cand = candidates();
                int vw = Math.max(1, (int) pageW1);
                // 1) quick previews for pages that are on screen
                int visCount = Math.max(0, Math.min(pageCount - 1, visLast) - visFirst + 1);
                for (int k = 0; k < cand.length; k++) {
                    int i = cand[k];
                    if (k < visCount && cache.get(i) == null && lowCache.get(i) == null) {
                        renderInto(i, Math.max(1, vw / 3), lowCache);
                        more = true; return;
                    }
                }
                // 2) full-resolution pages, nearest first
                for (int i : cand) {
                    if (cache.get(i) == null) {
                        renderInto(i, vw, cache);
                        more = true; return;
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                pumping.set(false);
                if (more && !destroyed) kickPump();
            }
        }
    };

    private void renderInto(int i, int w, LruCache<Integer, Bitmap> target) {
        Page p = null;
        try {
            float ratio = (sized != null && sized[i]) ? ph[i] / pw[i] : defaultRatio;
            p = doc.loadPage(i);
            int h = Math.max(1, Math.round(w * ratio));
            Bitmap bm = renderPatch(p, w, h, 0, 0, w, h);
            if (bm != null) target.put(i, bm);
        } catch (Throwable ignored) {
        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
        ui.post(new Runnable() { @Override public void run() { if (!destroyed) invalidate(); } });
    }

    // ---- MuPDF drawing ------------------------------------------------------------------------------
    // Draws the rectangle (px,py,pw,ph) -- in pixels of a page that is pageW x pageH pixels in total -- into a
    // new bitmap. Uses only the basic Device API (works across MuPDF 1.2x versions).
    private static Bitmap renderPatch(Page p, int pageW, int pageH, int px, int py, int pw, int ph) throws Exception {
        com.artifex.mupdf.fitz.Rect b = p.getBounds();
        float bw = Math.max(1f, b.x1 - b.x0), bh = Math.max(1f, b.y1 - b.y0);
        float sx = pageW / bw, sy = pageH / bh;
        com.artifex.mupdf.fitz.Matrix ctm = new com.artifex.mupdf.fitz.Matrix(sx, 0f, 0f, sy, -b.x0 * sx, -b.y0 * sy);
        Bitmap bm = Bitmap.createBitmap(Math.max(1, pw), Math.max(1, ph), Bitmap.Config.ARGB_8888);
        bm.eraseColor(Color.WHITE);
        com.artifex.mupdf.fitz.Device dev = newDrawDevice(bm, px, py);
        try {
            p.run(dev, ctm, (com.artifex.mupdf.fitz.Cookie) null);
            dev.close();
        } finally {
            try { dev.destroy(); } catch (Throwable ignored) { }
        }
        return bm;
    }

    private static com.artifex.mupdf.fitz.Device newDrawDevice(Bitmap bm, int px, int py) throws Exception {
        try {
            return (com.artifex.mupdf.fitz.Device) AndroidDrawDevice.class
                    .getConstructor(Bitmap.class, int.class, int.class).newInstance(bm, px, py);
        } catch (NoSuchMethodException e) {
            return (com.artifex.mupdf.fitz.Device) AndroidDrawDevice.class
                    .getConstructor(Bitmap.class, int.class, int.class, int.class, int.class, int.class, int.class)
                    .newInstance(bm, px, py, px, py, px + bm.getWidth(), py + bm.getHeight());
        }
    }

    private final Runnable detailRunnable = new Runnable() {
        @Override public void run() { requestDetail(); }
    };
    private void scheduleDetail() { removeCallbacks(detailRunnable); postDelayed(detailRunnable, 90); }

    /** Re-renders the visible part of each visible page at the current zoom (only when zoomed in). */
    private void requestDetail() {
        if (destroyed || pageCount == 0 || zoom <= 1.15f || top1 == null) return;
        int vw = getWidth(), vh = getHeight();
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int first = pageAtContentY(scrollY), last = pageAtContentY(scrollY + vh);
        prunePatches(first, last);
        for (int i = first; i <= last && i < pageCount; i++) {
            float t = top1[i] * zoom - scrollY;
            float w = pageW1 * zoom, h = h1[i] * zoom;
            // visible rectangle of the page in page-pixel coordinates, with a margin
            int margin = (int) (vh * 0.12f);
            int x0 = (int) Math.max(0, -left0 - margin), x1 = (int) Math.min(w, vw - left0 + margin);
            int y0 = (int) Math.max(0, -t - margin), y1 = (int) Math.min(h, vh - t + margin);
            if (x1 - x0 < 8 || y1 - y0 < 8) continue;
            Patch have;
            synchronized (patches) { have = patches.get(i); }
            if (have != null && Math.abs(have.zoom - zoom) < 0.01f
                    && have.x <= x0 + margin / 2 && have.y <= y0 + margin / 2
                    && have.x + have.w >= x1 - margin / 2 && have.y + have.h >= y1 - margin / 2) continue;
            requestPatch(i, zoom, Math.round(w), Math.round(h), x0, y0, x1 - x0, y1 - y0);
        }
    }

    /** Sharp patches are big: keep only those of the pages on screen (and only for the current zoom). */
    private void prunePatches(int first, int last) {
        synchronized (patches) {
            java.util.Iterator<Map.Entry<Integer, Patch>> it = patches.entrySet().iterator();
            while (it.hasNext()) {
                Patch pt = it.next().getValue();
                if (pt.page0 < first - 1 || pt.page0 > last + 1 || Math.abs(pt.zoom - zoom) > 0.35f * zoom) it.remove();
            }
        }
    }

    private void requestPatch(final int i, final float z, final int pageWpx, final int pageHpx,
                              final int x, final int y, final int w, final int h) {
        synchronized (pendingPatch) { if (!pendingPatch.add(i)) return; }
        submitB(new Task(2, new Runnable() {
            @Override public void run() {
                Bitmap bm = null;
                try {
                    if (!destroyed && i >= visFirst - 1 && i <= visLast + 1 && Math.abs(curZoomForTasks - z) < 0.05f) {
                        Page p = docB().loadPage(i);
                        try { bm = renderPatch(p, pageWpx, pageHpx, x, y, w, h); }
                        finally { try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                } catch (Throwable ignored) { }
                final Bitmap result = bm;
                ui.post(new Runnable() { @Override public void run() {
                    synchronized (pendingPatch) { pendingPatch.remove(i); }
                    if (destroyed) return;
                    if (result != null) {
                        Patch pt = new Patch(); pt.page0 = i; pt.zoom = z; pt.x = x; pt.y = y; pt.w = w; pt.h = h; pt.bmp = result;
                        synchronized (patches) { patches.put(i, pt); }
                        invalidate();
                        scheduleDetail();   // the view may have moved while rendering
                    }
                } });
            }
        }));
    }

    // ================================================================= touch
    @Override public boolean onTouchEvent(MotionEvent e) {
        sgd.onTouchEvent(e);
        if (!sgd.isInProgress()) gd.onTouchEvent(e);
        if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            if (zoom > 1.15f) scheduleDetail();
        }
        return true;
    }

    private void handleTap(float x, float y) {
        if (pageCount == 0 || top1 == null) { if (host != null) host.onTap(); return; }
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int p = pageAtContentY(scrollY + y);
        float t = top1[p] * zoom - scrollY;
        float w = pageW1 * zoom, h = h1[p] * zoom;
        if (!sized[p] || x < left0 || x > left0 + w || y < t || y > t + h) { if (host != null) host.onTap(); return; }
        final float px = (x - left0) / w * pw[p], py = (y - t) / h * ph[p];
        final int page = p;
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                String uri = null; int target = -1; boolean hit = false;
                Page pg = null;
                try {
                    pg = doc.loadPage(page);
                    Link[] links = pg.getLinks();
                    if (links != null) {
                        for (Link l : links) {
                            com.artifex.mupdf.fitz.Rect b = l.getBounds();
                            if (b != null && px >= b.x0 && px <= b.x1 && py >= b.y0 && py <= b.y1) {
                                hit = true; uri = l.getURI();
                                if (uri != null && (uri.startsWith("http:") || uri.startsWith("https:") || uri.startsWith("mailto:"))) break;
                                target = resolvePage(l, uri);
                                break;
                            }
                        }
                    }
                } catch (Throwable ignored) {
                } finally { if (pg != null) try { pg.destroy(); } catch (Throwable ignored) { } }
                final boolean fh = hit; final String fu = uri; final int ft = target;
                ui.post(new Runnable() { @Override public void run() {
                    if (destroyed) return;
                    if (fh && ft >= 0) goToPage(ft);
                    else if (fh && fu != null && (fu.startsWith("http") || fu.startsWith("mailto:"))) { if (host != null) host.onExternalLink(fu); }
                    else if (host != null) host.onTap();
                } });
            }
        }));
    }

    // ================================================================= search
    public void search(final String query, final SearchListener listener) {
        final int token = ++searchToken;
        hits.clear(); currentHit = -1; invalidate();
        if (query == null || query.trim().isEmpty() || pageCount == 0) { if (listener != null) listener.onProgress(0, true); return; }
        final String q = query.trim();
        final int n = pageCount, batch = 12;
        for (int start = 0; start < n; start += batch) {
            final int a = start, b = Math.min(n, start + batch);
            submitB(new Task(6, new Runnable() {
                @Override public void run() {
                    if (destroyed || token != searchToken) return;
                    final List<Hit> found = new ArrayList<>();
                    for (int i = a; i < b && token == searchToken; i++) {
                        Page p = null;
                        try {
                            p = docB().loadPage(i);
                            collect(p, q, i, found);
                        } catch (Throwable ignored) {
                        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                    final boolean done = b >= n;
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed || token != searchToken) return;
                        if (hits.size() < 800) hits.addAll(found);
                        if (currentHit < 0 && !hits.isEmpty()) { currentHit = 0; showHit(0); }
                        invalidate();
                        if (listener != null) listener.onProgress(hits.size(), done);
                    } });
                }
            }));
        }
    }

    private void collect(Page p, String q, int pageIdx, List<Hit> out) throws Exception {
        Method m = Page.class.getMethod("search", String.class);
        Object res = m.invoke(p, q);
        addHits(res, pageIdx, out);
    }

    private void addHits(Object o, int pageIdx, List<Hit> out) {
        if (o == null) return;
        if (o instanceof com.artifex.mupdf.fitz.Rect) {
            com.artifex.mupdf.fitz.Rect r = (com.artifex.mupdf.fitz.Rect) o;
            out.add(new Hit(pageIdx, r.x0, r.y0, r.x1, r.y1));
        } else if (o instanceof Quad) {
            Quad qd = (Quad) o;
            float x0 = Math.min(Math.min(qd.ul_x, qd.ll_x), Math.min(qd.ur_x, qd.lr_x));
            float x1 = Math.max(Math.max(qd.ul_x, qd.ll_x), Math.max(qd.ur_x, qd.lr_x));
            float y0 = Math.min(Math.min(qd.ul_y, qd.ll_y), Math.min(qd.ur_y, qd.lr_y));
            float y1 = Math.max(Math.max(qd.ul_y, qd.ll_y), Math.max(qd.ur_y, qd.lr_y));
            out.add(new Hit(pageIdx, x0, y0, x1, y1));
        } else if (o instanceof Object[]) {
            for (Object x : (Object[]) o) addHits(x, pageIdx, out);
        }
    }

    public int hitCount() { return hits.size(); }
    public int currentHitIndex() { return currentHit; }
    public void clearSearch() { searchToken++; hits.clear(); currentHit = -1; invalidate(); }

    public void nextHit(int dir) {
        if (hits.isEmpty()) return;
        currentHit = (currentHit + dir + hits.size()) % hits.size();
        showHit(currentHit); invalidate();
    }

    private void showHit(int k) {
        if (k < 0 || k >= hits.size() || top1 == null) return;
        Hit h = hits.get(k);
        if (h.page0 >= pageCount) return;
        float ratio = h1[h.page0] / (sized[h.page0] ? ph[h.page0] : 1f);
        float yz = (top1[h.page0] + h.y0 * ratio) * zoom;
        scroller.forceFinished(true);
        scrollY = yz - getHeight() * 0.3f;
        clampScroll(); onMoved();
    }

    // ================================================================= lifecycle
    public void destroy() {
        destroyed = true;
        searchToken++;
        removeCallbacks(detailRunnable);
        exec.getQueue().clear();
        execB.getQueue().clear();
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                try { if (doc != null) doc.destroy(); } catch (Throwable ignored) { }
                doc = null;
            }
        }));
        submitB(new Task(0, new Runnable() {
            @Override public void run() {
                try { if (docB != null) docB.destroy(); } catch (Throwable ignored) { }
                docB = null;
            }
        }));
        exec.shutdown();
        execB.shutdown();
        synchronized (cache) { cache.evictAll(); }
        synchronized (lowCache) { lowCache.evictAll(); }
        synchronized (patches) { patches.clear(); }
    }
}
