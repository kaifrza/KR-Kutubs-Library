// Library screen: books downloaded from this app + every PDF found on the phone.
// Files are read straight from storage; nothing is copied into app storage.
import { getDownloads, getDownloadRecord, removeDownloadRecord } from "./downloads-store.js";
import { getNativePlugin } from "./download-manager.js";

const SCAN_KEY = "krl_device_scan_v1";
const PAGE = 60;
let activeCleanup = null;
let thumbChain = Promise.resolve();

export function cleanupLibrary(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

function formatBytes(n){
  n = Number(n) || 0;
  if(n >= 1073741824) return (n / 1073741824).toFixed(1) + " GB";
  if(n >= 1048576) return (n / 1048576).toFixed(1) + " MB";
  if(n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}
function formatDate(ts, ur){
  try{ return new Date(ts).toLocaleDateString(ur ? "ur-PK" : "en-GB", { day: "numeric", month: "short", year: "numeric" }); }catch{ return ""; }
}
function readScanCache(){
  try{
    const v = JSON.parse(localStorage.getItem(SCAN_KEY) || "null");
    if(v && Array.isArray(v.files)) return v;
  }catch{}
  return { files: [], at: 0 };
}
function writeScanCache(files){
  try{
    localStorage.setItem(SCAN_KEY, JSON.stringify({ at: Date.now(), files: files.map(f => ({ p: f.path, n: f.name, s: f.size, m: f.modified })) }));
  }catch{}
}
function fromCache(v){ return v.files.map(f => ({ path: f.p, name: f.n, size: f.s, modified: f.m })); }
function folderOf(path){
  const parts = String(path).split("/").filter(Boolean);
  parts.pop();
  return parts.pop() || "";
}

export function renderLibrary(d){
  cleanupLibrary();
  const { lang, shell, books, navigate, showToast, confirmDialog, downloadBookPdf, coverMarkup, wireCover, escapeHTML } = d;
  const ur = lang === "ur";
  const T = ur ? {
    title: "لائبریری", intro: "اس ایپ سے ڈاؤنلوڈ کی ہوئی کتابیں اور آپ کے فون کی تمام PDF فائلیں، سب آف لائن پڑھیں۔",
    search: "کتابیں تلاش کریں…", sortDate: "تازہ ترین", sortName: "نام", sortSize: "سائز",
    krTitle: "KR لائبریری سے ڈاؤنلوڈ", devTitle: "فون کی دوسری PDF فائلیں",
    krEmpty: "ابھی کوئی کتاب ڈاؤنلوڈ نہیں ہوئی۔ کسی کتاب کا ڈاؤنلوڈ بٹن دبائیں۔",
    devEmpty: "کوئی PDF نہیں ملی۔", noMatch: "کوئی نتیجہ نہیں ملا۔",
    missing: "فائل نہیں ملی", del: "حذف کریں", delTitle: "فائل حذف کریں؟",
    delMsg: "یہ کتاب آپ کے فون کے ڈاؤنلوڈز فولڈر سے بھی حذف ہو جائے گی۔", deleted: "کتاب حذف ہوگئی۔",
    again: "دوبارہ ڈاؤنلوڈ کریں", againMsg: "یہ فائل فون میں موجود نہیں۔ کیا دوبارہ ڈاؤنلوڈ کریں؟",
    accessTitle: "فون کی PDF فائلیں دیکھنے کی اجازت دیں",
    accessText: "اجازت دینے کے بعد ایپ آپ کے فون کی تمام PDF فائلیں یہاں دکھا سکے گی۔ فائلیں کہیں کاپی یا اپلوڈ نہیں ہوتیں۔",
    accessBtn: "اجازت دیں", scanning: "PDF فائلیں تلاش کی جا رہی ہیں…", found: n => `${n} PDF فائلیں ملیں`,
    rescan: "دوبارہ تلاش کریں", more: "مزید دکھائیں", androidOnly: "یہ فہرست صرف اینڈرائیڈ ایپ میں کام کرتی ہے۔",
    scanFailed: "تلاش مکمل نہیں ہو سکی۔"
  } : {
    title: "Library", intro: "Books downloaded from this app and every PDF on your phone, all readable offline.",
    search: "Search your books…", sortDate: "Newest", sortName: "Name", sortSize: "Size",
    krTitle: "Downloaded from KR Library", devTitle: "Other PDFs on this phone",
    krEmpty: "No books downloaded yet. Tap Download on any book.",
    devEmpty: "No PDFs found.", noMatch: "No results found.",
    missing: "File not found", del: "Delete", delTitle: "Delete this file?",
    delMsg: "The book will also be removed from your phone's Downloads folder.", deleted: "Book deleted.",
    again: "Download again", againMsg: "This file is no longer on your phone. Download it again?",
    accessTitle: "Allow access to PDFs on your phone",
    accessText: "Once allowed, the app can list every PDF on your phone here. Files are never copied or uploaded.",
    accessBtn: "Allow access", scanning: "Looking for PDFs…", found: n => `${n} PDFs found`,
    rescan: "Scan again", more: "Show more", androidOnly: "This list works in the Android app only.",
    scanFailed: "The scan could not finish."
  };

  const plugin = getNativePlugin();
  const state = {
    query: "", sort: "date", limit: PAGE, granted: false, scanning: false, scanError: false,
    files: fromCache(readScanCache()), missing: new Set(), destroyed: false
  };

  const page = shell(T.title, `<section class="dl-page">
    <div class="dl-head"><h1>${T.title}</h1><p>${T.intro}</p></div>
    <div id="lbAccess"></div>
    <div class="lb-toolbar">
      <form class="search-box" id="lbSearchForm"><span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span><input id="lbSearch" type="search" placeholder="${T.search}" aria-label="${T.search}" autocomplete="off" enterkeyhint="search"></form>
      <select id="lbSort" class="lb-sort" aria-label="Sort">
        <option value="date">${T.sortDate}</option><option value="name">${T.sortName}</option><option value="size">${T.sortSize}</option>
      </select>
      <button class="icon-btn" id="lbRescan" type="button" aria-label="${T.rescan}" title="${T.rescan}"><i class="fa-solid fa-rotate"></i></button>
    </div>
    <div id="lbKr"></div>
    <div id="lbDevice"></div>
  </section>`, "downloads");

  const $ = s => page.querySelector(s);
  const accessBox = $("#lbAccess"), krBox = $("#lbKr"), devBox = $("#lbDevice");

  const matches = (text, q) => !q || String(text || "").toLowerCase().includes(q);
  const sorter = (getName, getSize, getDate) => (a, b) => {
    if(state.sort === "name") return String(getName(a)).localeCompare(String(getName(b)));
    if(state.sort === "size") return (getSize(b) || 0) - (getSize(a) || 0);
    return (getDate(b) || 0) - (getDate(a) || 0);
  };

  function recordInfo(rec){
    const b = books().find(x => x.id === rec.bookId);
    return {
      rec, b,
      name: ur ? (b?.title || rec.title) : (b?.titleEn || rec.titleEn || b?.title || rec.title),
      author: ur ? (b?.author || rec.author) : (b?.authorEn || rec.authorEn || b?.author || rec.author),
      cover: b?.cover || rec.cover || ""
    };
  }

  function paintAccess(){
    if(!plugin){
      accessBox.innerHTML = `<div class="lb-banner"><i class="fa-solid fa-mobile-screen"></i><div><span>${T.androidOnly}</span></div></div>`;
      return;
    }
    if(!state.granted){
      accessBox.innerHTML = `<div class="lb-banner"><i class="fa-solid fa-folder-open"></i><div><strong>${T.accessTitle}</strong><span>${T.accessText}</span>
        <button class="btn primary" id="lbAllow" type="button">${T.accessBtn}</button></div></div>`;
      $("#lbAllow").onclick = () => { plugin.requestStorageAccess().catch(() => {}); };
      return;
    }
    const text = state.scanning ? T.scanning : (state.scanError ? T.scanFailed : T.found(state.files.length));
    accessBox.innerHTML = `<p class="lb-status ${state.scanning ? "is-busy" : ""}">${state.scanning ? '<i class="fa-solid fa-spinner fa-spin"></i> ' : ""}${escapeHTML(text)}</p>`;
  }

  function paintKr(){
    const q = state.query;
    const items = getDownloads().map(recordInfo)
      .filter(x => matches(x.name, q) || matches(x.author, q))
      .sort(sorter(x => x.name, x => x.rec.size, x => x.rec.savedAt));
    const total = getDownloads().length;
    const head = `<h2 class="dl-section"><i class="fa-solid fa-book-bookmark"></i> ${T.krTitle} <span class="dl-count">${total}</span></h2>`;
    if(!items.length){
      krBox.innerHTML = head + `<p class="dl-note">${total ? T.noMatch : T.krEmpty}</p>`;
      return;
    }
    krBox.innerHTML = head + `<div class="dl-list">${items.map(x => `
      <article class="dl-card ${state.missing.has(x.rec.bookId) ? "is-missing" : ""}" data-book="${escapeHTML(x.rec.bookId)}">
        <button class="dl-main" type="button" data-read="${escapeHTML(x.rec.bookId)}">
          <div class="book-cover dl-cover">${coverMarkup(x.cover ? escapeHTML(x.cover) : "")}</div>
          <div class="dl-info">
            <strong>${escapeHTML(x.name || "")}</strong>
            <span>${escapeHTML(x.author || "")}</span>
            <small class="dl-meta">${escapeHTML(formatBytes(x.rec.size))} · ${escapeHTML(formatDate(x.rec.savedAt, ur))}</small>
            <small class="dl-state">${state.missing.has(x.rec.bookId) ? T.missing : ""}</small>
          </div>
        </button>
        <button class="icon-btn dl-delete" type="button" data-delete="${escapeHTML(x.rec.bookId)}" aria-label="${T.del}" title="${T.del}"><i class="fa-solid fa-trash-can"></i></button>
      </article>`).join("")}</div>`;
    krBox.querySelectorAll(".dl-cover").forEach(wireCover);
  }

  function deviceItems(){
    const q = state.query;
    const krKeys = new Set(getDownloads().map(r => `${String(r.filename).toLowerCase()}|${r.size}`));
    return state.files
      .filter(f => !krKeys.has(`${String(f.name).toLowerCase()}|${f.size}`))
      .filter(f => matches(f.name, q))
      .sort(sorter(f => f.name, f => f.size, f => f.modified));
  }

  const observer = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      const box = entry.target;
      const file = { path: box.dataset.path, size: Number(box.dataset.size), modified: Number(box.dataset.mod) };
      thumbChain = thumbChain.then(async () => {
        if(state.destroyed || !box.isConnected || !plugin) return;
        try{
          const res = await plugin.thumbnail({ path: file.path, key: `${file.path}|${file.size}|${file.modified}`, width: 240 });
          if(res?.data && box.isConnected) box.innerHTML = `<img alt="" src="${res.data}">`;
        }catch{}
      });
    });
  }, { rootMargin: "300px" }) : null;

  function paintDevice(){
    if(!plugin){ devBox.innerHTML = ""; return; }
    const all = deviceItems();
    const shown = all.slice(0, state.limit);
    const head = `<h2 class="dl-section"><i class="fa-solid fa-file-pdf"></i> ${T.devTitle} <span class="dl-count">${all.length}</span></h2>`;
    if(!state.granted){ devBox.innerHTML = ""; return; }
    if(!all.length){
      devBox.innerHTML = head + `<p class="dl-note">${state.query ? T.noMatch : (state.scanning ? "" : T.devEmpty)}</p>`;
      return;
    }
    devBox.innerHTML = head + `<div class="dl-list">${shown.map((f, i) => `
      <article class="dl-card">
        <button class="dl-main" type="button" data-open="${i}">
          <div class="dl-cover dl-thumb" data-path="${escapeHTML(f.path)}" data-size="${f.size}" data-mod="${f.modified}"><i class="fa-regular fa-file-pdf"></i></div>
          <div class="dl-info">
            <strong>${escapeHTML(String(f.name).replace(/\.pdf$/i, ""))}</strong>
            <span>${escapeHTML(folderOf(f.path))}</span>
            <small class="dl-meta">${escapeHTML(formatBytes(f.size))} · ${escapeHTML(formatDate(f.modified, ur))}</small>
          </div>
        </button>
      </article>`).join("")}</div>
      ${all.length > shown.length ? `<div class="dl-more"><button class="btn" id="lbMore" type="button">${T.more}</button></div>` : ""}`;
    devBox.querySelectorAll("[data-open]").forEach(btn => btn.onclick = () => {
      const f = shown[Number(btn.dataset.open)];
      if(f) navigate("local", { path: f.path, name: f.name });
    });
    $("#lbMore")?.addEventListener("click", () => { state.limit += PAGE; paintDevice(); });
    if(observer) devBox.querySelectorAll(".dl-thumb").forEach(el => observer.observe(el));
  }

  function paintAll(){ paintAccess(); paintKr(); paintDevice(); }

  async function scan(){
    if(!plugin || !state.granted || state.scanning) return;
    state.scanning = true; state.scanError = false; paintAccess();
    try{
      const res = await plugin.scanPdfs();
      state.files = (res?.files || []).map(f => ({ path: f.path, name: f.name, size: Number(f.size), modified: Number(f.modified) }));
      writeScanCache(state.files);
    }catch(err){
      state.scanError = true;
      console.warn("PDF scan failed", err);
    }
    state.scanning = false;
    if(!state.destroyed){ state.limit = PAGE; paintAccess(); paintDevice(); }
  }

  async function refreshAccess(){
    if(!plugin) return;
    try{
      const res = await plugin.checkStorageAccess();
      const was = state.granted;
      state.granted = Boolean(res?.granted);
      if(state.destroyed) return;
      paintAccess(); paintDevice();
      if(state.granted && (!was || !state.files.length)) scan();
    }catch{}
  }

  // Books downloaded here: does the file still exist?
  if(plugin){
    getDownloads().forEach(async rec => {
      try{
        const info = await plugin.fileInfo({ id: rec.downloadId });
        if(info?.exists || state.destroyed) return;
        state.missing.add(rec.bookId);
        paintKr();
      }catch{}
    });
  }

  krBox.addEventListener("click", async e => {
    const readBtn = e.target.closest("[data-read]");
    const delBtn = e.target.closest("[data-delete]");
    if(readBtn){
      const id = readBtn.dataset.read;
      if(state.missing.has(id)){
        const b = books().find(x => x.id === id);
        if(!b){ removeDownloadRecord(id); paintKr(); return; }
        if(await confirmDialog(T.missing, T.againMsg, T.again, false)) downloadBookPdf(b);
        return;
      }
      navigate("local", { book: id });
    }else if(delBtn){
      const id = delBtn.dataset.delete;
      const rec = getDownloadRecord(id);
      if(!rec) return;
      if(!(await confirmDialog(T.delTitle, T.delMsg, T.del, true))) return;
      try{ await plugin?.deleteDownload({ id: rec.downloadId }); }catch{}
      removeDownloadRecord(id);
      showToast(T.deleted);
      paintKr(); paintDevice();
    }
  });

  let searchTimer = null;
  $("#lbSearch").addEventListener("input", e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.query = e.target.value.trim().toLowerCase(); state.limit = PAGE; paintKr(); paintDevice(); }, 160);
  });
  $("#lbSearchForm").addEventListener("submit", e => { e.preventDefault(); $("#lbSearch").blur(); });
  $("#lbSort").addEventListener("change", e => { state.sort = e.target.value; paintKr(); paintDevice(); });
  $("#lbRescan").addEventListener("click", () => {
    if(!plugin){ showToast(T.androidOnly); return; }
    if(!state.granted){ plugin.requestStorageAccess().catch(() => {}); return; }
    scan();
  });

  const onVisible = () => { if(document.visibilityState === "visible") refreshAccess(); };
  document.addEventListener("visibilitychange", onVisible);
  activeCleanup = () => {
    state.destroyed = true;
    clearTimeout(searchTimer);
    document.removeEventListener("visibilitychange", onVisible);
    observer?.disconnect();
  };

  paintAll();
  refreshAccess();
}
