package com.kr.urdulibrary;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "KRDownloader")
public class KRDownloaderPlugin extends Plugin {

    private DownloadManager manager() {
        return (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
    }

    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url");
        String filename = call.getString("filename", "book.pdf");
        String title = call.getString("title", filename);
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            request.setDescription("KR Urdu Library");
            request.setMimeType("application/pdf");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            request.addRequestHeader("x-kr-client", "KR-URDU-LIBRARY-PDF-V1");
            long id = manager().enqueue(request);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Could not start download");
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        Cursor c = null;
        try {
            JSObject ret = new JSObject();
            c = manager().query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()) {
                ret.put("found", true);
                ret.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                ret.put("downloaded", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                ret.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                ret.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                String uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                ret.put("uri", uri == null ? "" : uri);
            } else {
                ret.put("found", false);
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Could not read download status");
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Could not cancel download");
        }
    }
}
