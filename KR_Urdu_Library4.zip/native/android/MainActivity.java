package com.kr.urdulibrary;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KRDownloaderPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
