// Library screen: books downloaded from this app + every PDF found on the phone.
// Files are read straight from storage; nothing is copied into app storage.
import { getDownloads, getDownloadRecord, removeDownloadRecord } from "./downloads-store.js";
import { getNativePlugin } from "./download-manager.js";
import { typesetCover, paletteIndex } from "../components/book-card.js";
import { icon } from "../utils/icons.js";

const SCAN_KEY = "krl_device_scan_v1";
const PAGE = 60;
const VIEW_KEY = "krl_library_view_v1";
const readView = () => { try{ return localStorage.getItem(VIEW_KEY) === "list" ? "list" : "grid"; }catch{ return "grid"; } };
const saveView = v => { try{ localStorage.setItem(VIEW_KEY, v); }catch{} };
// Survives re-renders (e.g. coming back from the reader) so the list looks exactly as it was left.
const remembered = { sort: "date", query: "", limit: PAGE, granted: false };
let activeCleanup = null;
let thumbChain = Promise.resolve();

export function cleanupLibrary(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

function formatBytes(n){
  n = Number(n) || 0;
  if(n >= 1073741824) return (n / 1073741824).toFixed(1) + " GB";
  if(n >= 1048576) return (n / 1048576).toFixed(1) + " MB";
  if(n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}
function formatDate(ts, ur){
  try{ return new Date(ts).toLocaleDateString(ur ? "ur-PK" : "en-GB", { day: "numeric", month: "short", year: "numeric" }); }catch{ return ""; }
}
function readScanCache(){
  try{
    const v = JSON.parse(localStorage.getItem(SCAN_KEY) || "null");
    if(v && Array.isArray(v.files)) return v;
  }catch{}
  return { files: [], at: 0 };
}
function writeScanCache(files){
  try{
    localStorage.setItem(SCAN_KEY, JSON.stringify({ at: Date.now(), files: files.map(f => ({ p: f.path, n: f.name, s: f.size, m: f.modified })) }));
  }catch{}
}
function fromCache(v){ return v.files.map(f => ({ path: f.p, name: f.n, size: f.s, modified: f.m })); }
function folderOf(path){
  const parts = String(path).split("/").filter(Boolean);
  parts.pop();
  return parts.pop() || "";
}

export function renderLibrary(d){
  cleanupLibrary();
  const { lang, shell, books, navigate, showToast, confirmDialog, downloadBookPdf, coverMarkup, wireCover, escapeHTML } = d;
  const ur = lang === "ur";
  const T = ur ? {
    title: "لائبریری", intro: "اس ایپ سے ڈاؤنلوڈ کی ہوئی کتابیں اور آپ کے فون کی تمام PDF فائلیں، سب آف لائن پڑھیں۔",
    search: "کتابیں تلاش کریں…", sortDate: "تازہ ترین", sortName: "نام", sortSize: "سائز",
    krTitle: "KR لائبریری سے ڈاؤنلوڈ", devTitle: "فون کی دوسری PDF فائلیں",
    krEmpty: "ابھی کوئی کتاب ڈاؤنلوڈ نہیں ہوئی۔ کسی کتاب کا ڈاؤنلوڈ بٹن دبائیں۔",
    devEmpty: "کوئی PDF نہیں ملی۔", noMatch: "کوئی نتیجہ نہیں ملا۔",
    missing: "فائل نہیں ملی", del: "حذف کریں", delTitle: "فائل حذف کریں؟",
    delMsg: "یہ کتاب آپ کے فون کے ڈاؤنلوڈز فولڈر سے بھی حذف ہو جائے گی۔", deleted: "کتاب حذف ہوگئی۔",
    again: "دوبارہ ڈاؤنلوڈ کریں", againMsg: "یہ فائل فون میں موجود نہیں۔ کیا دوبارہ ڈاؤنلوڈ کریں؟",
    accessTitle: "فون کی PDF فائلیں دیکھنے کی اجازت دیں",
    accessText: "اجازت دینے کے بعد ایپ آپ کے فون کی تمام PDF فائلیں یہاں دکھا سکے گی۔ فائلیں کہیں کاپی یا اپلوڈ نہیں ہوتیں۔",
    accessBtn: "اجازت دیں", scanning: "PDF فائلیں تلاش کی جا رہی ہیں…", found: n => `${n} PDF فائلیں ملیں`,
    rescan: "دوبارہ تلاش کریں", more: "مزید دکھائیں", androidOnly: "یہ فہرست صرف اینڈرائیڈ ایپ میں کام کرتی ہے۔",
    scanFailed: "تلاش مکمل نہیں ہو سکی۔", browse: "کتابیں دیکھیں", sortBy: "ترتیب", viewAs: "دکھانے کا انداز", viewGrid: "گرڈ", viewList: "فہرست"
  } : {
    title: "Library", intro: "Books downloaded from this app and every PDF on your phone, all readable offline.",
    search: "Search your books…", sortDate: "Newest", sortName: "Name", sortSize: "Size",
    krTitle: "Downloaded from KR Library", devTitle: "Other PDFs on this phone",
    krEmpty: "No books downloaded yet. Tap Download on any book.",
    devEmpty: "No PDFs found.", noMatch: "No results found.",
    missing: "File not found", del: "Delete", delTitle: "Delete this file?",
    delMsg: "The book will also be removed from your phone's Downloads folder.", deleted: "Book deleted.",
    again: "Download again", againMsg: "This file is no longer on your phone. Download it again?",
    accessTitle: "Allow access to PDFs on your phone",
    accessText: "Once allowed, the app can list every PDF on your phone here. Files are never copied or uploaded.",
    accessBtn: "Allow access", scanning: "Looking for PDFs…", found: n => `${n} PDFs found`,
    rescan: "Scan again", more: "Show more", androidOnly: "This list works in the Android app only.",
    scanFailed: "The scan could not finish.", browse: "Browse books", sortBy: "Sort by", viewAs: "View as", viewGrid: "Grid", viewList: "List"
  };

  const plugin = getNativePlugin();
  const state = {
    query: remembered.query, sort: remembered.sort, view: readView(), limit: remembered.limit, granted: remembered.granted, scanning: false, scanError: false,
    files: fromCache(readScanCache()), missing: new Set(), destroyed: false
  };

  const page = shell(T.title, `<section class="lib-page">
    <header class="tab-head lb-head"><div><h1 class="tab-title">${T.title}</h1><p class="tab-sub">${T.intro}</p></div>
      <button class="lb-rescan" id="lbRescan" type="button" aria-label="${T.rescan}" title="${T.rescan}">${icon("refresh")}</button></header>
    <div id="lbAccess"></div>
    <form class="search-pill lb-search" id="lbSearchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="lbSearch" type="search" placeholder="${T.search}" aria-label="${T.search}" autocomplete="off" enterkeyhint="search"></form>
    <div class="lb-toolbar">
      <div class="lb-sort" id="lbSort" role="radiogroup" aria-label="${T.sortBy}">
        <button type="button" role="radio" aria-checked="true" data-sort="date">${T.sortDate}</button>
        <button type="button" role="radio" aria-checked="false" data-sort="name">${T.sortName}</button>
        <button type="button" role="radio" aria-checked="false" data-sort="size">${T.sortSize}</button>
      </div>
      <div class="lb-view" id="lbView" role="radiogroup" aria-label="${T.viewAs}">
        <button type="button" role="radio" aria-checked="${state.view === "grid"}" data-view="grid" aria-label="${T.viewGrid}" title="${T.viewGrid}">${icon("grid")}</button>
        <button type="button" role="radio" aria-checked="${state.view === "list"}" data-view="list" aria-label="${T.viewList}" title="${T.viewList}">${icon("list")}</button>
      </div>
    </div>
    <section class="lb-section" id="lbKr"></section>
    <section class="lb-section" id="lbDevice"></section>
  </section>`, "downloads");
  page.classList.add("library-page");

  const $ = s => page.querySelector(s);
  const accessBox = $("#lbAccess"), krBox = $("#lbKr"), devBox = $("#lbDevice");
  $("#lbSearch").value = state.query;
  $("#lbSort").querySelectorAll("[data-sort]").forEach(b => b.setAttribute("aria-checked", String(b.dataset.sort === state.sort)));
  const remember = () => { remembered.sort = state.sort; remembered.query = state.query; remembered.limit = state.limit; remembered.granted = state.granted; };

  const matches = (text, q) => !q || String(text || "").toLowerCase().includes(q);
  const sorter = (getName, getSize, getDate) => (a, b) => {
    if(state.sort === "name") return String(getName(a)).localeCompare(String(getName(b)));
    if(state.sort === "size") return (getSize(b) || 0) - (getSize(a) || 0);
    return (getDate(b) || 0) - (getDate(a) || 0);
  };

  function recordInfo(rec){
    const b = books().find(x => x.id === rec.bookId);
    return {
      rec, b,
      name: ur ? (b?.title || rec.title) : (b?.titleEn || rec.titleEn || b?.title || rec.title),
      author: ur ? (b?.author || rec.author) : (b?.authorEn || rec.authorEn || b?.author || rec.author),
      cover: b?.cover || rec.cover || ""
    };
  }

  const head = (ico, title, count) => `<h2 class="lb-title"><span class="lb-title-ico">${icon(ico)}</span><span>${title}</span><span class="lb-count">${count}</span></h2>`;
  const empty = (ico, text, cta = "") => `<div class="lb-empty">${icon(ico)}<p>${text}</p>${cta}</div>`;
  // File sizes ("17.5 MB") stay left-to-right even inside Urdu (RTL) text.
  const ltr = text => `\u2066${text}\u2069`;
  const meta = (...parts) => `<span class="file-meta">${parts.filter(Boolean).map(x => `<span>${escapeHTML(x)}</span>`).join("")}</span>`;

  function paintAccess(){
    $("#lbRescan").classList.toggle("is-spinning", state.scanning);
    if(!plugin){
      accessBox.innerHTML = `<div class="lb-note">${icon("phone")}<span>${T.androidOnly}</span></div>`;
      return;
    }
    if(!state.granted){
      accessBox.innerHTML = `<div class="lb-card"><span class="lb-medal">${icon("folder")}</span><div><strong>${T.accessTitle}</strong><p>${T.accessText}</p>
        <button class="cta-btn" id="lbAllow" type="button">${T.accessBtn}${icon("arrow")}</button></div></div>`;
      $("#lbAllow").onclick = () => { plugin.requestStorageAccess().catch(() => {}); };
      return;
    }
    const text = state.scanning ? T.scanning : (state.scanError ? T.scanFailed : T.found(state.files.length));
    const lead = state.scanning ? '<i class="lb-spin"></i>' : '<i class="lb-dot"></i>';
    accessBox.innerHTML = `<p class="lb-status${state.scanning ? " is-busy" : ""}${state.scanError ? " is-error" : ""}" role="status">${lead}<span>${escapeHTML(text)}</span></p>`;
  }

  function paintKr(){
    const q = state.query;
    const items = getDownloads().map(recordInfo)
      .filter(x => matches(x.name, q) || matches(x.author, q))
      .sort(sorter(x => x.name, x => x.rec.size, x => x.rec.savedAt));
    const total = getDownloads().length;
    const top = head("download", T.krTitle, total);
    if(!items.length){
      krBox.innerHTML = top + (total ? empty("search", T.noMatch)
        : empty("book", T.krEmpty, `<a class="cta-btn" href="#catalogue">${T.browse}${icon("arrow")}</a>`));
      return;
    }
    const grid = state.view === "grid";
    krBox.innerHTML = top + `<div class="${grid ? "file-grid" : "file-list"}">${items.map(x => {
      const missing = state.missing.has(x.rec.bookId);
      const id = escapeHTML(x.rec.bookId), title = x.name || "";
      const art = `${typesetCover(title, x.author, x.rec.bookId)}${x.cover ? coverMarkup(escapeHTML(x.cover)) : ""}`;
      if(grid) return `
      <article class="file-card${missing ? " is-missing" : ""}" data-book="${id}">
        <button class="file-card-main" type="button" data-read="${id}">
          <span class="cover file-card-cover file-thumb">${art}${missing ? `<span class="file-card-flag">${icon("alert")}</span>` : ""}</span>
          <strong class="file-card-title">${escapeHTML(title)}</strong>
          <span class="file-card-sub">${escapeHTML(x.author || "")}</span>
          ${meta(ltr(formatBytes(x.rec.size)), formatDate(x.rec.savedAt, ur))}
          ${missing ? `<span class="file-sr">${T.missing}</span>` : ""}
        </button>
        <button class="file-card-delete" type="button" data-delete="${id}" aria-label="${T.del}" title="${T.del}">${icon("trash")}</button>
      </article>`;
      return `
      <article class="file-row${missing ? " is-missing" : ""}" data-book="${id}">
        <button class="file-main" type="button" data-read="${id}">
          <span class="cover is-mini file-thumb">${art}</span>
          <span class="file-info">
            <strong class="file-title">${escapeHTML(title)}</strong>
            <span class="file-sub">${escapeHTML(x.author || "")}</span>
            ${meta(ltr(formatBytes(x.rec.size)), formatDate(x.rec.savedAt, ur))}
            ${missing ? `<span class="file-flag">${icon("alert")}${T.missing}</span>` : ""}
          </span>
        </button>
        <button class="file-delete" type="button" data-delete="${id}" aria-label="${T.del}" title="${T.del}">${icon("trash")}</button>
      </article>`;
    }).join("")}</div>`;
    krBox.querySelectorAll(".file-thumb").forEach(wireCover);
  }

  function deviceItems(){
    const q = state.query;
    const krKeys = new Set(getDownloads().map(r => `${String(r.filename).toLowerCase()}|${r.size}`));
    return state.files
      .filter(f => !krKeys.has(`${String(f.name).toLowerCase()}|${f.size}`))
      .filter(f => matches(f.name, q))
      .sort(sorter(f => f.name, f => f.size, f => f.modified));
  }

  const observer = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      const box = entry.target;
      const file = { path: box.dataset.path, size: Number(box.dataset.size), modified: Number(box.dataset.mod) };
      thumbChain = thumbChain.then(async () => {
        if(state.destroyed || !box.isConnected || !plugin) return;
        try{
          const res = await plugin.thumbnail({ path: file.path, key: `${file.path}|${file.size}|${file.modified}`, width: 240 });
          if(res?.data && box.isConnected){
            const img = new Image();
            img.alt = "";
            img.addEventListener("load", () => img.classList.add("is-loaded"), { once: true });
            img.src = res.data;
            box.appendChild(img);
          }
        }catch{}
      });
    });
  }, { rootMargin: "300px" }) : null;

  function paintDevice(){
    if(!plugin || !state.granted){ devBox.innerHTML = ""; return; }
    const all = deviceItems();
    const shown = all.slice(0, state.limit);
    const top = head("pdf", T.devTitle, all.length);
    if(!all.length){
      if(state.scanning && !state.query){
        const sk = state.view === "grid"
          ? `<div class="file-card is-skeleton"><span class="cover file-card-cover file-thumb"></span><i class="sk w70"></i><i class="sk w40"></i></div>`.repeat(6)
          : `<div class="file-row is-skeleton"><span class="cover is-mini file-thumb"></span><span class="file-info"><i class="sk w70"></i><i class="sk w40"></i><i class="sk w55"></i></span></div>`.repeat(4);
        devBox.innerHTML = top + `<div class="${state.view === "grid" ? "file-grid" : "file-list"}" aria-hidden="true">${sk}</div>`;
      }else{
        devBox.innerHTML = top + empty(state.query ? "search" : "pdf", state.query ? T.noMatch : T.devEmpty);
      }
      return;
    }
    const grid = state.view === "grid";
    devBox.innerHTML = top + `<div class="${grid ? "file-grid" : "file-list"}">${shown.map((f, i) => {
      const name = escapeHTML(String(f.name).replace(/\.pdf$/i, ""));
      const thumb = `data-path="${escapeHTML(f.path)}" data-size="${f.size}" data-mod="${f.modified}"`;
      if(grid) return `
      <article class="file-card">
        <button class="file-card-main" type="button" data-open="${i}">
          <span class="cover file-card-cover file-thumb is-pdf" ${thumb}>${icon("pdf", "file-glyph")}<b class="file-ext">PDF</b></span>
          <strong class="file-card-title">${name}</strong>
          <span class="file-card-sub">${escapeHTML(folderOf(f.path))}</span>
          ${meta(ltr(formatBytes(f.size)), formatDate(f.modified, ur))}
        </button>
      </article>`;
      return `
      <article class="file-row">
        <button class="file-main" type="button" data-open="${i}">
          <span class="cover is-mini file-thumb is-pdf" ${thumb}>${icon("pdf", "file-glyph")}<b class="file-ext">PDF</b></span>
          <span class="file-info">
            <strong class="file-title">${name}</strong>
            <span class="file-sub">${icon("folder")}<span>${escapeHTML(folderOf(f.path))}</span></span>
            ${meta(ltr(formatBytes(f.size)), formatDate(f.modified, ur))}
          </span>
        </button>
      </article>`;
    }).join("")}</div>
      ${all.length > shown.length ? `<div class="lb-more"><button class="lb-more-btn" id="lbMore" type="button">${T.more}<span>${all.length - shown.length}</span></button></div>` : ""}`;
    devBox.querySelectorAll("[data-open]").forEach(btn => btn.onclick = () => {
      const f = shown[Number(btn.dataset.open)];
      if(f) navigate("local", { path: f.path, name: f.name });
    });
    $("#lbMore")?.addEventListener("click", () => { state.limit += PAGE; remember(); paintDevice(); });
    if(observer) devBox.querySelectorAll(".is-pdf").forEach(el => observer.observe(el));
  }

  function paintAll(){ paintAccess(); paintKr(); paintDevice(); }

  async function scan(){
    if(!plugin || !state.granted || state.scanning) return;
    state.scanning = true; state.scanError = false; paintAccess(); paintDevice();
    try{
      const res = await plugin.scanPdfs();
      state.files = (res?.files || []).map(f => ({ path: f.path, name: f.name, size: Number(f.size), modified: Number(f.modified) }));
      writeScanCache(state.files);
    }catch(err){
      state.scanError = true;
      console.warn("PDF scan failed", err);
    }
    state.scanning = false;
    if(!state.destroyed){ paintAccess(); paintDevice(); }
  }

  async function refreshAccess(){
    if(!plugin) return;
    try{
      const res = await plugin.checkStorageAccess();
      const was = state.granted;
      state.granted = Boolean(res?.granted);
      remember();
      if(state.destroyed) return;
      paintAccess(); paintDevice();
      if(state.granted && (!was || !state.files.length)) scan();
    }catch{}
  }

  // Books downloaded here: does the file still exist?
  if(plugin){
    getDownloads().forEach(async rec => {
      try{
        const info = await plugin.fileInfo({ id: rec.downloadId });
        if(info?.exists || state.destroyed) return;
        state.missing.add(rec.bookId);
        paintKr();
      }catch{}
    });
  }

  krBox.addEventListener("click", async e => {
    const readBtn = e.target.closest("[data-read]");
    const delBtn = e.target.closest("[data-delete]");
    if(readBtn){
      const id = readBtn.dataset.read;
      if(state.missing.has(id)){
        const b = books().find(x => x.id === id);
        if(!b){ removeDownloadRecord(id); paintKr(); return; }
        if(await confirmDialog(T.missing, T.againMsg, T.again, false)) downloadBookPdf(b);
        return;
      }
      navigate("local", { book: id });
    }else if(delBtn){
      const id = delBtn.dataset.delete;
      const rec = getDownloadRecord(id);
      if(!rec) return;
      if(!(await confirmDialog(T.delTitle, T.delMsg, T.del, true))) return;
      try{ await plugin?.deleteDownload({ id: rec.downloadId }); }catch{}
      removeDownloadRecord(id);
      showToast(T.deleted);
      paintKr(); paintDevice();
    }
  });

  let searchTimer = null;
  $("#lbSearch").addEventListener("input", e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.query = e.target.value.trim().toLowerCase(); state.limit = PAGE; remember(); paintKr(); paintDevice(); }, 160);
  });
  $("#lbSearchForm").addEventListener("submit", e => { e.preventDefault(); $("#lbSearch").blur(); });
  $("#lbSort").addEventListener("click", e => {
    const btn = e.target.closest("[data-sort]");
    if(!btn || btn.dataset.sort === state.sort) return;
    state.sort = btn.dataset.sort;
    $("#lbSort").querySelectorAll("[data-sort]").forEach(b => b.setAttribute("aria-checked", String(b === btn)));
    remember(); paintKr(); paintDevice();
  });
  $("#lbView").addEventListener("click", e => {
    const btn = e.target.closest("[data-view]");
    if(!btn || btn.dataset.view === state.view) return;
    state.view = btn.dataset.view;
    saveView(state.view);
    $("#lbView").querySelectorAll("[data-view]").forEach(b => b.setAttribute("aria-checked", String(b === btn)));
    paintKr(); paintDevice();
  });
  $("#lbRescan").addEventListener("click", () => {
    if(!plugin){ showToast(T.androidOnly); return; }
    if(!state.granted){ plugin.requestStorageAccess().catch(() => {}); return; }
    scan();
  });

  const onVisible = () => { if(document.visibilityState === "visible") refreshAccess(); };
  document.addEventListener("visibilitychange", onVisible);
  activeCleanup = () => {
    state.destroyed = true;
    clearTimeout(searchTimer);
    document.removeEventListener("visibilitychange", onVisible);
    observer?.disconnect();
  };

  paintAll();
  refreshAccess();
}
