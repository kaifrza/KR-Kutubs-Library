import { escapeHTML, formatPages } from "../utils/helpers.js";
import { isFavorite, toggleFavorite } from "../utils/storage.js";
import { coverMarkup, wireCover } from "../utils/cover.js";

/* Book cards are cover-first: the cover is the hero, the text underneath is
   just title, author and one quiet meta line. Books without a cover get a
   typeset cover made from their own title instead of a generic placeholder. */

export const HEART = `<svg class="heart" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 20.8s-7.6-4.7-9.6-9.6C1 7.7 3.1 4.4 6.5 4.4c2 0 3.5 1 4.5 2.6.4.6.7.6 1 0 1-1.6 2.5-2.6 4.5-2.6 3.4 0 5.5 3.3 4.1 6.8-2 4.9-9.6 9.6-9.6 9.6z"/></svg>`;

export function paletteIndex(id) {
  let h = 0;
  for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h % 6;
}

export function typesetCover(title, author, id) {
  return `<div class="tcover tc-${paletteIndex(id)}" aria-hidden="true"><span class="tc-title">${escapeHTML(title)}</span><span class="tc-rule"></span><span class="tc-author">${escapeHTML(author || "")}</span></div>`;
}

export function bookCard(book, lang, onOpen) {
  const card = document.createElement("article");
  card.className = "book-card";
  card.tabIndex = 0;
  card.dataset.bookId = book.id;
  card.setAttribute("role", "link");
  const ur = lang === "ur";
  const title = ur ? book.title : (book.titleEn || book.title);
  const type = book.bookType === "matn" ? (ur ? "متون" : "Matn") : (ur ? "شروحات" : "Commentary");
  const pages = formatPages(book.pages, lang);
  const fav = isFavorite(book.id);
  const available = book.status === "available";
  const favLabel = ur ? (fav ? "پسندیدہ سے ہٹائیں" : "پسندیدہ میں شامل کریں") : (fav ? "Remove favorite" : "Add favorite");
  if (!available) card.classList.add("is-unavailable");

  card.innerHTML = `
    <button type="button" class="favorite-btn ${fav ? "active" : ""}" aria-label="${favLabel}" aria-pressed="${fav}">${HEART}</button>
    <div class="book-cover">
      ${typesetCover(title, book.author, book.id)}
      ${book.cover ? coverMarkup(escapeHTML(book.cover)) : ""}
    </div>
    <div class="book-info">
      <h3 class="book-title">${escapeHTML(title)}</h3>
      <p class="book-author">${escapeHTML(book.author || "")}</p>
      <div class="book-meta"><span class="book-type">${type}</span>${pages ? `<span class="book-pages">${escapeHTML(pages)}</span>` : ""}</div>
      ${available ? "" : `<div class="status unavailable">${ur ? "فی الحال دستیاب نہیں" : "Currently unavailable"}</div>`}
    </div>
  `;

  const coverEl = card.querySelector(".book-cover");
  wireCover(coverEl);
  const img = coverEl.querySelector("img");
  if (img) img.addEventListener("load", () => img.classList.add("is-loaded"), { once: true });

  const heartBtn = card.querySelector(".favorite-btn");
  heartBtn.addEventListener("click", e => {
    e.stopPropagation();
    const result = toggleFavorite(book.id);
    const nowFavorite = Array.isArray(result) ? result.includes(book.id) : Boolean(result);
    const label = ur
      ? (nowFavorite ? "پسندیدہ سے ہٹائیں" : "پسندیدہ میں شامل کریں")
      : (nowFavorite ? "Remove favorite" : "Add favorite");
    heartBtn.classList.toggle("active", nowFavorite);
    heartBtn.setAttribute("aria-label", label);
    heartBtn.setAttribute("aria-pressed", String(nowFavorite));
    if (nowFavorite) {
      heartBtn.classList.remove("pop");
      void heartBtn.offsetWidth;            // restart the animation
      heartBtn.classList.add("pop");
      try { navigator.vibrate?.(10); } catch {}
    }
    card.dispatchEvent(new CustomEvent("favoritechange", { bubbles: false, detail: { id: book.id, favorite: nowFavorite } }));
  });
  heartBtn.addEventListener("animationend", () => heartBtn.classList.remove("pop"));

  const openCard = () => onOpen?.("book", book.id);
  card.addEventListener("click", e => { if (e.target.closest(".favorite-btn")) return; openCard(); });
  card.addEventListener("keydown", e => {
    if ((e.key === "Enter" || e.key === " ") && e.target === card) { e.preventDefault(); openCard(); }
  });
  return card;
}
