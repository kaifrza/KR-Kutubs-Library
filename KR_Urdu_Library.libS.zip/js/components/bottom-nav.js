import { navigate } from "../router.js";

/* ------------------------------------------------------------------
   Floating dock. One number, --x, describes the whole animation: it is the
   (fractional) position of the active tab. CSS derives every width, colour,
   icon fill and the pill position from it, so all of it stays in sync.
   The value is driven by a small spring below and survives re-renders
   (the nav element is rebuilt on every screen change), which is why the
   motion never restarts or jumps when the next screen appears.
------------------------------------------------------------------ */

const TABS = ["home", "classes", "categories", "downloads", "more"];

const ICONS = {
  home: `<path class="f" d="M4 10.8 11.2 4.4a1.2 1.2 0 0 1 1.6 0L20 10.8V19a1.5 1.5 0 0 1-1.5 1.5H15v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5H5.5A1.5 1.5 0 0 1 4 19z"/>`,
  classes: `<path class="f" d="M12 6.6C10.3 5.3 8 4.7 4.6 4.9c-.3 0-.6.3-.6.6v11.7c0 .3.3.6.6.6 3.3-.2 5.5.4 7.4 1.8 1.9-1.4 4.1-2 7.4-1.8.3 0 .6-.3.6-.6V5.5c0-.3-.3-.6-.6-.6C16 4.7 13.7 5.3 12 6.6z"/><path d="M12 6.8v11.6"/>`,
  categories: `<rect class="f" x="4" y="4" width="6.6" height="6.6" rx="1.9"/><rect class="f" x="13.4" y="4" width="6.6" height="6.6" rx="1.9"/><rect class="f" x="4" y="13.4" width="6.6" height="6.6" rx="1.9"/><rect class="f" x="13.4" y="13.4" width="6.6" height="6.6" rx="1.9"/>`,
  downloads: `<path class="f" d="M7.5 4h9A1.5 1.5 0 0 1 18 5.5V20l-6-3.9L6 20V5.5A1.5 1.5 0 0 1 7.5 4z"/>`,
  more: `<circle class="d" cx="5.5" cy="12" r="1.75"/><circle class="d" cx="12" cy="12" r="1.75"/><circle class="d" cx="18.5" cy="12" r="1.75"/>`
};

/* Spring state lives at module level so it persists across screen renders. */
const S = { x: null, v: 0, tx: 0, on: 1, von: 0, ton: 1, raf: 0, last: 0, el: null };
const reduceMotion = () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

function paint() {
  const el = S.el;
  if (!el) return;
  const squash = Math.min(0.09, Math.abs(S.v) * 0.009);
  el.style.setProperty("--x", S.x.toFixed(4));
  el.style.setProperty("--on", Math.max(0, Math.min(1, S.on)).toFixed(4));
  el.style.setProperty("--s", squash.toFixed(4));
}

function frame(now) {
  const dt = Math.min(0.034, (now - S.last) / 1000 || 0.016);
  S.last = now;
  // x: lively spring with a hint of overshoot. on: critically damped fade.
  const kx = 360, cx = 2 * Math.sqrt(kx) * 0.72;
  const ko = 240, co = 2 * Math.sqrt(ko);
  for (let n = 0; n < 2; n++) {
    const h = dt / 2;
    S.v += (-kx * (S.x - S.tx) - cx * S.v) * h; S.x += S.v * h;
    S.von += (-ko * (S.on - S.ton) - co * S.von) * h; S.on += S.von * h;
  }
  const rest = Math.abs(S.x - S.tx) < 0.0008 && Math.abs(S.v) < 0.01 && Math.abs(S.on - S.ton) < 0.001 && Math.abs(S.von) < 0.01;
  if (rest) { S.x = S.tx; S.v = 0; S.on = S.ton; S.von = 0; S.raf = 0; paint(); return; }
  paint();
  S.raf = requestAnimationFrame(frame);
}

function go(tx, ton) {
  S.tx = tx; S.ton = ton;
  if (reduceMotion()) { S.x = tx; S.v = 0; S.on = ton; S.von = 0; paint(); return; }
  if (!S.raf) { S.last = performance.now(); S.raf = requestAnimationFrame(frame); }
}

export function renderBottomNav(active, lang) {
  const ur = lang === "ur";
  const names = ur
    ? { home: "گھر", classes: "جماعتیں", categories: "زمرے", downloads: "لائبریری", more: "مزید" }
    : { home: "Home", classes: "Classes", categories: "Categories", downloads: "Library", more: "More" };

  const activeIndex = TABS.indexOf(active);
  const idle = activeIndex < 0;

  const nav = document.createElement("nav");
  nav.className = "bottom-nav";
  nav.setAttribute("aria-label", ur ? "مرکزی نیویگیشن" : "Main navigation");

  const track = document.createElement("div");
  track.className = "nav-track";
  track.innerHTML = `<span class="nav-pill" aria-hidden="true"></span>`;

  TABS.forEach((route, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "nav-item";
    b.style.setProperty("--j", String(i));
    b.setAttribute("aria-label", names[route]);
    if (route === active) b.setAttribute("aria-current", "page");
    b.innerHTML = `<svg class="nav-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[route]}</svg>`;
    b.addEventListener("click", () => {
      if (route !== active) {
        // Respond instantly; the next screen renders while the pill is already travelling.
        track.querySelectorAll(".nav-item").forEach((el, n) => {
          if (n === i) el.setAttribute("aria-current", "page"); else el.removeAttribute("aria-current");
        });
        go(i, 1);
        try { navigator.vibrate?.(8); } catch {}
      }
      navigate(route);
    });
    track.appendChild(b);
  });
  nav.appendChild(track);

  S.el = nav;
  if (S.x === null) {                       // very first paint: no animation
    S.x = S.tx = idle ? 0 : activeIndex;
    S.on = S.ton = idle ? 0 : 1;
  }
  paint();
  go(idle ? S.tx : activeIndex, idle ? 0 : 1);
  return nav;
}
