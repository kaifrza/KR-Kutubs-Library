// In-app PDF reader for files that live on the phone (Downloads / "Open with").
// Continuous vertical scrolling like Google Drive: every page sits in one long
// scrollable column. Only pages near the screen are rendered, so big books stay fast.
import { escapeHTML } from "../utils/helpers.js";
import { getBookProgress, setProgress } from "../utils/storage.js";
import { loadPdfJs } from "./pdfjs-loader.js";
import { openNativeFile, loadLocalPdf, nativeReaderAvailable } from "./local-file.js";

const PAD = 8;   // side padding (css px)
const GAP = 10;  // space between pages (css px)
const MIN_ZOOM = .6, MAX_ZOOM = 4;

let activeCleanup = null;

export function cleanupLocalReader(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

export function renderLocalReader(app, { lang = "en", title = "PDF", source, progressKey }){
  cleanupLocalReader();
  const ur = lang === "ur";
  const L = ur ? {
    more:"مزید", jump:"صفحہ پر جائیں", fit:"چوڑائی کے مطابق", zoomIn:"زوم بڑھائیں", zoomOut:"زوم کم کریں",
    close:"بند کریں", go:"جائیں", page:"صفحہ", of:"از", invalid:"درست صفحہ نمبر درج کریں۔",
    loading:"کتاب کھل رہی ہے…", failed:"یہ فائل نہیں کھل سکی۔",
    hint:"ممکن ہے فائل ہٹا دی گئی ہو یا کسی اور جگہ منتقل ہوگئی ہو۔", retry:"دوبارہ کوشش کریں",
    androidOnly:"یہ فیچر صرف اینڈرائیڈ ایپ میں دستیاب ہے۔"
  } : {
    more:"More", jump:"Jump to page", fit:"Fit to width", zoomIn:"Zoom in", zoomOut:"Zoom out",
    close:"Close", go:"Go", page:"Page", of:"of", invalid:"Enter a valid page number.",
    loading:"Opening book…", failed:"This file could not be opened.",
    hint:"It may have been moved or deleted.", retry:"Try again",
    androidOnly:"This feature is only available in the Android app."
  };

  const saved = progressKey ? getBookProgress(progressKey) : null;
  const savedPage = Math.max(1, Number(saved?.page) || 1);

  let pdf = null, task = null, file = null;
  let numPages = 0, zoom = 1, currentPage = savedPage;
  let ratios = [], tops = [], heights = [];
  let W = 0, containerW = 0, totalH = 0, layoutVersion = 0;
  const wrappers = new Map();
  let pumping = false, destroyed = false, controlsHidden = false, sliding = false;
  let rafId = 0, saveTimer = null, pillTimer = null, resizeTimer = null;

  app.innerHTML = `<main class="reader-shell local-reader" aria-label="${escapeHTML(title)}">
    <header class="reader-top">
      <button class="icon-btn" id="lrBack" type="button" aria-label="Back"><i class="fa-solid ${ur ? "fa-arrow-right" : "fa-arrow-left"}"></i></button>
      <strong class="reader-title" title="${escapeHTML(title)}">${escapeHTML(title)}</strong>
      <div class="reader-more-wrap">
        <button class="icon-btn" id="lrMore" type="button" aria-label="${L.more}" aria-haspopup="menu" aria-expanded="false"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        <div class="reader-more-menu" id="lrMenu" role="menu" hidden>
          <button type="button" role="menuitem" data-action="jump"><i class="fa-solid fa-arrow-right-to-bracket"></i><span>${L.jump}</span></button>
          <button type="button" role="menuitem" data-action="fit"><i class="fa-solid fa-left-right"></i><span>${L.fit}</span></button>
          <button type="button" role="menuitem" data-action="zoomOut"><i class="fa-solid fa-minus"></i><span>${L.zoomOut}</span></button>
          <button type="button" role="menuitem" data-action="zoomIn"><i class="fa-solid fa-plus"></i><span>${L.zoomIn}</span></button>
        </div>
      </div>
    </header>
    <section class="reader-body lr-body" id="lrBody" tabindex="0" aria-label="${escapeHTML(title)}" aria-busy="true">
      <div class="reader-loading" id="lrLoading"><i class="fa-solid fa-spinner fa-spin"></i><span>${L.loading}</span></div>
      <div class="lr-pages" id="lrPages"></div>
      <div class="lr-pill" id="lrPill" hidden></div>
    </section>
    <footer class="reader-bottom">
      <div class="reader-controls">
        <input class="lr-slider" id="lrSlider" type="range" min="1" max="1" value="1" step="1" disabled aria-label="${L.jump}">
        <div class="reader-primary">
          <button class="icon-btn" id="lrPrev" type="button" disabled aria-label="Previous page"><i class="fa-solid fa-chevron-up"></i></button>
          <span id="pageInfo" aria-live="polite">—</span>
          <button class="icon-btn" id="lrNext" type="button" disabled aria-label="Next page"><i class="fa-solid fa-chevron-down"></i></button>
        </div>
      </div>
    </footer>
  </main>`;

  const $ = s => app.querySelector(s);
  const shellEl = $(".reader-shell"), body = $("#lrBody"), loading = $("#lrLoading"), pagesEl = $("#lrPages");
  const menu = $("#lrMenu"), moreBtn = $("#lrMore"), pageInfo = $("#pageInfo"), pill = $("#lrPill");
  const slider = $("#lrSlider"), prevBtn = $("#lrPrev"), nextBtn = $("#lrNext");

  // ---------------- helpers ----------------
  const clampPage = n => Math.min(numPages || 1, Math.max(1, n));
  const saveProgress = () => {
    if(!numPages || !progressKey) return;
    setProgress(progressKey, { page: currentPage, totalPages: numPages, percent: Math.round(currentPage / numPages * 100) });
  };
  const closeMenu = () => { menu.hidden = true; moreBtn.setAttribute("aria-expanded", "false"); };
  const toggleMenu = () => { const open = menu.hidden; menu.hidden = !open; moreBtn.setAttribute("aria-expanded", String(open)); };

  function indexAt(y){
    let lo = 0, hi = numPages - 1;
    while(lo < hi){
      const mid = (lo + hi + 1) >> 1;
      if(tops[mid] <= y) lo = mid; else hi = mid - 1;
    }
    return lo;
  }

  function showPill(){
    if(!numPages) return;
    pill.textContent = `${currentPage} / ${numPages}`;
    pill.hidden = false;
    clearTimeout(pillTimer);
    pillTimer = setTimeout(() => { pill.hidden = true; }, 1200);
  }

  function setCurrent(n){
    currentPage = clampPage(n);
    pageInfo.textContent = `${currentPage} / ${numPages}`;
    if(!sliding) slider.value = String(currentPage);
    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= numPages;
  }

  // ---------------- layout ----------------
  function positionWrapper(el, i){
    el.style.top = `${tops[i]}px`;
    el.style.left = `${Math.round((containerW - W) / 2)}px`;
    el.style.width = `${W}px`;
    el.style.height = `${heights[i]}px`;
  }

  function layout(){
    const vw = body.clientWidth || 360;
    W = Math.max(120, Math.round((vw - PAD * 2) * zoom));
    containerW = Math.max(vw, W + PAD * 2);
    let y = GAP;
    for(let i = 0; i < numPages; i++){
      const h = Math.round(W * ratios[i]);
      heights[i] = h; tops[i] = y; y += h + GAP;
    }
    totalH = y;
    pagesEl.style.width = `${containerW}px`;
    pagesEl.style.height = `${totalH}px`;
    layoutVersion++;
  }

  // A page turned out to have a different shape than assumed: fix heights below it.
  function applyRatio(i, r){
    const oldH = heights[i];
    ratios[i] = r;
    const newH = Math.round(W * r);
    const delta = newH - oldH;
    if(!delta) return;
    const before = body.scrollTop;
    heights[i] = newH;
    for(let k = i + 1; k < numPages; k++) tops[k] += delta;
    totalH += delta;
    pagesEl.style.height = `${totalH}px`;
    for(const [k, w] of wrappers){
      if(k === i) w.el.style.height = `${newH}px`;
      else if(k > i) w.el.style.top = `${tops[k]}px`;
    }
    if(tops[i] + oldH <= before) body.scrollTop = before + delta;
  }

  // ---------------- virtual window ----------------
  function dispose(i){
    const w = wrappers.get(i);
    if(!w) return;
    if(w.task){ try{ w.task.cancel(); }catch{} }
    const c = w.el.querySelector("canvas");
    if(c){ c.width = 0; c.height = 0; }
    w.el.remove();
    wrappers.delete(i);
  }
  function clearWrappers(){ for(const i of Array.from(wrappers.keys())) dispose(i); }

  function createWrapper(i){
    const el = document.createElement("div");
    el.className = "lr-page";
    el.dataset.page = String(i + 1);
    el.innerHTML = `<div class="lr-ph"><i class="fa-solid fa-spinner fa-spin"></i></div>`;
    positionWrapper(el, i);
    pagesEl.appendChild(el);
    wrappers.set(i, { el, rendered: false, task: null });
  }

  function update(){
    if(!pdf || !numPages || destroyed) return;
    const st = body.scrollTop, vh = body.clientHeight, m = vh * 1.2;
    const a = indexAt(Math.max(0, st - m)), b = indexAt(st + vh + m);
    for(const i of Array.from(wrappers.keys())) if(i < a || i > b) dispose(i);
    for(let i = a; i <= b; i++) if(!wrappers.has(i)) createWrapper(i);
    setCurrent(indexAt(st + vh * .35) + 1);
    pump();
  }

  function nextToRender(){
    const center = body.scrollTop + body.clientHeight / 2;
    let best = -1, bestD = Infinity;
    for(const [i, w] of wrappers){
      if(w.rendered) continue;
      const d = Math.abs(tops[i] + heights[i] / 2 - center);
      if(d < bestD){ bestD = d; best = i; }
    }
    return best;
  }

  async function pump(){
    if(pumping) return;
    pumping = true;
    try{
      while(!destroyed){
        const idx = nextToRender();
        if(idx < 0) break;
        await renderIndex(idx);
      }
    }finally{
      pumping = false;
    }
  }

  async function renderIndex(i){
    const w = wrappers.get(i);
    if(!w) return;
    const ver = layoutVersion;
    let page;
    try{
      page = await pdf.getPage(i + 1);
    }catch(err){
      w.rendered = true;
      return;
    }
    if(destroyed || wrappers.get(i) !== w || ver !== layoutVersion){
      try{ page.cleanup?.(); }catch{}
      return;
    }
    try{
      const base = page.getViewport({ scale: 1 });
      const ratio = base.height / base.width;
      if(Math.abs(ratio - ratios[i]) > .004) applyRatio(i, ratio);
      const cssW = W, cssH = heights[i];
      const viewport = page.getViewport({ scale: cssW / base.width });
      let dpr = Math.min(2.5, window.devicePixelRatio || 1);
      if(cssW * cssH * dpr * dpr > 16000000) dpr = Math.max(1, Math.sqrt(16000000 / (cssW * cssH)));
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil(viewport.width * dpr);
      canvas.height = Math.ceil(viewport.height * dpr);
      const ctx = canvas.getContext("2d", { alpha: false });
      const rt = page.render({ canvasContext: ctx, viewport, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
      w.task = rt;
      await rt.promise;
      w.task = null;
      if(!destroyed && wrappers.get(i) === w && ver === layoutVersion){
        w.el.querySelector("canvas")?.remove();
        w.el.appendChild(canvas);
        w.el.classList.add("is-ready");
        w.rendered = true;
      }
    }catch(err){
      w.task = null;
      if(err?.name === "RenderingCancelledException") return;
      w.rendered = true;
      console.warn("Page render failed", i + 1, err);
    }finally{
      try{ page.cleanup?.(); }catch{}
    }
  }

  // ---------------- navigation & zoom ----------------
  function goTo(n, smooth){
    if(!numPages) return;
    const top = Math.max(0, tops[clampPage(n) - 1] - GAP);
    if(smooth) body.scrollTo({ top, behavior: "smooth" });
    else{ body.scrollTop = top; update(); }
  }

  function captureAnchor(){
    const c = body.scrollTop + body.clientHeight / 2;
    const i = indexAt(c);
    return { i, frac: (c - tops[i]) / Math.max(1, heights[i]), x: (body.scrollLeft + body.clientWidth / 2) / Math.max(1, containerW) };
  }
  function restoreAnchor(a){
    body.scrollTop = Math.max(0, tops[a.i] + a.frac * heights[a.i] - body.clientHeight / 2);
    body.scrollLeft = Math.max(0, a.x * containerW - body.clientWidth / 2);
  }
  function relayout(){
    if(!pdf) return;
    const a = captureAnchor();
    clearWrappers();
    layout();
    restoreAnchor(a);
    update();
  }
  function setZoom(z){
    z = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(z * 100) / 100));
    if(!pdf || z === zoom) return;
    zoom = z;
    relayout();
  }

  // ---------------- error / loading ----------------
  const showError = err => {
    body.setAttribute("aria-busy", "false");
    pagesEl.hidden = true;
    loading.hidden = false;
    const friendly = err?.friendly ? err.message : L.failed;
    loading.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><strong>${escapeHTML(friendly)}</strong>
      ${err?.friendly ? "" : `<small>${L.hint}</small><div class="detail-actions"><button class="btn primary" id="lrRetry" type="button">${L.retry}</button></div>`}`;
    $("#lrRetry")?.addEventListener("click", () => {
      loading.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>${L.loading}</span>`;
      pagesEl.hidden = false;
      load();
    });
    console.warn("Local reader error:", err);
  };

  async function load(){
    try{
      if(!nativeReaderAvailable()) throw Object.assign(new Error(L.androidOnly), { friendly: true });
      const pdfjs = await loadPdfJs();
      if(destroyed) return;
      file = await openNativeFile(source);
      if(destroyed){ file.close(); return; }
      const result = await loadLocalPdf(pdfjs, file);
      if(destroyed){ try{ result.task.destroy(); }catch{} return; }
      pdf = result.pdf; task = result.task; numPages = pdf.numPages;
      const first = await pdf.getPage(1);
      const v = first.getViewport({ scale: 1 });
      try{ first.cleanup?.(); }catch{}
      ratios = new Array(numPages).fill(v.height / v.width);
      slider.max = String(numPages); slider.disabled = false;
      loading.hidden = true;
      body.setAttribute("aria-busy", "false");
      layout();
      body.scrollTop = Math.max(0, tops[clampPage(savedPage) - 1] - GAP);
      update();
    }catch(err){
      if(!destroyed) showError(err);
    }
  }

  // ---------------- events ----------------
  const onScroll = () => {
    if(rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = 0;
      update();
      showPill();
      clearTimeout(saveTimer);
      saveTimer = setTimeout(saveProgress, 500);
    });
  };
  body.addEventListener("scroll", onScroll, { passive: true });

  $("#lrBack").onclick = () => { closeMenu(); saveProgress(); history.back(); };
  moreBtn.onclick = e => { e.stopPropagation(); toggleMenu(); };
  prevBtn.onclick = () => goTo(currentPage - 1, true);
  nextBtn.onclick = () => goTo(currentPage + 1, true);
  slider.addEventListener("input", () => { sliding = true; setCurrent(Number(slider.value)); goTo(Number(slider.value), false); showPill(); });
  slider.addEventListener("change", () => { sliding = false; });

  const openJump = () => {
    closeMenu();
    document.querySelector(".reader-jump-backdrop")?.remove();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop reader-jump-backdrop";
    backdrop.innerHTML = `<section class="modal reader-jump-dialog" role="dialog" aria-modal="true">
      <h2>${L.jump}</h2>
      <p>${L.page} <span>${numPages || "—"}</span> ${L.of}</p>
      <form class="search-box" id="lrJumpForm"><input id="lrJumpInput" type="number" inputmode="numeric" min="1" max="${numPages || 1}" value="${currentPage}" aria-label="${L.jump}"></form>
      <small class="reader-jump-error" id="lrJumpError" hidden>${L.invalid}</small>
      <div class="modal-actions">
        <button class="btn" id="lrJumpCancel" type="button">${L.close}</button>
        <button class="btn primary" id="lrJumpGo" type="button">${L.go}</button>
      </div>
    </section>`;
    document.body.appendChild(backdrop);
    const input = backdrop.querySelector("#lrJumpInput"), error = backdrop.querySelector("#lrJumpError");
    const finish = () => backdrop.remove();
    const jump = () => {
      const n = Number(input.value);
      if(!numPages || !Number.isInteger(n) || n < 1 || n > numPages){ error.hidden = false; input.focus(); return; }
      finish(); goTo(n, false);
    };
    backdrop.querySelector("#lrJumpCancel").onclick = finish;
    backdrop.querySelector("#lrJumpGo").onclick = jump;
    backdrop.querySelector("#lrJumpForm").addEventListener("submit", e => { e.preventDefault(); jump(); });
    backdrop.addEventListener("click", e => { if(e.target === backdrop) finish(); });
    input.addEventListener("input", () => { error.hidden = true; });
    requestAnimationFrame(() => { input.focus(); input.select(); });
  };

  menu.addEventListener("click", e => {
    const item = e.target.closest("[data-action]");
    if(!item) return;
    const action = item.dataset.action;
    closeMenu();
    if(action === "jump") openJump();
    else if(action === "fit") setZoom(1);
    else if(action === "zoomIn") setZoom(zoom + .3);
    else if(action === "zoomOut") setZoom(zoom - .3);
  });
  const onOutside = e => { if(!e.target.closest(".reader-more-wrap")) closeMenu(); };
  document.addEventListener("click", onOutside);

  // Tap toggles controls, double-tap zooms, pinch zooms.
  let touchMoved = false, startX = 0, startY = 0, pinchStart = 0, pinchLast = 0;
  const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  body.addEventListener("click", e => {
    if(e.target.closest("button") || touchMoved){ touchMoved = false; return; }
    controlsHidden = !controlsHidden;
    shellEl.classList.toggle("controls-hidden", controlsHidden);
  });
  body.addEventListener("dblclick", e => {
    if(!pdf || e.target.closest("button")) return;
    setZoom(zoom > 1.05 ? 1 : 2.2);
  });
  body.addEventListener("touchstart", e => {
    if(e.touches.length === 2){
      pinchStart = pinchLast = dist(e.touches); touchMoved = true;
      const r = body.getBoundingClientRect();
      const mx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left + body.scrollLeft;
      const my = (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top + body.scrollTop;
      pagesEl.style.transformOrigin = `${mx}px ${my}px`;
      return;
    }
    startX = e.touches[0].clientX; startY = e.touches[0].clientY; touchMoved = false;
  }, { passive: true });
  body.addEventListener("touchmove", e => {
    if(e.touches.length === 2 && pinchStart){
      pinchLast = dist(e.touches); touchMoved = true;
      const ratio = Math.min(MAX_ZOOM / zoom, Math.max(MIN_ZOOM / zoom, pinchLast / pinchStart));
      pagesEl.style.transform = `scale(${ratio})`;
      return;
    }
    const t = e.touches[0];
    if(Math.abs(t.clientX - startX) > 10 || Math.abs(t.clientY - startY) > 10) touchMoved = true;
  }, { passive: true });
  body.addEventListener("touchend", () => {
    if(!pinchStart) return;
    const ratio = pinchLast / pinchStart;
    pinchStart = pinchLast = 0;
    pagesEl.style.transform = "";
    if(ratio > 1.06 || ratio < .94) setZoom(zoom * ratio);
  }, { passive: true });

  const onResize = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if(pdf && !destroyed) relayout(); }, 200);
  };
  window.addEventListener("resize", onResize, { passive: true });
  const onVisibility = () => { if(document.visibilityState !== "visible") saveProgress(); };
  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("pagehide", saveProgress);

  activeCleanup = () => {
    destroyed = true;
    saveProgress();
    cancelAnimationFrame(rafId);
    clearTimeout(saveTimer); clearTimeout(pillTimer); clearTimeout(resizeTimer);
    window.removeEventListener("resize", onResize);
    window.removeEventListener("pagehide", saveProgress);
    document.removeEventListener("visibilitychange", onVisibility);
    document.removeEventListener("click", onOutside);
    document.querySelector(".reader-jump-backdrop")?.remove();
    for(const w of wrappers.values()){ try{ w.task?.cancel(); }catch{} }
    wrappers.clear();
    try{ task?.destroy?.(); }catch{}
    try{ pdf?.destroy?.(); }catch{}
    try{ file?.close?.(); }catch{}
  };

  load();
}
