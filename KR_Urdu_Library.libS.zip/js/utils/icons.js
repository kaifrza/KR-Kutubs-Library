/* Inline UI icons (no icon-font dependency, so they also work offline in the APK).
   Usage: icon("search") or icon("pdf", "file-glyph"). Styling lives in tab-screens.css (.ico). */

const PATHS = {
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  refresh: '<path d="M4.6 12a7.4 7.4 0 0 1 12.9-5l2 2.1"/><path d="M19.6 4.6v4.8h-4.8"/><path d="M19.4 12a7.4 7.4 0 0 1-12.9 5l-2-2.1"/><path d="M4.4 19.4v-4.8h4.8"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.8c0-.5.4-.8.8-.8h3.4c.4 0 .8.3.8.8V7"/><path d="M6.5 7l.8 11.4c.1.9.8 1.6 1.7 1.6h6c.9 0 1.6-.7 1.7-1.6L17.5 7"/><path d="M10 11v5M14 11v5"/>',
  folder: '<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2.2h7a2 2 0 0 1 2 2V17.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
  phone: '<rect x="7" y="2.8" width="10" height="18.4" rx="2.4"/><path d="M11 18.2h2"/>',
  pdf: '<path d="M7 3.5h6.5l5 5V19a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 19V5A1.5 1.5 0 0 1 7 3.5z"/><path d="M13.5 3.5v5h5"/><path d="M8.7 16.2h6.6M8.7 13h3.4"/>',
  book: '<path d="M12 6.6C10.3 5.3 8 4.7 4.6 4.9c-.3 0-.6.3-.6.6v11.7c0 .3.3.6.6.6 3.3-.2 5.5.4 7.4 1.8 1.9-1.4 4.1-2 7.4-1.8.3 0 .6-.3.6-.6V5.5c0-.3-.3-.6-.6-.6C16 4.7 13.7 5.3 12 6.6z"/><path d="M12 6.8v11.6"/>',
  download: '<path d="M12 4v11"/><path d="M7.5 11.5 12 16l4.5-4.5"/><path d="M5 19.5h14"/>',
  alert: '<path d="M12 4.5 20.5 19h-17z"/><path d="M12 10v4.2"/><path d="M12 16.9h.01"/>',
  arrow: '<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>'
};

export function icon(name, cls = "") {
  return `<svg class="ico${cls ? " " + cls : ""}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${PATHS[name] || ""}</svg>`;
}
