import { loadLibraryData, ensureAllBooksLoaded, searchBooksPage, mergeBooksIntoLibrary, getLibraryCacheInfo, loadClassStats, loadCategoryStats } from "./data/data-loader.js";
import { state } from "./state.js";
import { readRoute, navigate, replaceRoute, ensureAppHistory, isAppHistoryEntry, syncHashNavigation, lockScrollSave } from "./router.js";
import { renderBottomNav } from "./components/bottom-nav.js";
import { bookCard, typesetCover, paletteIndex, HEART } from "./components/book-card.js";
import { coverPalette } from "./utils/palette.js";
import { icon } from "./utils/icons.js";
import { identityFor } from "./utils/identity.js";
import { watchInsets } from "./features/insets.js";
import { watchNativePtr, syncNativePtr } from "./features/native-ptr.js";
import { searchBooks } from "./features/search.js";
import { applyTheme, changeTheme, watchSystemTheme } from "./features/theme.js";
import { getFavorites, toggleFavorite, addHistory, getHistory, clearHistory, getBookProgress, setProgress, clearProgress, setLanguage } from "./utils/storage.js";
import { escapeHTML } from "./utils/helpers.js";
import { coverMarkup, wireCover } from "./utils/cover.js";
import { SUPABASE_URL } from "./data/supabase.js";
import { downloadManager, DOWNLOAD_STATES, nativeDiagnostics, getNativePlugin, BUILD_TAG } from "./features/download-manager.js";
import { loadPdfJs } from "./features/pdfjs-loader.js";
import { renderLocalReader, cleanupLocalReader } from "./features/local-reader.js";
import { openInNativeReader, nativeReaderWanted } from "./features/native-reader.js";
import { getDownloadRecord } from "./features/downloads-store.js";
import { renderLibrary, cleanupLibrary } from "./features/library-screen.js";
import { createReaderNetworkMonitor } from "./features/reader-network-monitor.js";
import { getCachedPdf, hasCachedPdf, getPdfCacheInfo, clearPdfCache } from "./features/pdf-cache.js";

const app = document.querySelector("#app");
let data;
const t = {
  ur: {
    brand:"KR Urdu Library", tagline:"اردو و اسلامی کتب کا ڈیجیٹل کتب خانہ", search:"کتاب، مصنف یا لفظ تلاش کریں",
    classes:"جماعت کے لحاظ سے", featured:"منتخب کتب", recent:"حال ہی میں شامل کتب", continue:"جہاں چھوڑا تھا",
    available:"دستیاب", back:"واپس", read:"پڑھیں", download:"ڈاؤنلوڈ", fav:"پسندیدہ کتب", source:"اصل ماخذ",
    openSource:"اصل ویب سائٹ دیکھیں", report:"مسئلہ رپورٹ کریں", more:"مزید", empty:"ابھی کوئی کتاب موجود نہیں۔",
    clearHistory:"مطالعہ کی تاریخ صاف کریں", clearData:"مقامی ڈیٹا صاف کریں", clearOffline:"محفوظ شدہ کتب صاف کریں", confirmClear:"پسندیدہ، مطالعہ کی تاریخ اور پیش رفت صاف کر دیں؟",
    cleared:"مقامی ڈیٹا صاف کر دیا گیا۔", theme:"ظاہری انداز", language:"زبان", rights:"ذرائع اور حقوق",
    browse:"سب جماعتیں دیکھیں", allBooks:"تمام کتب", catalogue:"تمام کتب", searchResults:"تلاش کے نتائج", noSearch:"کوئی کتاب نہیں ملی",
    noSearchHint:"عنوان، مصنف یا کوئی دوسرا لفظ آزما کر دیکھیں۔", noClassBooks:"اس جماعت میں ابھی کوئی کتاب دستیاب نہیں۔", noCategoryBooks:"اس زمرے میں ابھی کوئی کتاب دستیاب نہیں۔", noFavorites:"ابھی کوئی پسندیدہ کتاب نہیں۔", filterAll:"تمام کتب", filterMatn:"متون", filterSharah:"شروحات", continueAction:"مطالعہ جاری رکھیں", pageOf:"صفحہ",
    reportSoon:"رپورٹ فیچر ابھی دستیاب نہیں ہے۔", related:"ملتی جلتی کتب", relatedHint:"اسی جماعت یا زمرے کی مزید کتب", sourceMissing:"اس کتاب کا PDF ماخذ ابھی دستیاب نہیں ہے۔", favoriteAdded:"کتاب پسندیدہ میں شامل ہوگئی۔", favoriteRemoved:"کتاب پسندیدہ سے ہٹا دی گئی۔",
    historyCleared:"مطالعہ کی تاریخ صاف کر دی گئی۔", dataCleared:"مقامی ڈیٹا صاف کر دیا گیا۔", quickClasses:"جماعتیں", quickCategories:"زمرے",
    quickFavorites:"پسندیدہ", quickHistory:"حالیہ مطالعہ", about:"مختصر تعارف", unavailable:"فی الحال دستیاب نہیں", quickSettings:"فوری ترتیبات", librarySection:"لائبریری", offlineSection:"آف لائن کتب", dataSection:"ڈیٹا اور اسٹوریج", appearanceShort:"ظاہری انداز", languageShort:"زبان", savedBooks:"محفوظ شدہ کتب", storageUsed:"استعمال شدہ جگہ", clearHistoryShort:"مطالعہ کی تاریخ صاف کریں", clearDataShort:"تمام مقامی ڈیٹا صاف کریں", clearOfflineShort:"صاف کریں", sourceRightsShort:"ذرائع اور حقوق", aboutApp:"KR Urdu Library کے بارے میں", systemTheme:"سسٹم", lightTheme:"لائٹ", darkTheme:"ڈارک",
    offline:"آپ آف لائن ہیں؛ محفوظ شدہ کتب دکھائی جا رہی ہیں۔", online:"انٹرنیٹ بحال ہوگیا۔", cached:"محفوظ شدہ ڈیٹا استعمال ہو رہا ہے۔", readerLoading:"کتاب لوڈ ہو رہی ہے…", readerPageError:"صفحہ دکھایا نہیں جا سکا", readerLoadError:"PDF لوڈ نہیں ہو سکی",
    openPdf:"PDF کھولیں", readerSource:"اصل ماخذ کھولیں", previous:"پچھلا صفحہ", next:"اگلا صفحہ", zoomOut:"زوم کم کریں",
    zoomIn:"زوم بڑھائیں", fullscreen:"مکمل اسکرین", hideControls:"کنٹرول چھپائیں", showControls:"کنٹرول دکھائیں", retry:"دوبارہ کوشش کریں", alternateReader:"متبادل ریڈر استعمال کریں", readerViewerHint:"اگر PDF یہاں نظر نہ آئے تو متبادل ریڈر استعمال کریں۔", readerClosed:"مطالعہ بند کر دیا گیا۔", refresh:"تازہ کریں", refreshing:"کتب تازہ کی جا رہی ہیں…", refreshed:"کتب تازہ ہوگئیں۔", refreshFailed:"تازہ کاری ناکام ہوگئی۔"
  },
  en: {
    brand:"KR Urdu Library", tagline:"A Digital Home for Urdu & Islamic Books", search:"Search books, authors or keywords",
    classes:"Browse by Class", featured:"Featured Books", recent:"Recently Added", continue:"Continue Reading",
    available:"Available", back:"Back", read:"Read", download:"Download", fav:"Favorites", source:"Original Source",
    openSource:"View Original Source", report:"Report a Problem", more:"More", empty:"No books found.",
    clearHistory:"Clear reading history", clearData:"Clear local data", clearOffline:"Clear saved offline books", confirmClear:"Clear favorites, reading history and reading progress?",
    cleared:"Local data cleared.", theme:"Appearance", language:"Language", rights:"Sources & Rights",
    browse:"View all classes", allBooks:"All books", catalogue:"All books", searchResults:"Search results", noSearch:"No books found",
    noSearchHint:"Try a different title, author, or keyword.", noClassBooks:"No books are available in this class yet.", noCategoryBooks:"No books are available in this category yet.", noFavorites:"No favorite books yet.", filterAll:"All books", filterMatn:"Matn", filterSharah:"Commentary", continueAction:"Continue reading", pageOf:"Page",
    reportSoon:"Reporting is not available yet.", related:"Related books", relatedHint:"More books from the same class or category", sourceMissing:"A PDF source is not currently available for this book.", favoriteAdded:"Book added to favorites.", favoriteRemoved:"Book removed from favorites.",
    historyCleared:"Reading history cleared.", dataCleared:"Local data cleared.", quickClasses:"Classes", quickCategories:"Categories",
    quickFavorites:"Favorites", quickHistory:"Recent", about:"About this book", unavailable:"Currently unavailable", quickSettings:"Quick settings", librarySection:"Library", offlineSection:"Offline books", dataSection:"Data & storage", appearanceShort:"Appearance", languageShort:"Language", savedBooks:"Saved books", storageUsed:"Storage used", clearHistoryShort:"Clear reading history", clearDataShort:"Clear all local data", clearOfflineShort:"Clear", sourceRightsShort:"Sources & Rights", aboutApp:"About KR Urdu Library", systemTheme:"System", lightTheme:"Light", darkTheme:"Dark",
    offline:"You are offline; showing cached library data.", online:"Internet connection restored.", cached:"Using cached library data.", readerLoading:"Loading book…", readerPageError:"Page could not be rendered", readerLoadError:"Unable to load PDF",
    openPdf:"Open PDF", readerSource:"Open Source", previous:"Previous page", next:"Next page", zoomOut:"Zoom out",
    zoomIn:"Zoom in", fullscreen:"Fullscreen", hideControls:"Hide controls", showControls:"Show controls", retry:"Retry", alternateReader:"Use alternate reader", readerViewerHint:"If the PDF does not appear here, use the alternate reader.", readerClosed:"Reading closed.", refresh:"Refresh", refreshing:"Refreshing library…", refreshed:"Library refreshed.", refreshFailed:"Refresh failed."
  }
};

const langName = (c, lang) => lang === "ur" ? c.name : (c.nameEn || c.name);
function currentLang(){ return state.language; }
function setDirection(){
  const rtl = currentLang() === "ur";
  document.documentElement.lang = rtl ? "ur" : "en";
  document.documentElement.dir = rtl ? "rtl" : "ltr";
}
function validExternalUrl(url){ try { const u = new URL(url, location.href); return ["http:","https:"].includes(u.protocol); } catch { return false; } }
function openExternal(url){ if(validExternalUrl(url)) window.open(url, "_blank", "noopener,noreferrer"); }
function archiveIdentifierFromUrl(url){
  try{
    const u=new URL(url,location.href);
    if(!/(^|\.)archive\.org$/i.test(u.hostname))return null;
    const parts=u.pathname.split('/').filter(Boolean);
    for(const marker of ['download','details','embed']){
      const i=parts.indexOf(marker);
      if(i>=0&&parts[i+1])return decodeURIComponent(parts[i+1]);
    }
  }catch{}
  return null;
}

function readerSourceForBook(book){
  const type=String(book?.pdfSourceType||'').toLowerCase();
  const driveId=String(book?.driveFileId||'').trim();
  if(type==='drive' || driveId){
    if(driveId)return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/preview`};
  }
  // Be resilient to older records where a Drive /file/{id}/view URL was
  // stored in pdfUrl without a separate drive_file_id. The canonical reader
  // still remains Drive preview; this does not create a second source.
  for(const candidate of [book?.source?.pageUrl,book?.pdfUrl]){
    try{
      const u=new URL(candidate,location.href);
      const m=u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i);
      if(/(^|\.)drive\.google\.com$/i.test(u.hostname) && m?.[1]){
        return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(m[1])}/preview`};
      }
    }catch{}

    const identifier=archiveIdentifierFromUrl(candidate);
    if(identifier)return {kind:'archive',url:`https://archive.org/embed/${encodeURIComponent(identifier)}`};
  }
  if(validExternalUrl(book?.pdfUrl))return {kind:'external',url:book.pdfUrl};
  return null;
}
// PDF.js fallback fetches through the gateway because third-party hosts such as Archive.org and
// Google Drive are not expected to expose the CORS contract needed by PDF.js. The primary reader
// is source-specific: Archive.org uses its /embed/{identifier} viewer and public Drive books use
// the Drive /file/{id}/preview viewer. Only the fallback path uses the gateway + PDF.js.
const PDF_GATEWAY_CLIENT = "KR-URDU-LIBRARY-PDF-V1";
function pdfGatewayUrl(bookId){
  return `${SUPABASE_URL}/functions/v1/pdf-gateway?book_id=${encodeURIComponent(bookId)}&client=${PDF_GATEWAY_CLIENT}`;
}

function formatDownloadBytes(bytes){
  if(!Number.isFinite(bytes) || bytes < 0) return "—";
  const units=["B","KB","MB","GB"];
  let n=bytes, i=0;
  while(n>=1024 && i<units.length-1){ n/=1024; i++; }
  const digits=i===0?0:(n>=100?0:n>=10?1:2);
  return `${n.toFixed(digits)} ${units[i]}`;
}

function formatDownloadSpeed(bytesPerSecond){
  return Number.isFinite(bytesPerSecond) && bytesPerSecond > 0 ? `${formatDownloadBytes(bytesPerSecond)}/s` : "";
}

function formatDownloadEta(seconds){
  if(!Number.isFinite(seconds) || seconds < 0) return "";
  const total=Math.ceil(seconds);
  if(total < 60) return `${total}s`;
  const minutes=Math.floor(total/60);
  const secs=total%60;
  if(minutes < 60) return `${minutes}m ${secs}s`;
  const hours=Math.floor(minutes/60);
  return `${hours}h ${minutes%60}m`;
}

function ensureDownloadStatus(){
  let region=document.querySelector(".download-status-region");
  if(!region){
    region=document.createElement("div");
    region.className="download-status-region";
    region.setAttribute("aria-live","polite");
    region.setAttribute("aria-atomic","false");
    document.body.appendChild(region);
  }
  return region;
}

function updateDownloadStatus(payload){
  const region=ensureDownloadStatus();
  if(payload.state===DOWNLOAD_STATES.IDLE || !payload.bookId) return;

  const key=String(payload.bookId).replace(/[^A-Za-z0-9_-]/g,"_");
  let card=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
  if(!card){
    card=document.createElement("section");
    card.className="download-status";
    card.dataset.downloadId=String(payload.bookId);
    region.appendChild(card);
  }

  const title=payload.filename ? payload.filename.replace(/\.pdf$/i,"") : (currentLang()==="ur" ? "کتاب" : "Book");
  const ur=currentLang()==="ur";
  let statusText=ur ? "ڈاؤن لوڈ ہو رہی ہے…" : "Downloading…";
  if(payload.state===DOWNLOAD_STATES.PREPARING) statusText=ur ? "ڈاؤن لوڈ تیار ہو رہا ہے…" : "Preparing download…";
  if(payload.state===DOWNLOAD_STATES.COMPLETING) statusText=ur ? "فائل تیار ہو رہی ہے…" : "Finishing…";
  if(payload.state===DOWNLOAD_STATES.CANCELLING) statusText=ur ? "ڈاؤن لوڈ منسوخ ہو رہا ہے…" : "Cancelling download…";
  if(payload.state===DOWNLOAD_STATES.HANDING_OFF) statusText=ur ? "فائل براؤزر کے حوالے کی جا رہی ہے…" : "Handing download to browser…";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF) statusText=ur ? "ڈاؤن لوڈ براؤزر کے حوالے ہوگیا ✓" : "Download handed to browser ✓";
  if(payload.state===DOWNLOAD_STATES.COMPLETED) statusText=ur ? "ڈاؤن لوڈ مکمل ہوگیا ✓" : "Download complete ✓";
  if(payload.state===DOWNLOAD_STATES.FAILED) statusText=ur ? "ڈاؤن لوڈ ناکام ہوگیا" : "Download failed";
  if(payload.state===DOWNLOAD_STATES.CANCELLED) statusText=ur ? "ڈاؤن لوڈ منسوخ ہوگیا" : "Download cancelled";

  const percent=Number.isFinite(payload.percentage) ? Math.max(0,Math.min(100,payload.percentage)) : null;
  const hasTotal=Number.isFinite(payload.totalBytes) && payload.totalBytes>0;
  let bytesLine;
  if(hasTotal) bytesLine=formatDownloadBytes(payload.downloadedBytes||0)+" / "+formatDownloadBytes(payload.totalBytes);
  else if(Number.isFinite(payload.downloadedBytes)) bytesLine=formatDownloadBytes(payload.downloadedBytes)+" · "+(ur ? "کل سائز معلوم نہیں" : "size unknown");
  else bytesLine=ur ? "سائز معلوم کیا جا رہا ہے" : "Checking file size…";

  const progressLabel=percent===null ? "" : percent.toFixed(percent>=10 ? 0 : 1)+"%";
  const speed=formatDownloadSpeed(payload.speedBytesPerSecond);
  const eta=formatDownloadEta(payload.etaSeconds);
  let details=speed;
  if(eta) details+=(details ? " · " : "")+(ur ? "باقی " : "left ")+eta;
  if(payload.state===DOWNLOAD_STATES.FAILED && payload.errorMessage) details=payload.errorMessage;
  if(payload.state===DOWNLOAD_STATES.CANCELLED) details=ur ? "آپ دوبارہ کوشش کر سکتے ہیں۔" : "You can retry this download.";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF) details=(ur ? "براؤزر اب فائل محفوظ کرے گا۔" : "Your browser is handling the file save.")+" ["+(payload.nativeFallbackReason ? payload.nativeFallbackReason+" | " : "")+nativeDiagnostics()+"]";
  if(payload.state===DOWNLOAD_STATES.COMPLETED && payload.mode==="native") details=ur ? "فائل ڈاؤن لوڈز فولڈر میں محفوظ ہوگئی۔" : "Saved to your Downloads folder.";

  const canCancel=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING].includes(payload.state);
  const cancelLabel=ur ? "ڈاؤن لوڈ منسوخ کریں" : "Cancel download";
  const cancelMarkup=canCancel ? '<button type="button" class="download-status-cancel" aria-label="'+escapeHTML(cancelLabel)+'"><i class="fa-solid fa-xmark"></i></button>' : "";
  const canRetry=[DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state) && downloadManager.canRetry(payload.bookId);
  const retryMarkup=canRetry ? '<button type="button" class="download-status-retry">'+escapeHTML(ur ? "دوبارہ کوشش کریں" : "Retry")+'</button>' : "";
  let progressMarkup;
  if(percent!==null) progressMarkup='<div class="download-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+percent.toFixed(1)+'"><span style="width:'+percent+'%"></span></div>';
  else progressMarkup='<div class="download-progress-track indeterminate"><span></span></div>';
  const detailsMarkup=details ? '<div class="download-status-sub">'+escapeHTML(details)+'</div>' : "";
  const cancellingClass=payload.state===DOWNLOAD_STATES.CANCELLING ? " is-cancelling" : "";
  const busyAttr=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING,DOWNLOAD_STATES.CANCELLING,DOWNLOAD_STATES.HANDING_OFF].includes(payload.state) ? ' aria-busy="true"' : "";
  card.className="download-status"+cancellingClass;
  card.setAttribute("role","status");
  if(busyAttr) card.setAttribute("aria-busy","true"); else card.removeAttribute("aria-busy");
  card.innerHTML='<div class="download-status-head"><div class="download-status-title"><i class="fa-solid fa-download"></i><span>'+escapeHTML(statusText)+'</span></div>'+cancelMarkup+'</div>'
    +'<div class="download-status-book" title="'+escapeHTML(title)+'">'+escapeHTML(title)+'</div>'
    +progressMarkup
    +'<div class="download-status-meta"><span>'+escapeHTML(bytesLine)+'</span><strong>'+escapeHTML(progressLabel)+'</strong></div>'
    +detailsMarkup+retryMarkup;

  const cancel=card.querySelector(".download-status-cancel");
  if(cancel) cancel.onclick=()=>downloadManager.cancel(payload.bookId);
  const retry=card.querySelector(".download-status-retry");
  if(retry){ retry.onclick=async()=>{ retry.disabled=true; try{ await downloadManager.retry(payload.bookId); }catch(err){ console.error("KR Urdu Library PDF retry failed",err); } }; }

  if([DOWNLOAD_STATES.COMPLETED,DOWNLOAD_STATES.HANDED_OFF,DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state)){
    const timerKey="timer_"+key;
    clearTimeout(updateDownloadStatus[timerKey]);
    updateDownloadStatus[timerKey]=setTimeout(()=>{
      const target=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
      if(target) target.remove();
      if(!region.children.length) region.remove();
    }, payload.state===DOWNLOAD_STATES.COMPLETED ? 3200 : (payload.state===DOWNLOAD_STATES.HANDED_OFF ? 20000 : 4500));
  }
}
downloadManager.subscribe(updateDownloadStatus);

function showToast(message){
  let region=document.querySelector(".toast-region");
  if(!region){ region=document.createElement("div"); region.className="toast-region"; region.setAttribute("aria-live","polite"); region.setAttribute("aria-atomic","true"); document.body.appendChild(region); }
  region.innerHTML=`<div class="toast" role="status">${escapeHTML(message)}</div>`;
  clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>region.remove(),2600);
}

function confirmDialog(title, message, confirmLabel, danger=false){
  return new Promise(resolve=>{
    const backdrop=document.createElement("div"); backdrop.className="modal-backdrop";
    backdrop.innerHTML=`<section class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><h2 id="modalTitle">${escapeHTML(title)}</h2><p>${escapeHTML(message)}</p><div class="modal-actions"><button class="btn" id="modalCancel">${currentLang()==="ur"?"منسوخ":"Cancel"}</button><button class="btn ${danger?"danger":"primary"}" id="modalConfirm">${escapeHTML(confirmLabel)}</button></div></section>`;
    document.body.appendChild(backdrop);
    const onKey=e=>{if(e.key==="Escape")finish(false);};
    const finish=value=>{document.removeEventListener("keydown",onKey);backdrop.remove();resolve(value);};
    backdrop.querySelector("#modalCancel").onclick=()=>finish(false);
    backdrop.querySelector("#modalConfirm").onclick=()=>finish(true);
    backdrop.addEventListener("click",e=>{if(e.target===backdrop)finish(false);});
    document.addEventListener("keydown",onKey);
    backdrop.querySelector("#modalConfirm").focus();
  });
}

function goBackInApp() {
  // Always keep Back inside the library when possible. A direct/deep link is
  // seeded with Home by ensureAppHistory(), so history.back() is safe here.
  if (isAppHistoryEntry() && history.length > 1) history.back();
  else navigate("home", {}, { replace: true });
}

// ---- Android hardware Back ------------------------------------------------
// MainActivity asks the web layer what to do on every Back press by calling
// window.__krBack(). Order: close the topmost overlay -> go to the previous
// screen -> (tab screens) go Home -> on Home, press twice to exit.
// Returns "handled" (stay in app) or "exit" (native may close the app).
const TAB_ROOTS = new Set(["classes","categories","downloads","more","catalogue","favorites","search"]);
let lastExitTap = 0;
window.__krBack = function(){
  try{
    const lrWrap = document.querySelector(".lr-sheet-wrap.open:not([hidden])");
    if(lrWrap){ history.back(); return "handled"; }          // history-integrated sheet
    const modal = document.querySelector(".modal-backdrop");
    if(modal){ modal.click(); if(modal.isConnected) modal.remove(); return "handled"; }
    const info = document.querySelector(".more-info-dialog");
    if(info){ info.remove(); return "handled"; }
    const menu = document.querySelector("#readerMoreMenu:not([hidden])");
    if(menu){ document.querySelector("#more")?.click(); if(!menu.hidden) menu.hidden = true; return "handled"; }
    if(document.querySelector(".class-search-panel.is-open")){ history.back(); return "handled"; }
    const { route } = readRoute();
    if(route !== "home"){
      if(TAB_ROOTS.has(route)) navigate("home", {}, { replace: true });
      else goBackInApp();
      return "handled";
    }
    const now = Date.now();
    if(now - lastExitTap < 2000) return "exit";
    lastExitTap = now;
    showToast(currentLang()==="ur" ? "باہر نکلنے کے لیے دوبارہ بیک دبائیں" : "Press back again to exit");
    return "handled";
  }catch(err){ console.error("back handler", err); return "exit"; }
};

let networkStatusTimer = null;
function updateNetworkStatus(mode = null) {
  const offline = mode === "offline" || (mode === null && typeof navigator !== "undefined" && navigator.onLine === false);
  const nodes = document.querySelectorAll(".network-status");
  nodes.forEach(node => {
    node.dataset.state = offline ? "offline" : "online";
    node.hidden = !offline;
    node.textContent = offline ? t[currentLang()].offline : "";
  });
}

function announceNetworkStatus(mode) {
  if (mode === "offline") {
    showToast(t[currentLang()].offline);
    updateNetworkStatus("offline");
    return;
  }
  updateNetworkStatus("online");
  if (networkStatusTimer) clearTimeout(networkStatusTimer);
  const message = t[currentLang()].online;
  showToast(message);
  networkStatusTimer = window.setTimeout(() => updateNetworkStatus(null), 2600);
}

function shell(title, content, active){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const top = document.createElement("header"); top.className = `topbar ${state.route === "home" ? "topbar-home" : ""} ${(state.route === "reader" || state.route === "local") ? "topbar-reader" : ""}`;
  top.innerHTML = `<a class="brand" href="#home" aria-label="${escapeHTML(t[lang].brand)}"><span class="brand-mark">KR</span><span class="brand-copy"><span class="brand-name">${escapeHTML(t[lang].brand)}</span><span class="brand-context">${title}</span></span></a>
    <div class="topbar-actions"><span class="network-status" data-state="online" hidden role="status" aria-live="polite"></span>${state.route !== "reader" ? `<button class="icon-btn" id="refreshBtn" type="button" aria-label="${escapeHTML(t[lang].refresh)}" title="${escapeHTML(t[lang].refresh)}"><i class="fa-solid fa-arrows-rotate"></i></button>` : ""}<button class="icon-btn" id="favoritesBtn" type="button" aria-label="${escapeHTML(lang==="ur"?"پسندیدہ":"Favorites")}" title="${escapeHTML(lang==="ur"?"پسندیدہ":"Favorites")}"><i class="fa-solid fa-heart"></i></button></div>`;
  if(state.route !== "reader" && state.route !== "local"){ const scrim = document.createElement("div"); scrim.className = "top-scrim"; scrim.setAttribute("aria-hidden", "true"); app.appendChild(scrim); }
  app.appendChild(top);
  updateNetworkStatus(null);
  const page = document.createElement("main"); page.className = "page"; page.innerHTML = content; app.appendChild(page);
  if(state.route !== "reader") app.appendChild(renderBottomNav(active, lang));
  const favoritesBtn = top.querySelector("#favoritesBtn");
  if(favoritesBtn) favoritesBtn.onclick = () => navigate("favorites");
  const refreshBtn = top.querySelector("#refreshBtn");
  if(refreshBtn) refreshBtn.onclick = () => refreshLibrary({ source: "button" });
  return page;
}

function detailShell(title, content){
  const lang=currentLang();
  app.innerHTML="";
  const top=document.createElement("header"); top.className="detail-top";
  top.innerHTML=`<button class="icon-btn detail-back" id="bookBack" type="button" aria-label="${escapeHTML(t[lang].back)}"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7"/></svg></button><span class="detail-top-title" aria-hidden="true">${escapeHTML(title)}</span><span class="detail-top-end"><span class="network-status" data-state="online" hidden role="status" aria-live="polite"></span></span>`;
  app.appendChild(top);
  updateNetworkStatus(null);
  const page=document.createElement("main"); page.className="page"; page.innerHTML=content; app.appendChild(page);
  return page;
}

let refreshInFlight = null;

function showRefreshIndicator(stateName){
  let indicator = document.querySelector(".pull-refresh-indicator");
  if(!indicator){
    indicator = document.createElement("div");
    indicator.className = "pull-refresh-indicator";
    indicator.setAttribute("role", "status");
    indicator.setAttribute("aria-live", "polite");
    document.body.appendChild(indicator);
  }
  const lang=currentLang(), L=t[lang];
  const labels={pull:lang==="ur"?"تازہ کرنے کے لیے نیچے کھینچیں":"Pull to refresh",release:lang==="ur"?"تازہ کرنے کے لیے چھوڑ دیں":"Release to refresh",refreshing:L.refreshing,done:L.refreshed,error:L.refreshFailed};
  indicator.dataset.state=stateName;
  if(stateName!=="pull"&&stateName!=="release"){ indicator.style.transition=""; indicator.style.transform=""; indicator.style.opacity=""; }
  indicator.innerHTML = `<span class="pull-refresh-icon" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span>${escapeHTML(labels[stateName] || labels.pull)}</span>`;
  if(stateName === "done" || stateName === "error"){
    window.setTimeout(()=>{ if(indicator.dataset.state===stateName) indicator.remove(); }, 1300);
  }
  return indicator;
}

async function refreshLibrary({source="pull"}={}){
  if(refreshInFlight) return refreshInFlight;
  if((state.route === "reader" || state.route === "local")) return;
  const startedAt=Date.now();
  const button=document.querySelector("#refreshBtn");
  refreshInFlight=(async()=>{
    if(button){ button.disabled=true; button.classList.add("is-spinning"); button.setAttribute("aria-busy","true"); }
    const quiet = source === "native";
    if(!quiet) showRefreshIndicator("refreshing");
    try{
      const next=await loadLibraryData({force:true});
      data=next;
      state.dataReady=true;
      updateNetworkStatus(null);
      lastRenderedRoute="";
      await renderRouteOnce();
      const elapsed=Date.now()-startedAt;
      if(elapsed<500) await new Promise(r=>setTimeout(r,500-elapsed));
      if(!quiet) showRefreshIndicator("done");
      return {ok:true};
    }catch(error){
      console.error("KR Urdu Library refresh failed",error);
      if(!quiet) showRefreshIndicator("error");
      showToast(t[currentLang()].refreshFailed);
      return {ok:false,error};
    }finally{
      const currentButton=document.querySelector("#refreshBtn");
      if(currentButton){ currentButton.disabled=false; currentButton.classList.remove("is-spinning"); currentButton.removeAttribute("aria-busy"); }
      refreshInFlight=null;
    }
  })();
  return refreshInFlight;
}

window.__krNativeRefresh = () => { Promise.resolve(refreshLibrary({source:"native"})).finally(()=>{ try{ getNativePlugin()?.refreshDone?.(); }catch{} }); };

function installPullToRefresh(){
  if(window.__krPullRefreshInstalled) return;
  window.__krPullRefreshInstalled=true;
  // Deliberate-pull rules: the gesture only counts if it starts with the page exactly at the
  // top, is a clearly vertical drag, is pulled well past a threshold AND is still held there
  // when the finger lifts. Quick flicks, scrolls inside lists/carousels, taps and drags that
  // begin while a fling is still settling never refresh.
  const PTR_ROUTES = new Set(["home","catalogue","classes","class","categories","category","favorites","more","downloads"]);
  const SLOP = 14;            // px of finger travel before the gesture is "a pull"
  const RESIST = 0.5;         // finger px -> indicator px
  const TRIGGER = 80;         // indicator px needed (= ~160px of finger travel)
  const MAX = 120;
  const COOLDOWN_MS = 4000;
  let t0 = 0, startY = 0, startX = 0, pull = 0, active = false, pulling = false, lastScrollAt = 0, lastRefreshAt = 0;
  window.addEventListener("scroll",()=>{ lastScrollAt = Date.now(); },{passive:true});

  const insideScroller = el => {
    for(let n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement){
      if(!(n instanceof HTMLElement)) continue;
      const cs = getComputedStyle(n);
      if((/(auto|scroll)/.test(cs.overflowY) && n.scrollHeight > n.clientHeight + 1) ||
         (/(auto|scroll)/.test(cs.overflowX) && n.scrollWidth > n.clientWidth + 1)) return true;
    }
    return false;
  };
  const blocked = () => !PTR_ROUTES.has(state.route) || refreshInFlight || Date.now() - lastRefreshAt < COOLDOWN_MS ||
    document.querySelector(".modal-backdrop, .more-info-dialog, .class-search-panel.is-open, .lr-sheet-wrap.open");
  const reset = (keepIndicator=false) => {
    active = false; pulling = false; pull = 0;
    const ind = document.querySelector(".pull-refresh-indicator");
    if(ind && !keepIndicator && ind.dataset.state !== "refreshing") ind.remove();
  };

  document.addEventListener("touchstart",e=>{
    active = false; pulling = false; pull = 0;
    if(window.__krNativePtr || e.touches.length !== 1 || blocked()) return;
    if(window.scrollY > 0 || Date.now() - lastScrollAt < 160) return;   // must be settled at the very top
    if(insideScroller(e.target)) return;
    startY = e.touches[0].clientY; startX = e.touches[0].clientX; t0 = Date.now(); active = true;
  },{passive:true});

  document.addEventListener("touchmove",e=>{
    if(!active) return;
    if(e.touches.length !== 1 || window.scrollY > 0){ reset(); return; }
    const dy = e.touches[0].clientY - startY, dx = e.touches[0].clientX - startX;
    if(!pulling){
      if(dy < 0 || Math.abs(dx) > Math.abs(dy)){ if(Math.abs(dx) > SLOP || dy < -SLOP) reset(); return; }  // scrolling down the page or sideways
      if(dy < SLOP || Math.abs(dx) > dy * 0.6) return;                                                      // not clearly vertical yet
      pulling = true;
    }
    if(dy <= 0){ reset(); return; }
    pull = Math.min(MAX, (dy - SLOP) * RESIST);
    const ind = showRefreshIndicator(pull >= TRIGGER ? "release" : "pull");
    ind.style.transition = "none";
    ind.style.transform = `translate(-50%, ${Math.min(58, pull * 0.75)}px)`;
    ind.style.opacity = String(Math.min(1, pull / 28));
    const icon = ind.querySelector(".pull-refresh-icon i");
    if(icon) icon.style.transform = `rotate(${Math.round(pull / TRIGGER * 270)}deg)`;
    if(e.cancelable) e.preventDefault();
  },{passive:false});

  const finish = () => {
    if(!active) return;
    const go = pulling && pull >= TRIGGER && Date.now() - t0 >= 280;   // a fast flick is not a pull
    reset(go);
    if(go){ lastRefreshAt = Date.now(); refreshLibrary({source:"pull"}); }
  };
  document.addEventListener("touchend",finish,{passive:true});
  document.addEventListener("touchcancel",()=>reset(),{passive:true});
}

// State for the search-results screen (infinite loading of further result pages).
let searchObserver = null;
let searchLoadInFlight = null;
// Results of the last search, so coming back from a book shows the same list again.
// (The data layer remembers a finished query and would otherwise return nothing the second time.)
let searchSession = { q: "", books: [], done: false };
let searchRequestToken = 0;

function leadCard(book, lang){
  const ur=lang==="ur", L=t[lang];
  const title=ur?book.title:(book.titleEn||book.title);
  const progress=getBookProgress(book.id);
  const percent=Math.max(0,Math.min(100,Math.round(Number(progress?.percent)||0)));
  const pageNo=Number(progress?.page)||0, total=Number(progress?.totalPages)||Number(book.pages)||0;
  const label=(pageNo&&total)?(ur?`صفحہ ${pageNo} از ${total}`:`Page ${pageNo} of ${total}`)
    :(percent?(ur?`${percent}% مکمل`:`${percent}% complete`):(ur?"مطالعہ شروع کریں":"Ready to start"));
  const el=document.createElement("article");
  el.className=`home-lead tc-${paletteIndex(book.id)}`; el.id="homeLead"; el.tabIndex=0; el.setAttribute("role","link");
  el.setAttribute("aria-label",(ur?"مطالعہ جاری رکھیں: ":"Continue reading: ")+title);
  el.innerHTML=`<div class="cover is-mini lead-cover">${typesetCover(title,book.author,book.id)}${book.cover?coverMarkup(escapeHTML(book.cover),escapeHTML(title)):""}</div>
    <div class="lead-copy"><span class="lead-kicker">${escapeHTML(L.continue)}</span><h2 class="lead-title">${escapeHTML(title)}</h2><p class="lead-author">${escapeHTML(book.author||"")}</p>
    <div class="lead-progress"><div class="lead-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}"><span style="width:${percent}%"></span></div><small>${escapeHTML(label)}</small></div>
    <button class="cta-btn" type="button">${escapeHTML(L.continueAction)}<i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></button></div>`;
  const coverBox=el.querySelector(".lead-cover");
  wireCover(coverBox);
  const img=coverBox.querySelector("img");
  if(img) img.addEventListener("load",()=>{
    const pal=coverPalette(img);
    if(pal) for(const [k,v] of Object.entries(pal)) el.style.setProperty(k,v);
  },{once:true});
  const open=()=>openReader(book.id);
  el.addEventListener("click",open);
  el.addEventListener("keydown",e=>{ if((e.key==="Enter"||e.key===" ")&&e.target===el){ e.preventDefault(); open(); } });
  return el;
}

function welcomeCard(lang){
  const ur=lang==="ur", L=t[lang];
  const el=document.createElement("section"); el.className="home-welcome"; el.id="homeLead";
  el.innerHTML=`<div class="welcome-copy"><span class="lead-kicker">${ur?"کتب کا مطالعہ":"Your library"}</span><h2 class="welcome-title">${escapeHTML(L.tagline)}</h2>
    <button class="cta-btn" id="welcomeBrowse" type="button">${ur?"جماعتیں دیکھیں":"Browse classes"}<i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></button></div>
    <svg class="welcome-art" viewBox="0 0 120 120" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="1.4"><rect x="22" y="22" width="76" height="76" rx="6"/><rect x="22" y="22" width="76" height="76" rx="6" transform="rotate(45 60 60)"/><circle cx="60" cy="60" r="25"/><circle cx="60" cy="60" r="10"/></g></svg>`;
  el.querySelector("#welcomeBrowse").onclick=()=>navigate("classes");
  return el;
}

function renderHome(){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  const recent=(data.recentBooks || data.books);
  const findBook=id=>data.byId?.get(id) || data.books.find(b=>b.id===id);
  const historyBooks=getHistory().map(findBook).filter(Boolean).slice(0,6);
  const favoriteBooks=getFavorites().map(findBook).filter(Boolean).slice(0,12);
  const earlier=historyBooks.slice(1);
  const seeAll=ur?"سب دیکھیں":"See all";
  const head=(id,title,sub,href)=>`<div class="section-head"><div><h2 class="section-title">${title}</h2>${sub?`<p class="section-subtitle">${sub}</p>`:""}</div>${href?`<a class="section-link" href="${href}">${seeAll}</a>`:""}</div>`;
  const chip=(id,icon,text)=>`<button class="home-chip" id="${id}" type="button"><i class="fa-solid ${icon}"></i><span>${text}</span></button>`;
  const page=shell(ur?"السلام علیکم":"Assalamu alaikum", `
    <form class="search-pill" id="searchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="searchInput" type="search" autocomplete="off" enterkeyhint="search" aria-label="${L.search}" placeholder="${L.search}"><button class="search-pill-clear" id="searchClear" type="button" hidden aria-label="${ur?"صاف کریں":"Clear"}"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18"/></svg></button></form>
    <div class="home-chips" aria-label="${ur?"فوری رسائی":"Quick access"}">${chip("quickClasses","fa-book-open",L.quickClasses)}${chip("quickCategories","fa-layer-group",L.quickCategories)}${chip("quickFavorites","fa-heart",L.quickFavorites)}${chip("quickHistory","fa-clock-rotate-left",L.quickHistory)}</div>
    <div id="homeLeadSlot"></div>
    ${earlier.length?`<section class="section home-shelf-section" id="earlierSection">${head("earlier",ur?"حال ہی میں کھولی گئی":"Recently opened","",null)}<div class="shelf" id="earlierShelf"></div></section>`:""}
    ${recent.length?`<section class="section home-shelf-section" id="recentSection">${head("recent",L.recent,"","#catalogue")}<div class="shelf" id="recentShelf"></div></section>`:`<section class="section home-shelf-section" id="recentSection">${head("recent",L.recent,"",null)}<div class="hp-empty">${icon("book")}<strong>${ur?"کتابوں کی فہرست ابھی دستیاب نہیں":"The book list isn't available yet"}</strong><p>${ur?"انٹرنیٹ چیک کر کے فہرست دوبارہ لوڈ کریں۔":"Check your connection and load the list again."}</p><button class="cta-btn" id="homeRetry" type="button">${icon("refresh")}${ur?"دوبارہ لوڈ کریں":"Reload list"}</button></div></section>`}
    ${favoriteBooks.length?`<section class="section home-shelf-section" id="favSection">${head("fav",ur?"پسندیدہ کتب":"Your favorites","","#favorites")}<div class="shelf" id="favShelf"></div></section>`:""}`,"home");
  page.classList.add("home-page");
  if(state.prevRoute!=="home") page.classList.add("hp-animate");

  page.querySelector("#homeLeadSlot").appendChild(historyBooks.length?leadCard(historyBooks[0],lang):welcomeCard(lang));

  const fillShelf=(selector,books,href)=>{
    const target=page.querySelector(selector); if(!target) return;
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,id)=>a==="book"?navigate("book",{id}):null)));
    if(href){
      const more=document.createElement("a"); more.className="shelf-more"; more.href=href;
      more.innerHTML=`<span class="shelf-more-ring"><i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></span><span>${seeAll}</span>`;
      target.appendChild(more);
    }
  };
  fillShelf("#earlierShelf",earlier,null);
  fillShelf("#recentShelf",recent.slice(0,10),"#catalogue");
  fillShelf("#favShelf",favoriteBooks,"#favorites");

  // Keeps class statistics warm for the Classes screen (Home no longer shows the class grid).
  loadClassStats().catch(error=>console.warn('KR Urdu Library class stats unavailable.', error));

  const searchInput=page.querySelector("#searchInput"), searchClear=page.querySelector("#searchClear");
  // Tapping the search bar opens the search screen (recent searches + shortcuts); typing happens there.
  searchInput.addEventListener("focus",()=>{ searchInput.blur(); navigate("search",{q:""}); });
  searchInput.addEventListener("input",()=>{searchClear.hidden=!searchInput.value;});
  searchClear.onclick=()=>{searchInput.value="";searchClear.hidden=true;searchInput.focus();};
  page.querySelector("#homeRetry")?.addEventListener("click",()=>refreshLibrary({source:"button"}));
  page.querySelector("#searchForm").onsubmit=e=>{e.preventDefault();const q=page.querySelector("#searchInput").value.trim();if(q)navigate("search",{q});};
  page.querySelector("#quickClasses").onclick=()=>navigate("classes");
  page.querySelector("#quickCategories").onclick=()=>navigate("categories");
  page.querySelector("#quickFavorites").onclick=()=>navigate("favorites");
  page.querySelector("#quickHistory").onclick=()=>{
    const target=page.querySelector("#earlierSection")||(historyBooks.length?page.querySelector("#homeLead"):null);
    if(target) target.scrollIntoView({behavior:"smooth",block:"center"});
    else showToast(ur?"ابھی مطالعہ کی تاریخ خالی ہے۔":"No recent reading yet.");
  };
}

function classShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="classBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="classSearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="classSearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="classSearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="classSearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="classSearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="classSearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

function categoryShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar category-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="categoryBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="categorySearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="categorySearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="categorySearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="categorySearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="categorySearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="categorySearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page category-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

// One screen for a single class and for "All books" (all=true), so both look and behave exactly the same.
function renderClass(id, all=false){
  const lang=currentLang(), L=t[lang], c=all?null:data.classes.find(x=>x.id===id); if(!all && !c)return navigate("classes");
  const title=all?L.catalogue:langName(c,lang), routeName=all?"catalogue":"class";
  const baseParams=()=>all?{}:{id};
  const classBooks=all?(data.books||[]):(data.byClass?.get(id) || data.books.filter(b=>(b.classIds||[b.classId]).includes(id)));
  const routeParams=readRoute().params;
  const initialType=routeParams.type==="matn" || routeParams.type==="sharah" ? routeParams.type : null;
  const initialQuery=String(routeParams.q||"");
  const {page,header}=classShell(title, `<div class="class-intro"><div><h1 class="section-title">${escapeHTML(title)}</h1><div class="muted" id="classBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-book-open"></i></div></div><div class="actions discovery-filters" role="group" aria-label="${lang==="ur"?"کتب کی قسم":"Book type"}"><button class="btn active" id="all" aria-pressed="true"><i class="fa-solid fa-layer-group"></i> ${L.filterAll}</button><button class="btn" id="matn" aria-pressed="false"><i class="fa-solid fa-book-open"></i> ${L.filterMatn}</button><button class="btn" id="sharah" aria-pressed="false"><i class="fa-solid fa-book"></i> ${L.filterSharah}</button></div><section class="section class-books-section"><div class="section-head"><h2 class="section-title" id="bookHeading">${L.filterAll}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const filters=[...page.querySelectorAll(".discovery-filters .btn")];
  const searchInput=header.querySelector("#classSearchInput");
  const searchPanel=header.querySelector("#classSearchPanel");
  const searchToggle=header.querySelector("#classSearchToggle");
  const searchClear=header.querySelector("#classSearchClear");
  let searchTimer=0;
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams=baseParams(); if(type)nextParams.type=type;
      replaceRoute(routeName,nextParams);
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open")) return;
    if(!history.state?.classSearchOpen){
      history.pushState({...history.state,classSearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true}); searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.classSearchOpen);
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams=baseParams(); if(type)nextParams.type=type;
      replaceRoute(routeName,nextParams);
    }
    if(hadSearchHistory && history.length>1) history.back();
    else closeSearchPanel();
  };
  window.__krClassSearchClose = closeSearchPanel;
  const filtersType=()=>readRoute().params.type||initialType;
  const render=(type=initialType,{updateUrl=true,query=searchInput.value.trim()}={})=>{
    const normalizedQuery=query.trim();
    const scopedBooks=classBooks.filter(b=>!type||b.bookType===type);
    const books=searchBooks(scopedBooks,normalizedQuery);
    const target=page.querySelector("#books"); target.innerHTML="";
    filters.forEach(btn=>{const active=btn.id===(type||"all");btn.classList.toggle("active",active);btn.setAttribute("aria-pressed",String(active));});
    page.querySelector("#bookHeading").textContent=type==="matn"?L.filterMatn:type==="sharah"?L.filterSharah:L.filterAll;
    page.querySelector("#classBookCount").textContent=`${books.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams=baseParams(); if(type)nextParams.type=type; if(normalizedQuery)nextParams.q=normalizedQuery;
      navigate(routeName,nextParams,{replace:true});
    }
    if(!books.length){target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-book-open"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noClassBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا فلٹر منتخب کر کے دیکھیں۔":"Try another filter or browse another class."))}</p></div>`;return;}
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,...(all?{fromCatalogue:"1"}:{fromClass:id}),type:type||"",q:normalizedQuery}):null)));
  };
  header.querySelector("#classBack").onclick=()=>{ if(searchPanel.classList.contains("is-open")){ closeSearchViaBack(); return; } goBackInApp(); };
  searchToggle.onclick=()=>{ if(searchPanel.classList.contains("is-open")) closeSearchViaBack(); else openSearchPanel(); };
  searchClear.onclick=()=>closeSearchViaBack();
  page.querySelector("#all").onclick=()=>render(null);
  page.querySelector("#matn").onclick=()=>render("matn");
  page.querySelector("#sharah").onclick=()=>render("sharah");
  header.querySelector("#classSearchForm").onsubmit=e=>{e.preventDefault();render(filtersType(),{query:searchInput.value});};
  searchInput.addEventListener("input",()=>{
    clearTimeout(searchTimer);
    searchTimer=setTimeout(()=>{
      const type=filtersType();
      const normalizedQuery=searchInput.value.trim();
      render(type,{updateUrl:false,query:searchInput.value});
      const nextParams=baseParams(); if(type) nextParams.type=type; if(normalizedQuery) nextParams.q=normalizedQuery;
      replaceRoute(routeName,nextParams);
      if(searchPanel.classList.contains("is-open")) history.replaceState({...history.state,classSearchOpen:true},"",location.href);
    },180);
  });
  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialType,{updateUrl:false,query:initialQuery});
}

/* One card design for both the Classes and Categories tabs. */
function renderCardList({title,sub,route,pageClass,kind,items,allCard,getLocalTotal,loadStats,statsLabel,onOpen}){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  const page=shell(title,`<header class="tab-head"><div><h1 class="tab-title">${title}</h1><p class="tab-sub">${sub}</p></div></header><div class="class-list" id="cardList"></div>`,route);
  page.classList.add("classes-page",pageClass);
  const list=page.querySelector("#cardList");
  const bookWord=ur?"کتب":"books", noBooks=ur?"ابھی کوئی کتاب نہیں":"No books yet";
  const fill=(row,stat)=>{
    const count=row.querySelector(".class-count");
    if(!stat){ count.textContent=`— ${bookWord}`; row.classList.remove("is-empty"); return; }
    count.textContent=stat.total?`${stat.total} ${bookWord}`:noBooks;
    row.classList.toggle("is-empty",!stat.total);
  };
  // Counts are only trustworthy once the whole catalogue is loaded; otherwise show a placeholder
  // and fill in the authoritative numbers from the stats loader.
  const complete=getLibraryCacheInfo().complete;
  if(allCard){
    const allRow=document.createElement("a");
    allRow.className="class-row is-all"; allRow.href=allCard.href; allRow.style.setProperty("--i",0);
    allRow.innerHTML=`<span class="class-ico">${icon("library")}</span><span class="class-text"><span class="class-name">${escapeHTML(allCard.name)}</span><span class="class-count">${escapeHTML(allCard.sub)}</span></span><i class="fa-solid fa-chevron-${ur?"left":"right"} class-go" aria-hidden="true"></i>`;
    list.appendChild(allRow);
  }
  items.forEach((c,i)=>{
    const row=document.createElement("button");
    const idn=identityFor(kind,c);
    row.type="button"; row.className=`class-row tc-${idn.tone}`; row.dataset.itemId=c.id; row.style.setProperty("--i",Math.min(i+(allCard?1:0),10));
    row.innerHTML=`<span class="class-ico" aria-hidden="true">${idn.glyph}</span><span class="class-name">${escapeHTML(langName(c,lang))}</span><span class="class-count"></span>`;
    row.onclick=()=>onOpen(c);
    fill(row, complete?{total:getLocalTotal(c)}:null);
    list.appendChild(row);
  });
  loadStats().then(stats=>{
    if(!stats || !page.isConnected) return;
    list.querySelectorAll(".class-row[data-item-id]").forEach(row=>{ const stat=stats[row.dataset.itemId]; if(stat) fill(row,stat); });
  }).catch(error=>console.warn(`KR Urdu Library ${statsLabel} stats unavailable.`, error));
}

function renderClasses(){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  renderCardList({
    title:L.classes,
    sub:ur?"اپنی جماعت منتخب کریں اور متعلقہ کتب دیکھیں":"Choose a class to browse its books",
    route:"classes", pageClass:"classes-screen", kind:"class",
    items:data.classes,
    allCard:{href:"#catalogue",name:L.allBooks,sub:ur?"پوری لائبریری ایک جگہ":"The whole library in one place"},
    getLocalTotal:c=>(data.byClass?.get(c.id)||[]).length,
    loadStats:loadClassStats, statsLabel:"class",
    onOpen:c=>navigate("class",{id:c.id})
  });
}

function renderCategories(){
  const lang=currentLang(), ur=lang==="ur";
  renderCardList({
    title:ur?"زمرے":"Categories",
    sub:ur?"موضوع کے لحاظ سے کتب دیکھیں":"Browse books by topic",
    route:"categories", pageClass:"categories-page", kind:"category",
    items:data.categories,
    getLocalTotal:c=>(data.byCategory?.get(c.id)||[]).length,
    loadStats:loadCategoryStats, statsLabel:"category",
    onOpen:c=>navigate("category",{id:c.id})
  });
}

function renderCategory(id){
  const lang=currentLang(),L=t[lang],c=data.categories.find(x=>x.id===id);
  if(!c)return navigate("categories");
  const books=data.byCategory?.get(id) || data.books.filter(b=>(b.categoryIds||[]).includes(id));
  const routeParams=readRoute().params,initialQuery=String(routeParams.q||"");
  const {page,header}=categoryShell(langName(c,lang),`<div class="class-intro category-intro"><div><h1 class="section-title">${escapeHTML(langName(c,lang))}</h1><div class="muted" id="categoryBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-layer-group"></i></div></div><section class="section category-books-section"><div class="section-head"><h2 class="section-title">${L.catalogue}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const searchInput=header.querySelector("#categorySearchInput");
  const searchPanel=header.querySelector("#categorySearchPanel");
  const searchToggle=header.querySelector("#categorySearchToggle");
  const searchClear=header.querySelector("#categorySearchClear");
  let timer=0;

  const baseParams=()=>({id});
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open"))return;
    if(!history.state?.categorySearchOpen){
      history.pushState({...history.state,categorySearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true});searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.categorySearchOpen);
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
    if(hadSearchHistory && history.length>1)history.back();
    else closeSearchPanel();
  };
  window.__krCategorySearchClose=closeSearchPanel;

  const render=(query=searchInput.value.trim(),updateUrl=true)=>{
    const normalizedQuery=query.trim(),filtered=searchBooks(books,normalizedQuery),target=page.querySelector("#books");
    target.innerHTML="";
    page.querySelector("#categoryBookCount").textContent=`${filtered.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      navigate("category",nextParams,{replace:true});
    }
    if(!filtered.length){
      target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-layer-group"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noCategoryBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا زمرہ منتخب کر کے دیکھیں۔":"Browse another category to find more books."))}</p></div>`;
      return;
    }
    filtered.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,fromCategory:id,q:normalizedQuery}):null)));
  };

  header.querySelector("#categoryBack").onclick=()=>{
    if(searchPanel.classList.contains("is-open")){closeSearchViaBack();return;}
    goBackInApp();
  };
  searchToggle.onclick=()=>{
    if(searchPanel.classList.contains("is-open"))closeSearchViaBack();
    else openSearchPanel();
  };
  searchClear.onclick=()=>closeSearchViaBack();
  header.querySelector("#categorySearchForm").onsubmit=e=>{e.preventDefault();render(searchInput.value);};
  searchInput.addEventListener("input",()=>{
    clearTimeout(timer);
    timer=setTimeout(()=>{
      const normalizedQuery=searchInput.value.trim();
      render(searchInput.value,false);
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      replaceRoute("category",nextParams);
      if(searchPanel.classList.contains("is-open"))history.replaceState({...history.state,categorySearchOpen:true},"",location.href);
    },180);
  });

  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialQuery,false);
}
const RECENT_SEARCH_KEY="krl_recent_searches_v1";
function getRecentSearches(){
  try{const v=JSON.parse(localStorage.getItem(RECENT_SEARCH_KEY)||"[]");return Array.isArray(v)?v.filter(x=>typeof x==="string"&&x.trim()).slice(0,8):[];}catch{return [];}
}
function addRecentSearch(q){
  q=String(q||"").trim(); if(!q) return;
  try{const list=[q,...getRecentSearches().filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,8);localStorage.setItem(RECENT_SEARCH_KEY,JSON.stringify(list));}catch{}
}
function clearRecentSearches(){ try{localStorage.removeItem(RECENT_SEARCH_KEY);}catch{} }

function renderSearch(q){
  const lang=currentLang(),L=t[lang],ur=lang==="ur";
  q=String(q||"").trim();
  const S=ur
    ?{label:"تلاش کے نتائج",searching:"نتائج تلاش کی جا رہی ہیں…",clear:"صاف کریں",clearInput:"تلاش صاف کریں",recent:"حالیہ تلاشیں",hint:"کتاب کا نام، مصنف یا کوئی لفظ لکھ کر تلاش کریں۔",browse:"تمام کتب دیکھیں",classes:"جماعتیں",categories:"زمرے",retry:"دوبارہ کوشش کریں",failed:"نتائج لوڈ نہیں ہو سکے۔",failedHint:"انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔",loading:"مزید نتائج لوڈ ہو رہے ہیں…",done:"تمام نتائج دکھا دیے گئے ہیں۔",moreErr:"نتائج لوڈ نہیں ہو سکے۔ دوبارہ کوشش کریں۔",none:"کوئی نتیجہ نہیں ملا"}
    :{label:"Search results",searching:"Searching…",clear:"Clear",clearInput:"Clear search",recent:"Recent searches",hint:"Type a title, author or any word to search.",browse:"Browse all books",classes:"Classes",categories:"Categories",retry:"Try again",failed:"Could not load results.",failedHint:"Check your connection and try again.",loading:"Loading more results…",done:"All matching results loaded.",moreErr:"Could not load more results.",none:"No results found"};
  const back=ur?"fa-arrow-right":"fa-arrow-left";
  const recents=q?[]:getRecentSearches();
  const chip=(txt,attr)=>`<button type="button" class="sr-chip" ${attr}>${escapeHTML(txt)}</button>`;
  const emptyQuery=`<section class="sr-start" id="srStart">
      ${recents.length?`<div class="sr-sec-head"><h2>${S.recent}</h2><button type="button" class="sr-link" id="srClearRecents">${S.clear}</button></div><div class="sr-chips">${recents.map(r=>chip(r,`data-q="${escapeHTML(r)}"`)).join("")}</div>`
        :`<div class="sr-hint"><span class="sr-hint-ico" aria-hidden="true">${icon("search")}</span><p>${S.hint}</p></div>`}
      <div class="sr-chips sr-browse"><button type="button" class="sr-chip is-soft" id="srClasses">${S.classes}</button><button type="button" class="sr-chip is-soft" id="srCategories">${S.categories}</button><button type="button" class="sr-chip is-soft" id="srAll">${S.browse}</button></div>
    </section>`;
  const skeletons=Array.from({length:6},()=>`<div class="sr-skel" aria-hidden="true"><div class="sr-skel-cover"></div><div class="sr-skel-line"></div><div class="sr-skel-line short"></div></div>`).join("");
  const page=document.createElement("main");
  page.className="sr-screen sr-page"; page.setAttribute("aria-label",ur?"تلاش":"Search");
  page.innerHTML=`<header class="sr-top">
      <button class="icon-btn sr-back" id="searchBack" type="button" aria-label="${escapeHTML(L.back)}"><i class="fa-solid ${back}"></i></button>
      <form class="search-pill sr-pill" id="searchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="searchInput" type="search" value="${escapeHTML(q)}" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(L.search)}" placeholder="${escapeHTML(L.search)}"><button class="search-pill-clear" id="searchClear" type="button" aria-label="${S.clearInput}" ${q?"":"hidden"}><i class="fa-solid fa-xmark"></i></button></form>
    </header>
    <section class="page sr-body">${q?`<header class="sr-head"><p class="sr-label">${S.label}</p><h1 class="sr-query">“<bdi>${escapeHTML(q)}</bdi>”</h1><p class="sr-sub" id="searchSummary" aria-live="polite">${S.searching}</p></header>
    <div class="grid book-grid" id="books">${skeletons}</div>
    <div class="catalogue-loader" id="searchLoader" data-state="idle" aria-live="polite"><span class="catalogue-loader-spinner" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span id="searchLoaderText"></span><button type="button" class="sr-link sr-loader-retry" id="searchLoaderRetry" hidden>${S.retry}</button></div>`:emptyQuery}</section>`;
  app.innerHTML=""; app.appendChild(page);
  searchObserver?.disconnect(); searchObserver=null;
  const $=s=>page.querySelector(s);
  const input=$("#searchInput"),clearBtn=$("#searchClear");

  $("#searchBack").onclick=()=>goBackInApp();
  // Scrolling the results hides the keyboard so the whole list is visible.
  let lastY=window.scrollY;
  const onScroll=()=>{
    if(!page.isConnected){window.removeEventListener("scroll",onScroll);return;}
    if(Math.abs(window.scrollY-lastY)>12 && document.activeElement===input) input.blur();
    lastY=window.scrollY;
  };
  window.addEventListener("scroll",onScroll,{passive:true});
  input.addEventListener("input",()=>{clearBtn.hidden=!input.value;});
  clearBtn.onclick=()=>{input.value="";clearBtn.hidden=true;input.focus();};
  const run=(text)=>{
    const next=String(text||"").trim();
    if(!next){input.focus();return;}
    if(next===q) return;
    navigate("search",{q:next},{replace:state.route==="search"});
  };
  $("#searchForm").onsubmit=e=>{e.preventDefault();input.blur();run(input.value);};

  if(!q){
    page.querySelectorAll(".sr-chip[data-q]").forEach(b=>b.onclick=()=>run(b.dataset.q));
    $("#srClearRecents")?.addEventListener("click",()=>{clearRecentSearches();renderSearch("");});
    $("#srClasses").onclick=()=>navigate("classes");
    $("#srCategories").onclick=()=>navigate("categories");
    $("#srAll").onclick=()=>navigate("catalogue");
    setTimeout(()=>{try{input.focus();}catch{}},60);
    return;
  }

  const token=++searchRequestToken;
  searchLoadInFlight=null; // a slow request from the previous query must not block this one
  if(searchSession.q!==q) searchSession={q,books:[],done:false};
  const target=$("#books"),loader=$("#searchLoader"),loaderText=$("#searchLoaderText"),retryBtn=$("#searchLoaderRetry");
  const setLoader=(mode)=>{
    loader.dataset.state=mode;
    retryBtn.hidden=mode!=="error";
    loaderText.textContent=mode==="loading"?S.loading:mode==="done"?S.done:mode==="error"?S.moreErr:"";
  };
  const clearSkeleton=()=>target.querySelectorAll(".sr-skel").forEach(n=>n.remove());
  const updateSummary=(count,done)=>{
    $("#searchSummary").textContent=ur?(count===1&&done?"1 کتاب":`${count}${done?"":"+"} کتب`):`${count}${done?"":"+"} ${count===1&&done?"book":"books"}`;
  };
  const showEmpty=()=>{
    target.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico" aria-hidden="true">${icon("search")}</span><strong>${escapeHTML(L.noSearch)}</strong><p>${escapeHTML(ur?`“${q}” کے لیے کوئی نتیجہ نہیں ملا۔ ${L.noSearchHint}`:`No results for “${q}”. ${L.noSearchHint}`)}</p><div class="sr-empty-actions"><button type="button" class="sr-cta" id="srEmptyClear">${S.clearInput}</button><button type="button" class="sr-chip is-soft" id="srEmptyAll">${S.browse}</button></div></div>`;
    target.classList.add("is-empty");
    $("#srEmptyClear").onclick=()=>{input.value="";clearBtn.hidden=true;input.focus();};
    $("#srEmptyAll").onclick=()=>navigate("catalogue");
    $("#searchSummary").textContent=S.none;
  };
  const showFailed=()=>{
    target.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico is-warn" aria-hidden="true">${icon("alert")}</span><strong>${S.failed}</strong><p>${S.failedHint}</p><div class="sr-empty-actions"><button type="button" class="sr-cta" id="srRetry">${S.retry}</button></div></div>`;
    target.classList.add("is-empty");
    $("#searchSummary").textContent="";
    $("#srRetry").onclick=()=>{target.classList.remove("is-empty");target.innerHTML=skeletons;$("#searchSummary").textContent=S.searching;loadMore();};
  };
  let savedRecent=false;
  const openBook=(a,id)=>a==="book"?navigate("book",{id}):null;
  const loadMore=async()=>{
    if(token!==searchRequestToken || searchLoadInFlight || state.route!=="search" || !page.isConnected)return;
    searchLoadInFlight=(async()=>{
      setLoader("loading");
      try{
        let result;
        try{
          result=await searchBooksPage(q,{pageSize:20});
        }catch(remoteError){
          console.warn("KR Urdu Library server search unavailable; using cached catalogue.",remoteError);
          result={results:searchBooks(data.books,q).slice(0,20),done:true};
        }
        if(token!==searchRequestToken || !page.isConnected)return;
        clearSkeleton();
        if(result.results?.length){
          mergeBooksIntoLibrary(result.results);
          const have=new Set([...target.querySelectorAll(".book-card")].map(c=>c.dataset.bookId));
          searchBooks(result.results,q).forEach(b=>{
            if(have.has(b.id))return; have.add(b.id);
            searchSession.books.push(b);
            target.appendChild(bookCard(b,lang,openBook));
          });
        }
        if(token===searchRequestToken) searchSession.done=Boolean(result.done);
        const count=target.querySelectorAll(".book-card").length;
        if(count&&!savedRecent){savedRecent=true;addRecentSearch(q);}
        if(!count&&result.done){showEmpty();}
        else updateSummary(count,Boolean(result.done));
        if(result.done){ setLoader(count?"done":"idle"); searchObserver?.disconnect(); searchObserver=null; }
        else setLoader("idle");
      }catch(error){
        console.error("KR Urdu Library search failed",error);
        if(token!==searchRequestToken || !page.isConnected)return;
        clearSkeleton();
        if(!target.querySelector(".book-card")){ showFailed(); setLoader("idle"); }
        else setLoader("error");
      }finally{ if(token===searchRequestToken) searchLoadInFlight=null; }
    })();
    return searchLoadInFlight;
  };
  retryBtn.onclick=()=>loadMore();
  if(searchSession.books.length){
    // Coming back to a search we already ran: show the saved list at once, keep loading only if more can come.
    clearSkeleton();
    searchSession.books.forEach(b=>target.appendChild(bookCard(b,lang,openBook)));
    savedRecent=true;
    updateSummary(searchSession.books.length,searchSession.done);
    if(searchSession.done){ setLoader("done"); return; }
  }else if(searchSession.done){
    clearSkeleton(); showEmpty(); return;
  }
  searchObserver=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting))loadMore();},{root:null,rootMargin:"0px 0px 500px 0px",threshold:0.01});
  searchObserver.observe(loader);
  loadMore();
}

function renderFavorites(){
  const lang=currentLang(),L=t[lang],ur=lang==="ur";
  const byId=id=>data.byId?.get(id)||data.books.find(b=>b.id===id);
  // Newest saved first (storage keeps insertion order).
  const books=getFavorites().slice().reverse().map(byId).filter(Boolean);
  const titleOf=b=>ur?b.title:(b.titleEn||b.title);
  const subText=n=>ur?(n===1?"1 کتاب محفوظ":`${n} کتب محفوظ`):`${n} ${n===1?"book":"books"} saved`;
  const S=ur
    ?{recent:"تازہ ترین",title:"عنوان",sort:"ترتیب",find:"پسندیدہ میں تلاش کریں",none:"کوئی کتاب نہیں ملی",hint:"کسی بھی کتاب پر دل کے آئیکن کو دبائیں، وہ یہاں محفوظ ہو جائے گی۔",browse:"کتب دیکھیں",removed:"پسندیدہ سے ہٹا دی گئی",undo:"واپس لائیں"}
    :{recent:"Recently saved",title:"Title A–Z",sort:"Sort",find:"Search favorites",none:"No matching books",hint:"Tap the heart on any book to keep it here.",browse:"Browse books",removed:"Removed from favorites",undo:"Undo"};
  const page=document.createElement("main");
  page.className="fav-screen fv-page"; page.setAttribute("aria-label",L.fav);
  page.innerHTML=`<header class="fav-top">
      <button class="icon-btn" id="favBack" type="button" aria-label="${escapeHTML(L.back)}"><i class="fa-solid ${ur?"fa-arrow-right":"fa-arrow-left"}"></i></button>
      <div class="fv-heading"><strong class="fav-title">${escapeHTML(L.fav)}</strong><small class="fv-sub" id="favSub">${subText(books.length)}</small></div>
    </header>
    <section class="page"><div class="fv-wrap">
      <div class="fv-tools" id="favTools" hidden>
        <div class="fv-sort" role="group" aria-label="${S.sort}">
          <button type="button" class="fv-chip" data-sort="recent" aria-pressed="true">${S.recent}</button>
          <button type="button" class="fv-chip" data-sort="title" aria-pressed="false">${S.title}</button>
        </div>
        <label class="fv-find" id="favFind" hidden><span aria-hidden="true">${icon("search")}</span><input id="favFilter" type="search" autocomplete="off" enterkeyhint="search" placeholder="${S.find}" aria-label="${S.find}"></label>
      </div>
      <div class="grid book-grid" id="books"></div>
      <p class="fv-nomatch" id="favNoMatch" hidden>${S.none}</p>
      <div class="fv-empty" id="favEmpty" hidden>
        <span class="fv-empty-ico" aria-hidden="true">${icon("heart")}</span>
        <strong>${escapeHTML(L.noFavorites)}</strong>
        <p>${S.hint}</p>
        <button type="button" class="fv-cta" id="favBrowse">${S.browse}</button>
      </div>
    </div></section>`;
  app.innerHTML=""; app.appendChild(page);
  page.querySelector("#favBack").onclick=()=>{ if(history.length>1) history.back(); else navigate("home"); };

  const $=s=>page.querySelector(s);
  const target=$("#books"),sub=$("#favSub"),tools=$("#favTools"),find=$("#favFind"),filter=$("#favFilter"),noMatch=$("#favNoMatch"),empty=$("#favEmpty");
  const cards=new Map(),removed=new Set();
  let sort="recent",query="",undoTimer=null;

  const openBook=(a,id)=>a==="book"?navigate("book",{id}):null;
  const showUndo=(book)=>{
    document.querySelector(".fv-undo")?.remove(); clearTimeout(undoTimer);
    const bar=document.createElement("div"); bar.className="fv-undo"; bar.setAttribute("role","status");
    bar.innerHTML=`<span>${S.removed}</span><button type="button">${S.undo}</button>`;
    bar.querySelector("button").onclick=()=>{
      clearTimeout(undoTimer); bar.remove();
      toggleFavorite(book.id); removed.delete(book.id);
      const card=cards.get(book.id),hb=card?.querySelector(".favorite-btn");
      if(hb){hb.classList.add("active");hb.setAttribute("aria-pressed","true");}
      card?.classList.remove("is-leaving");
      paint();
    };
    document.body.appendChild(bar);
    undoTimer=setTimeout(()=>bar.remove(),5000);
  };

  books.forEach(b=>{
    const card=bookCard(b,lang,openBook);
    card.addEventListener("favoritechange",e=>{
      if(e.detail?.favorite) return;
      removed.add(b.id); card.classList.add("is-leaving");
      showUndo(b);
      setTimeout(()=>{ if(removed.has(b.id)) paint(); },200);
    });
    cards.set(b.id,card);
  });

  function paint(){
    const live=books.filter(b=>!removed.has(b.id));
    sub.textContent=subText(live.length);
    const none=live.length===0;
    empty.hidden=!none; target.hidden=none;
    tools.hidden=live.length<2;
    find.hidden=live.length<8 && !query;
    if(none){ noMatch.hidden=true; return; }
    const q=query.trim().toLowerCase();
    let list=q?live.filter(b=>`${b.title||""} ${b.titleEn||""} ${b.author||""}`.toLowerCase().includes(q)):live.slice();
    if(sort==="title") list.sort((a,b)=>String(titleOf(a)).localeCompare(String(titleOf(b)),ur?"ur":"en"));
    target.replaceChildren(...list.map(b=>cards.get(b.id)));
    noMatch.hidden=list.length>0;
  }

  page.querySelectorAll(".fv-chip").forEach(btn=>btn.onclick=()=>{
    if(sort===btn.dataset.sort) return;
    sort=btn.dataset.sort;
    page.querySelectorAll(".fv-chip").forEach(x=>x.setAttribute("aria-pressed",String(x===btn)));
    try{navigator.vibrate?.(8);}catch{}
    paint();
  });
  filter.addEventListener("input",()=>{query=filter.value;paint();});
  $("#favBrowse").onclick=()=>navigate("catalogue");
  paint();
}
function getRelatedBooks(book, limit = 4){
  const classIds = new Set(Array.isArray(book.classIds) ? book.classIds : (book.classId ? [book.classId] : []));
  const categoryIds = new Set(Array.isArray(book.categoryIds) ? book.categoryIds : []);
  return data.books
    .filter(candidate => candidate.id !== book.id && candidate.status === "available")
    .map(candidate => {
      const candidateClasses = Array.isArray(candidate.classIds) ? candidate.classIds : (candidate.classId ? [candidate.classId] : []);
      const candidateCategories = Array.isArray(candidate.categoryIds) ? candidate.categoryIds : [];
      let score = 0;
      if (candidateClasses.some(id => classIds.has(id))) score += 4;
      if (candidateCategories.some(id => categoryIds.has(id))) score += 3;
      if (candidate.bookType === book.bookType) score += 1;
      return { candidate, score };
    })
    .filter(item => item.score > 0)
    .sort((a,b) => b.score - a.score || String(b.candidate.addedAt || "").localeCompare(String(a.candidate.addedAt || "")))
    .slice(0, limit)
    .map(item => item.candidate);
}

function renderBook(id){
  const lang=currentLang(),L=t[lang],b=data.byId?.get(id) || data.books.find(x=>x.id===id);if(!b)return navigate("home");
  const title=lang==="ur"?b.title:(b.titleEn||b.title), fav=getFavorites().includes(b.id), progress=getBookProgress(b.id);
  const percent=Math.max(0,Math.min(100,Number(progress?.percent)||0));
  const hasPdf=b.status==="available" && (validExternalUrl(b.pdfUrl) || Boolean(b.driveFileId)), hasSource=validExternalUrl(b.source?.pageUrl);
  const ok=b.status==="available";
  const statTypeLabel=b.bookType==="matn"?(lang==="ur"?"متون":"Matn"):(lang==="ur"?"شروحات":"Commentary");
  const stat=(v,c,cls="")=>`<div class="stat ${cls}"><strong>${escapeHTML(String(v))}</strong><span>${escapeHTML(c)}</span></div>`;
  const meta=[
    stat(statTypeLabel, lang==="ur"?"قسم":"Type"),
    b.pages?stat(b.pages, lang==="ur"?"صفحات":"Pages"):"",
    stat("PDF", lang==="ur"?"فارمیٹ":"Format"),
    stat(ok?L.available:(lang==="ur"?"دستیاب نہیں":"Unavailable"), lang==="ur"?"حالت":"Status", ok?"stat-ok":"stat-bad")
  ].filter(Boolean).join("");
  const resume=progress?.openedAt?`<div class="book-progress" aria-label="${lang==="ur"?`${percent}% مطالعہ مکمل`:`${percent}% read`}"><div class="book-progress-head"><span><i class="fa-solid fa-clock-rotate-left"></i> ${lang==="ur"?"مطالعہ کی پیش رفت":"Reading progress"}</span><strong>${percent}%</strong></div><div class="book-progress-track"><span style="width:${percent}%"></span></div><button class="progress-action" id="resume">${L.continueAction} <i class="fa-solid ${lang==="ur"?"fa-arrow-left":"fa-arrow-right"}"></i></button></div>`:"";
  const related=getRelatedBooks(b,4);
  const relatedMarkup=related.length ? `<section class="detail-section related-books-section"><div class="section-head"><div><h2 class="section-title">${L.related}</h2><p class="section-subtitle">${L.relatedHint}</p></div></div><div class="grid book-grid related-books-grid" id="relatedBooks"></div></section>` : "";
  const downloadNote=!hasPdf ? `<p class="action-note" role="status"><i class="fa-solid fa-circle-info"></i> ${escapeHTML(L.sourceMissing)}</p>` : "";
  const page=detailShell(title,`<article class="book-detail"><div class="book-detail-main"><div class="detail-ambient tc-${paletteIndex(b.id)}" aria-hidden="true"></div><div class="detail-cover-wrap"><div class="cover detail-cover">${typesetCover(title,b.author,b.id)}${b.cover?coverMarkup(escapeHTML(b.cover),`${escapeHTML(title)} cover`):""}</div></div><div class="book-detail-info"><h1 class="detail-title">${escapeHTML(title)}</h1><p class="detail-author">${escapeHTML(b.author||"")}</p><div class="chips" aria-label="${lang==="ur"?"کتاب کی معلومات":"Book information"}">${meta}</div>${resume}<div class="detail-buttons"><button class="btn primary" id="read" ${b.status!=="available"?"disabled":""}><i class="fa-solid fa-book-open"></i> ${L.read}</button><button class="btn" id="download" ${!hasPdf?"disabled":""}><i class="fa-solid fa-download"></i> ${L.download}</button><button class="btn detail-favorite ${fav?"active":""}" id="fav" aria-pressed="${fav}">${HEART}<span>${L.fav}</span></button></div>${downloadNote}</div></div><div class="book-detail-sections"><section class="detail-section"><h2 class="section-title">${L.about}</h2><p class="muted detail-desc" id="desc">${escapeHTML(b.description||"")}</p><button class="desc-toggle" id="descToggle" type="button" hidden>${lang==="ur"?"مزید پڑھیں":"Read more"}</button></section>${relatedMarkup}<section class="detail-section"><h2 class="section-title">${L.source}</h2>${b.source?.name?`<p class="source-name">${escapeHTML(b.source.name)}</p>`:""}${hasSource?`<button class="btn" id="source"><i class="fa-solid fa-arrow-up-right-from-square"></i> ${L.openSource}</button>`:`<p class="muted source-unavailable">${lang==="ur"?"اصل ماخذ دستیاب نہیں ہے۔":"Original source is not available."}</p>`}</section><section class="detail-section detail-report"><button class="btn danger" id="report"><i class="fa-solid fa-triangle-exclamation"></i> ${L.report}</button></section></div></article>`,"");
  page.classList.add("book-detail-page");
  app.querySelector("#bookBack")?.addEventListener("click",()=>goBackInApp());
  const topBar=app.querySelector(".detail-top"), heroTitle=page.querySelector(".detail-title");
  if(topBar && heroTitle && "IntersectionObserver" in window){
    new IntersectionObserver(([en])=>topBar.classList.toggle("is-scrolled",!en.isIntersecting && en.boundingClientRect.top<200),{rootMargin:"-64px 0px 0px 0px",threshold:0}).observe(heroTitle);
  }
  wireCover(page.querySelector(".detail-cover"));
  const coverImg=page.querySelector(".detail-cover img"), ambient=page.querySelector(".detail-ambient");
  const showAmbient=()=>ambient?.classList.add("is-ready");
  if(coverImg){
    coverImg.addEventListener("load",()=>{
      const pal=ambient?coverPalette(coverImg):null;
      if(pal) for(const [k,v] of Object.entries(pal)) ambient.style.setProperty(k,v);
      showAmbient();
    },{once:true});
    setTimeout(showAmbient,2500);
  } else requestAnimationFrame(showAmbient);
  const desc=page.querySelector("#desc"), descToggle=page.querySelector("#descToggle");
  requestAnimationFrame(()=>{
    if(desc && descToggle && desc.scrollHeight>desc.clientHeight+2) descToggle.hidden=false; else desc?.classList.add("open");
  });
  descToggle?.addEventListener("click",()=>{
    const open=desc.classList.toggle("open");
    descToggle.textContent=open?(lang==="ur"?"کم دکھائیں":"Show less"):(lang==="ur"?"مزید پڑھیں":"Read more");
  });
  // Book details are a fresh view: never inherit a previous document scroll position.
  requestAnimationFrame(() => window.scrollTo({ top: 0, left: 0, behavior: "auto" }));
  page.querySelector("#read").onclick=()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});openReader(id);};
  page.querySelector("#resume")?.addEventListener("click",()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});openReader(id);});
  page.querySelector("#download")?.addEventListener("click",async()=>{
    await downloadBookPdf(b);
  });
  hasCachedPdf(b.id).then(cached=>{
    if(!cached || !page.isConnected) return;
    const actions=page.querySelector(".detail-buttons");
    if(!actions || actions.querySelector(".cached-book-badge")) return;
    const badge=document.createElement("span");
    badge.className="cached-book-badge";
    badge.setAttribute("role","status");
    badge.innerHTML='<i class="fa-solid fa-cloud-arrow-down"></i> '+escapeHTML(lang==="ur"?"آف لائن مطالعے کے لیے محفوظ":"Saved for offline reading");
    actions.appendChild(badge);
  });
  page.querySelector("#fav").onclick=()=>{
    const was=fav;
    const result=toggleFavorite(id);
    const nowFavorite=Array.isArray(result) ? result.includes(id) : Boolean(result);
    const button=page.querySelector("#fav");
    button.classList.toggle("active",nowFavorite);
    button.setAttribute("aria-pressed",String(nowFavorite));
    if(nowFavorite){ button.classList.remove("pop"); void button.offsetWidth; button.classList.add("pop"); setTimeout(()=>button.classList.remove("pop"),650); try{navigator.vibrate?.(10);}catch{} }
    const icon=button.querySelector("i");
    if(icon){icon.classList.toggle("fa-solid",nowFavorite);icon.classList.toggle("fa-regular",!nowFavorite);}
    showToast(was?L.favoriteRemoved:L.favoriteAdded);
  };
  page.querySelector("#source")?.addEventListener("click",()=>openExternal(b.source.pageUrl));
  page.querySelector("#report").onclick=()=>showToast(L.reportSoon);
  if(related.length){
    const target=page.querySelector("#relatedBooks");
    related.forEach(book=>target.appendChild(bookCard(book,lang,(action,id)=>action==="book"?navigate("book",{id}):null)));
  }
}

function renderMore(){
  const lang=currentLang(),L=t[lang],theme=state.theme;
  const ur=lang==="ur";
  const themeIdx={system:0,light:1,dark:2}[theme]??0;
  const themeLabel=v=>v==="system"?L.systemTheme:v==="dark"?L.darkTheme:L.lightTheme;
  const row=(id,ico,tone,title,sub)=>`<button class="mo-row" id="${id}" type="button"><span class="mo-ico ${tone}">${icon(ico)}</span><span class="mo-copy"><strong>${escapeHTML(title)}</strong>${sub?`<small>${escapeHTML(sub)}</small>`:""}</span>${icon("chevron","mo-chev")}</button>`;
  const themeBtn=(v,ico)=>`<button type="button" class="mo-seg-btn" data-theme="${v}" aria-pressed="${theme===v}">${icon(ico)}<span>${escapeHTML(themeLabel(v))}</span></button>`;
  const page=shell(L.more,`<div class="mo-wrap">
    <header class="tab-head mo-in" style="--k:0"><div><h1 class="tab-title" id="moreTitle">${escapeHTML(L.more)}</h1><p class="tab-sub">${ur?"ظاہری انداز، زبان اور آف لائن کتب":"Appearance, language and offline books"}</p></div></header>

    <section class="mo-section mo-in" style="--k:1" aria-labelledby="quickSettingsTitle">
      <h2 class="mo-label" id="quickSettingsTitle">${escapeHTML(L.quickSettings)}</h2>
      <div class="mo-group">
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-amber">${icon("sun")}</span><span class="mo-copy"><strong>${escapeHTML(L.appearanceShort)}</strong><small id="themeValue">${escapeHTML(themeLabel(theme))}</small></span></div>
          <div class="mo-seg" id="themeSeg" style="--n:3;--i:${themeIdx}" role="group" aria-label="${escapeHTML(L.appearanceShort)}"><span class="mo-seg-thumb" aria-hidden="true"></span>${themeBtn("system","auto")}${themeBtn("light","sun")}${themeBtn("dark","moon")}</div>
        </div>
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-blue">${icon("globe")}</span><span class="mo-copy"><strong>${escapeHTML(L.languageShort)}</strong><small>${ur?"اردو":"English"}</small></span></div>
          <div class="mo-seg" id="langSeg" style="--n:2;--i:${ur?0:1}" role="group" aria-label="${escapeHTML(L.languageShort)}"><span class="mo-seg-thumb" aria-hidden="true"></span>
            <button type="button" class="mo-seg-btn" id="ur" aria-pressed="${ur}"><span>اردو</span></button>
            <button type="button" class="mo-seg-btn" id="en" aria-pressed="${!ur}"><span>English</span></button>
          </div>
        </div>
      </div>
    </section>

    <section class="mo-section mo-in" style="--k:2" aria-labelledby="offlineSectionTitle">
      <h2 class="mo-label" id="offlineSectionTitle">${escapeHTML(L.offlineSection)}</h2>
      <div class="mo-group"><div class="mo-storage">
        <div class="mo-setting-head"><span class="mo-ico">${icon("disk")}</span><span class="mo-copy"><strong>${escapeHTML(L.savedBooks)}</strong><small id="pdfCacheSummary">${ur?"محفوظ شدہ کتب چیک کی جا رہی ہیں…":"Checking saved offline books…"}</small></span></div>
        <div class="mo-meter" aria-hidden="true"><span id="pdfCacheMeter"></span></div>
        <div class="mo-storage-foot"><span class="mo-usage" id="pdfCacheUsage">${escapeHTML(L.storageUsed)}</span><button class="mo-danger" id="clearOffline" type="button" disabled>${icon("broom")}<span>${escapeHTML(L.clearOfflineShort)}</span></button></div>
      </div></div>
    </section>

    <section class="mo-section mo-in" style="--k:3" aria-labelledby="dataSectionTitle">
      <div class="mo-group">
        <button class="mo-row mo-toggle" id="dataSectionToggle" type="button" aria-expanded="false" aria-controls="dataSectionPanel"><span class="mo-ico is-blue">${icon("database")}</span><span class="mo-copy"><strong id="dataSectionTitle">${escapeHTML(L.dataSection)}</strong></span>${icon("chevron","mo-chev")}</button>
        <div class="mo-collapse" id="dataSectionPanel"><div><div class="mo-panel">
          <p>${escapeHTML(ur?"پسندیدہ، مطالعہ کی تاریخ اور پیش رفت اسی ڈیوائس پر محفوظ ہوتی ہے۔":"Favorites, reading history and progress are stored locally on this device.")}</p>
          <div class="mo-actions">
            <button class="mo-ghost" id="clearHistory" type="button">${icon("clock")}<span>${escapeHTML(L.clearHistoryShort)}</span></button>
            <button class="mo-danger is-solid" id="clearData" type="button">${icon("trash")}<span>${escapeHTML(L.clearDataShort)}</span></button>
          </div>
        </div></div></div>
      </div>
    </section>

    <section class="mo-section mo-in" style="--k:4" aria-label="${escapeHTML(L.more)}">
      <div class="mo-group">
        ${row("openRights","scale","is-amber",L.sourceRightsShort,"")}
        ${row("openAbout","info","is-blue",L.aboutApp,"")}
      </div>
    </section>

    <footer class="mo-footer mo-in" style="--k:5"><span class="mo-footer-mark" aria-hidden="true">KR</span><strong>${escapeHTML(L.brand)}</strong><span>${escapeHTML(L.tagline)}</span><small>${escapeHTML(BUILD_TAG)}</small></footer>
  </div>`,"more");
  page.classList.add("mo-page");

  const pressSeg=(seg,btn,idx)=>{
    seg.style.setProperty("--i",String(idx));
    seg.querySelectorAll(".mo-seg-btn").forEach(x=>x.setAttribute("aria-pressed",String(x===btn)));
    try{navigator.vibrate?.(8);}catch{}
  };
  page.querySelectorAll("[data-theme]").forEach(b=>b.onclick=()=>{
    const v=b.dataset.theme; if(v===state.theme) return;
    state.theme=v; changeTheme(v);
    pressSeg(page.querySelector("#themeSeg"),b,{system:0,light:1,dark:2}[v]);
    const val=page.querySelector("#themeValue"); if(val) val.textContent=themeLabel(v);
  });
  const switchLang=(code,btn)=>{
    if(currentLang()===code) return;
    pressSeg(page.querySelector("#langSeg"),btn,code==="ur"?0:1);
    setTimeout(()=>{state.language=code;setLanguage(code);render();},240);
  };
  page.querySelector("#ur").onclick=e=>switchLang("ur",e.currentTarget);
  page.querySelector("#en").onclick=e=>switchLang("en",e.currentTarget);
  page.querySelector("#openRights").onclick=()=>showInfoSheet(
    lang==="ur"?"ذرائع اور حقوق":"Sources & Rights",
    lang==="ur"?"ہر کتاب کے اصل ماخذ کو جہاں ممکن ہو نمایاں کیا جاتا ہے۔ مواد کو خودکار طور پر دوبارہ ہوسٹ نہیں کیا جاتا۔":"Each listing identifies its original source where available. Content is linked from external sources rather than automatically re-hosted."
  );
  page.querySelector("#openAbout").onclick=()=>showInfoSheet(L.aboutApp,L.tagline);

  const toggle=page.querySelector("#dataSectionToggle"), panel=page.querySelector("#dataSectionPanel");
  panel.inert=true;
  toggle.onclick=()=>{const open=toggle.getAttribute("aria-expanded")==="true";toggle.setAttribute("aria-expanded",String(!open));panel.classList.toggle("open",!open);panel.inert=open;};

  page.querySelector("#clearHistory").onclick=async()=>{const ok=await confirmDialog(L.clearHistory,lang==="ur"?"اس ڈیوائس سے مطالعہ کی تاریخ صاف کر دی جائے؟":"Clear reading history from this device?",lang==="ur"?"صاف کریں":"Clear",true);if(ok){clearHistory();showToast(L.historyCleared);render();}};
  page.querySelector("#clearData").onclick=async()=>{const ok=await confirmDialog(L.clearData,L.confirmClear,lang==="ur"?"سب صاف کریں":"Clear all",true);if(ok){localStorage.removeItem("krul:v1:favorites");clearHistory();clearProgress();showToast(L.dataCleared);render();}};

  getPdfCacheInfo().then(info=>{
    if(!page.isConnected)return;
    const summary=page.querySelector("#pdfCacheSummary"),usage=page.querySelector("#pdfCacheUsage"),meter=page.querySelector("#pdfCacheMeter");
    if(!summary)return;
    const bytes=Number(info.bytes||0),count=Number(info.count||0),mb=(bytes/(1024*1024)).toFixed(1),max=Number(info.maxBytes||512*1024*1024),percent=Math.max(0,Math.min(100,(bytes/max)*100));
    summary.textContent=count===0
      ?(ur?"ابھی کوئی کتاب آف لائن محفوظ نہیں":"No books saved offline yet")
      :ur?`${count} ${count===1?"محفوظ شدہ کتاب":"محفوظ شدہ کتب"} · ${mb} MB`:`${count} saved ${count===1?"book":"books"} · ${mb} MB`;
    if(usage)usage.textContent=`${mb} MB / ${Math.round(max/(1024*1024))} MB`;
    if(meter){
      meter.style.width=`${bytes>0?Math.max(percent,2):0}%`;
      meter.classList.toggle("is-warn",percent>=75&&percent<92);
      meter.classList.toggle("is-full",percent>=92);
    }
    const clearBtn=page.querySelector("#clearOffline");
    if(clearBtn)clearBtn.disabled=count===0;
  });
  page.querySelector("#clearOffline").onclick=async()=>{
    const ok=await confirmDialog(L.clearOffline,lang==="ur"?"اس ڈیوائس سے تمام محفوظ شدہ آف لائن کتب حذف کر دی جائیں؟":"Delete all saved offline books from this device?",lang==="ur"?"حذف کریں":"Delete",true);
    if(!ok)return;
    const cleared=await clearPdfCache();
    showToast(cleared?(lang==="ur"?"محفوظ شدہ آف لائن کتب صاف ہوگئیں۔":"Saved offline books cleared."):(lang==="ur"?"آف لائن کیش صاف نہیں ہو سکی۔":"Could not clear offline cache."));
    render();
  };
}

function formatBytes(n){
  n=Number(n)||0;
  if(n>=1073741824)return (n/1073741824).toFixed(1)+" GB";
  if(n>=1048576)return (n/1048576).toFixed(1)+" MB";
  if(n>=1024)return Math.round(n/1024)+" KB";
  return n+" B";
}
function renderDownloads(){
  renderLibrary({
    lang:currentLang(), shell, books:()=>data.books, navigate, showToast, confirmDialog,
    downloadBookPdf, coverMarkup, wireCover, escapeHTML
  });
}

// Downloaded and still on the phone -> read it in the premium offline reader; otherwise the online reader.
async function openReader(id){
  try{
    const rec=getDownloadRecord(id), plugin=getNativePlugin();
    if(rec && plugin){
      const info=await plugin.fileInfo({id:rec.downloadId});
      if(info?.exists){navigate("local",{book:id});return;}
    }
  }catch{}
  navigate("reader",{id});
}

function renderLocal(params){
  const lang=currentLang();
  let opts=null;
  if(params.book){
    const rec=getDownloadRecord(params.book);
    if(!rec)return navigate("downloads",{},{replace:true});
    const b=data.books.find(x=>x.id===rec.bookId);
    const title=lang==="ur"?(b?.title||rec.title):(b?.titleEn||rec.titleEn||b?.title||rec.title);
    if(b)addHistory(b.id);
    opts={lang,title,subtitle:(lang==="ur"?(b?.author||rec.author):(b?.authorEn||rec.authorEn||b?.author||rec.author))||"",source:{id:rec.downloadId},progressKey:rec.bookId};
  }else if(params.path){
    const name=(params.name||"PDF").replace(/\.pdf$/i,"");
    opts={lang,title:name,source:{path:params.path},progressKey:`file:${params.path}`,legacyKey:`file:${name}`};
  }else if(params.uri){
    const name=(params.name||"PDF").replace(/\.pdf$/i,"");
    opts={lang,title:name,source:{uri:params.uri},progressKey:`file:${params.uri}`,legacyKey:`file:${name}`};
  }
  if(!opts)return navigate("downloads",{},{replace:true});
  if(nativeReaderWanted()){
    // Native MuPDF reader first; if it can't be used the pdf.js reader below takes over.
    app.innerHTML=`<main class="boot"><div class="boot-bar"></div></main>`;
    openInNativeReader({...opts,onFallback:m=>showToast((lang==="ur"?"MuPDF ریڈر دستیاب نہیں: ":"MuPDF reader unavailable: ")+String(m).slice(0,110))}).then(done=>{
      if(done){ if(readRoute().route==="local") goBackInApp(); }
      else if(readRoute().route==="local") renderLocalReader(app,opts);
    });
    return;
  }
  return renderLocalReader(app,opts);
}

// "Open with" -> another app (file manager, WhatsApp...) handed us a PDF.
async function checkPendingOpen(){
  const plugin=getNativePlugin();
  if(!plugin)return;
  try{
    const res=await plugin.getPendingOpen();
    if(res?.uri)navigate("local",{uri:res.uri,name:res.name||"PDF"});
  }catch{}
}
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")checkPendingOpen();});

function showInfoSheet(title,message){
  const lang=currentLang();
  const existing=document.querySelector(".more-info-dialog");
  existing?.remove();
  const dialog=document.createElement("div");
  dialog.className="more-info-dialog";
  dialog.innerHTML=`<div class="more-info-dialog-backdrop" data-close></div><section class="more-info-dialog-panel" role="dialog" aria-modal="true" aria-labelledby="moreInfoTitle"><div class="more-info-dialog-head"><h2 id="moreInfoTitle">${escapeHTML(title)}</h2><button class="icon-btn" type="button" data-close aria-label="${escapeHTML(lang==="ur"?"بند کریں":"Close")}"><i class="fa-solid fa-xmark"></i></button></div><p>${escapeHTML(message)}</p></section>`;
  document.body.appendChild(dialog);
  const close=()=>dialog.remove();
  dialog.querySelectorAll("[data-close]").forEach(el=>el.addEventListener("click",close));
  requestAnimationFrame(()=>dialog.classList.add("is-open"));
}

let readerCleanup = null;
async function loadReaderPdfJs(){ return loadPdfJs(); }


async function downloadBookPdf(book){
  const title=(book?.titleEn||book?.title||"KR Urdu Library Book")
    .replace(/[\\/:*?"<>|]/g," ")
    .replace(/\s+/g," ")
    .trim()
    .replace(/[. ]+$/g,"") || "KR Urdu Library Book";
  const filename=`${title}.pdf`;
  // The gateway owns the final .pdf extension. Sending the extension again can
  // produce names such as "Book.pdf.pdf" when Content-Disposition is applied.
  const gatewayFilename=title;
  const url=pdfGatewayUrl(book.id)+"&download=1&filename="+encodeURIComponent(gatewayFilename);
  const ua=navigator.userAgent||"";
  const embeddedWebView=/;\s*wv\)/i.test(ua) || (/Android/i.test(ua) && /Version\/4\.0/i.test(ua) && /Chrome\//i.test(ua));

  try{
    if(typeof navigator !== "undefined" && navigator.onLine === false){
      const offlineError=new Error("You appear to be offline.");
      offlineError.code="OFFLINE";
      offlineError.retryable=true;
      throw offlineError;
    }
    return await downloadManager.download(book,url,{
      nativeDownload:embeddedWebView,
      allowLargeFileHandoff:true,
      largeFileThresholdBytes:100*1024*1024
    });
  }catch(err){
    // The Download Manager owns failure, retry, cancellation, and UI state.
    // Do not start a second hidden download here: doing so bypasses the
    // retry/recovery state machine and can create duplicate downloads.
    console.error("KR Urdu Library PDF download failed",{bookId:book?.id,error:err});
    throw err;
  }
}

function renderReader(id){
  if(readerCleanup) { readerCleanup(); readerCleanup = null; }
  const lang=currentLang(), L=t[lang], b=data.books.find(x=>x.id===id);
  if(!b || b.status!=="available") return navigate("book",{id});
  addHistory(id);

  const title=lang==="ur"?b.title:(b.titleEn||b.title), saved=getBookProgress(id);
  let pdf=null, loadingTask=null, currentPage=Math.max(1,Number(saved?.page)||1), scale=1, fitToWidth=true;
  const networkDebug=new URLSearchParams(location.hash.split("?")[1]||"").get("networkDebug")==="1";
  let networkMonitor=null;
  let rendering=false, destroyed=false, controlsHidden=false, resizeTimer=null, lastSavedPage=currentPage, cachedObjectUrl=null, activePdfSource=null;

  const prevIcon=lang==="ur"?"fa-chevron-right":"fa-chevron-left";
  const nextIcon=lang==="ur"?"fa-chevron-left":"fa-chevron-right";
  const labels = lang==="ur" ? {
    more:"مزید", download:"ڈاؤنلوڈ", jump:"صفحہ پر جائیں", source:"اصل ماخذ کھولیں",
    details:"کتاب کی تفصیل", alternateReader:"متبادل ریڈر استعمال کریں", fullscreen:"مکمل اسکرین", zoomIn:"زوم بڑھائیں", zoomOut:"زوم کم کریں",
    close:"بند کریں", go:"جائیں", page:"صفحہ", of:"از", invalid:"درست صفحہ نمبر درج کریں۔",
    loading:"کتاب لوڈ ہو رہی ہے…", openPdf:"PDF کھولیں"
  } : {
    more:"More", download:"Download", jump:"Jump to page", source:"Open source",
    details:"Book details", alternateReader:"Use alternate reader", fullscreen:"Fullscreen", zoomIn:"Zoom in", zoomOut:"Zoom out",
    close:"Close", go:"Go", page:"Page", of:"of", invalid:"Enter a valid page number.",
    loading:"Loading book…", openPdf:"Open PDF"
  };

  app.innerHTML=`<main class="reader-shell" aria-label="${escapeHTML(title)}">
    <header class="reader-top">
      <button class="icon-btn" id="back" aria-label="${L.back}">
        <i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i>
      </button>
      <strong class="reader-title" title="${escapeHTML(title)}">${escapeHTML(title)}</strong>
      <div class="reader-more-wrap">
        <button class="icon-btn" id="more" aria-label="${labels.more}" aria-haspopup="menu" aria-expanded="false">
          <i class="fa-solid fa-ellipsis-vertical"></i>
        </button>
        <div class="reader-more-menu" id="readerMoreMenu" role="menu" hidden>
          <button type="button" role="menuitem" data-action="download"><i class="fa-solid fa-download"></i><span>${labels.download}</span></button>
          <button type="button" role="menuitem" data-action="jump"><i class="fa-solid fa-arrow-right-to-bracket"></i><span>${labels.jump}</span></button>
          <button type="button" role="menuitem" data-action="source"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>${labels.source}</span></button>
          <button type="button" role="menuitem" data-action="alternate"><i class="fa-solid fa-layer-group"></i><span>${labels.alternateReader}</span></button>
          <button type="button" role="menuitem" data-action="details"><i class="fa-solid fa-circle-info"></i><span>${labels.details}</span></button>
          <div class="reader-menu-divider"></div>
          <button type="button" role="menuitem" data-action="zoomOut"><i class="fa-solid fa-minus"></i><span>${labels.zoomOut}</span></button>
          <button type="button" role="menuitem" data-action="zoomIn"><i class="fa-solid fa-plus"></i><span>${labels.zoomIn}</span></button>
          <button type="button" role="menuitem" data-action="fullscreen"><i class="fa-solid fa-expand"></i><span>${labels.fullscreen}</span></button>
        </div>
      </div>
    </header>

    <section class="reader-body external-mode" id="readerBody" tabindex="0" aria-label="${escapeHTML(title)}">
      <div class="reader-loading" id="readerLoading">
        <i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>
        <small id="readerViewerHint">${labels.readerViewerHint}</small>
        <div class="detail-actions">
          <button class="btn" id="readerUseAlternate"><i class="fa-solid fa-layer-group"></i>${labels.alternateReader}</button>
        </div>
      </div>
      <iframe id="readerExternalFrame" class="reader-external-frame" title="${escapeHTML(title)}" allow="fullscreen *; autoplay; clipboard-read; clipboard-write" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>
      <canvas id="pdfCanvas" aria-label="${escapeHTML(title)}"></canvas>
    </section>

    <footer class="reader-bottom">
      <div class="reader-controls">
        <div class="reader-primary">
          <button class="icon-btn" id="prev" disabled aria-label="${L.previous}"><i class="fa-solid ${prevIcon}"></i></button>
          <span id="pageInfo" aria-live="polite">—</span>
          <button class="icon-btn" id="next" disabled aria-label="${L.next}"><i class="fa-solid ${nextIcon}"></i></button>
        </div>
      </div>
    </footer>
  </main>`;

  const $r=s=>app.querySelector(s), shellEl=app.querySelector(".reader-shell"),
    body=$r("#readerBody"), loading=$r("#readerLoading"), canvas=$r("#pdfCanvas"),
    externalFrame=$r("#readerExternalFrame"), useAlternate=$r("#readerUseAlternate"),
    bottom=$r(".reader-bottom"), moreBtn=$r("#more"), moreMenu=$r("#readerMoreMenu");

  canvas.hidden=true;
  externalFrame.hidden=false;
  loading.hidden=false;
  body.classList.add("external-mode");
  body.classList.remove("reader-ready");
  bottom.hidden=true;

  const readerSource=readerSourceForBook(b);
  const openGateway=()=>window.open(pdfGatewayUrl(id), "_blank", "noopener,noreferrer");
  const openCachedPdf=async()=>{
    const cached=await getCachedPdf(id);
    if(!cached?.blob) return false;
    try{
      cachedObjectUrl=URL.createObjectURL(cached.blob);
      readerMode="pdfjs";
      activePdfSource=cachedObjectUrl;
      clearExternalTimers();
      syncReaderMenu();
      externalFrame.hidden=true;
      externalFrame.src="about:blank";
      body.classList.remove("external-mode");
      bottom.hidden=false;
      canvas.hidden=true;
      loading.hidden=false;
      loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
      await loadPdf();
      return true;
    }catch(error){
      try{URL.revokeObjectURL(cachedObjectUrl);}catch{}
      cachedObjectUrl=null;
      console.warn("KR Urdu Library cached PDF load failed",error);
      return false;
    }
  };
  const openSource=()=>{
    const url=b.source?.pageUrl || b.pdfUrl || readerSource?.url;
    if(url)openExternal(url);
  };

  const saveProgress=()=>{
    if(!pdf?.numPages)return;
    setProgress(id,{
      page:currentPage,totalPages:pdf.numPages,
      percent:Math.round(currentPage/pdf.numPages*100)
    });
    lastSavedPage=currentPage;
  };

  const closeMore=()=>{
    moreMenu.hidden=true;
    moreBtn.setAttribute("aria-expanded","false");
  };
  const toggleMore=()=>{
    const open=moreMenu.hidden;
    moreMenu.hidden=!open;
    moreBtn.setAttribute("aria-expanded",String(open));
    if(open) moreMenu.querySelector("button")?.focus();
  };

  let externalLoaded=false, externalHintTimer=null, readerMode="external";

  const clearExternalTimers=()=>{
    clearTimeout(externalHintTimer);
    externalHintTimer=null;
  };

  const syncReaderMenu=()=>{
    for(const action of ['jump','zoomOut','zoomIn']){
      const item=moreMenu.querySelector(`[data-action="${action}"]`);
      if(item)item.hidden=readerMode!=="pdfjs";
    }
    const alternateItem=moreMenu.querySelector('[data-action="alternate"]');
    if(alternateItem) alternateItem.hidden=readerMode!=="external";
  };

  const showExternalHint=()=>{
    if(destroyed || readerMode!=="external" || externalLoaded)return;
    const hint=$r("#readerViewerHint");
    if(hint)hint.textContent=labels.readerViewerHint;
  };

  const switchToPdfJs=()=>{
    if(destroyed || readerMode==="pdfjs")return;
    readerMode="pdfjs";
    activePdfSource=pdfGatewayUrl(id);
    clearExternalTimers();
    syncReaderMenu();
    externalFrame.hidden=true;
    externalFrame.src="about:blank";
    body.classList.remove("external-mode");
    bottom.hidden=false;
    canvas.hidden=true;
    loading.hidden=false;
    loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
    loadPdf();
  };

  useAlternate.addEventListener("click",switchToPdfJs);
  externalFrame.addEventListener("load",()=>{
    if(destroyed || readerMode!=="external")return;
    externalLoaded=true;
    clearTimeout(externalHintTimer);
    // Cross-origin iframe load only proves that the embedded document loaded;
    // it cannot prove that the Archive/Drive viewer successfully rendered the PDF.
    // Keep the alternate-reader action available in the More menu for the full
    // lifetime of the external reader instead of treating load as a health check.
    loading.hidden=true;
    body.classList.add("reader-ready");
    syncReaderMenu();
  });
  externalFrame.addEventListener("error",()=>switchToPdfJs());

  const startExternalReader=()=>{
    readerMode="external";
    syncReaderMenu();
    externalLoaded=false;
    clearExternalTimers();
    body.classList.add("external-mode");
    bottom.hidden=true;
    canvas.hidden=true;
    externalFrame.hidden=false;
    loading.hidden=false;
    if(!readerSource){
      switchToPdfJs();
      return;
    }
    externalFrame.src=readerSource.url;
    const sourceLabel=readerSource.kind==='archive'
      ? (lang==='ur'?'Archive.org ka embedded reader':'Archive.org embedded reader')
      : readerSource.kind==='drive'
        ? (lang==='ur'?'Google Drive viewer':'Google Drive viewer')
        : (lang==='ur'?'External PDF viewer':'External PDF viewer');
    const hint=$r("#readerViewerHint");
    if(hint)hint.textContent=sourceLabel;
    // The embedded viewer is the primary reader. Cross-origin iframe load
    // cannot be inspected from the parent page, so a timeout must never
    // replace a working embedded viewer with PDF.js. PDF.js remains an
    // explicit/manual alternate reader (or a true iframe error fallback).
    externalHintTimer=setTimeout(showExternalHint,5000);
  };

  const showLoading=(message, actions=false)=>{
    loading.hidden=false;
    body.setAttribute("aria-busy","false");
    loading.innerHTML=`<i class="fa-solid fa-triangle-exclamation"></i>
      <strong>${escapeHTML(message)}</strong>
      <small>${lang==="ur"?"انٹرنیٹ کنکشن چیک کریں یا دوبارہ کوشش کریں۔":"Check your connection or try again."}</small>
      ${actions?`<div class="detail-actions">
        <button class="btn primary" id="readerRetry">${L.retry}</button>
        <button class="btn" id="readerOpenPdf">${labels.openPdf}</button>
      </div>`:""}`;
    $r("#readerRetry")?.addEventListener("click",()=>{
      canvas.hidden=true; body.classList.remove("reader-ready");
      loading.hidden=false;
      loading.innerHTML=`<i class="fa-solid fa-spinner fa-spin"></i><span>${labels.loading}</span>`;
      loadPdf();
    });
    $r("#readerOpenPdf")?.addEventListener("click",openGateway);
  };

  const openJumpDialog=()=>{
    closeMore();
    const old=document.querySelector(".reader-jump-backdrop");
    old?.remove();

    const backdrop=document.createElement("div");
    backdrop.className="modal-backdrop reader-jump-backdrop";
    backdrop.innerHTML=`<section class="modal reader-jump-dialog" role="dialog" aria-modal="true" aria-labelledby="readerJumpTitle">
      <h2 id="readerJumpTitle">${labels.jump}</h2>
      <p>${labels.page} <span id="readerJumpTotal">${pdf?.numPages||"—"}</span> ${labels.of}</p>
      <input id="readerJumpInput" class="search-box" type="number" inputmode="numeric" min="1" max="${pdf?.numPages||1}" value="${currentPage}" aria-label="${labels.jump}">
      <small class="reader-jump-error" id="readerJumpError" hidden>${labels.invalid}</small>
      <div class="modal-actions">
        <button class="btn" id="readerJumpCancel">${labels.close}</button>
        <button class="btn primary" id="readerJumpGo">${labels.go}</button>
      </div>
    </section>`;
    document.body.appendChild(backdrop);

    const input=backdrop.querySelector("#readerJumpInput");
    const error=backdrop.querySelector("#readerJumpError");
    const finish=()=>backdrop.remove();
    const go=async()=>{
      const n=Number(input.value);
      if(!pdf || !Number.isInteger(n) || n<1 || n>pdf.numPages){
        error.hidden=false; input.focus(); return;
      }
      finish();
      currentPage=n;
      await renderPage();
      body.scrollTo({top:0,behavior:"smooth"});
    };
    backdrop.querySelector("#readerJumpCancel").onclick=finish;
    backdrop.querySelector("#readerJumpGo").onclick=go;
    backdrop.addEventListener("click",e=>{if(e.target===backdrop)finish();});
    input.addEventListener("keydown",e=>{if(e.key==="Enter")go(); if(e.key==="Escape")finish();});
    input.addEventListener("input",()=>error.hidden=true);
    requestAnimationFrame(()=>{input.focus();input.select();});
  };

  $r("#back").onclick=()=>{
    closeMore(); saveProgress();
    history.back();
  };

  moreBtn.onclick=(e)=>{e.stopPropagation();toggleMore();};

  moreMenu.addEventListener("click",async e=>{
    const item=e.target.closest("[data-action]");
    if(!item)return;
    const action=item.dataset.action;
    if(action==="download"){
      closeMore();
      await downloadBookPdf(b);
    } else if(action==="jump") {
      closeMore();
      if(readerMode==="pdfjs") openJumpDialog();
    }
    else if(action==="source") openSource();
    else if(action==="alternate") { closeMore(); switchToPdfJs(); return; }
    else if(action==="details"){ closeMore(); saveProgress(); history.back(); return; }
    else if(action==="zoomIn"){
      closeMore();
      if(pdf&&!rendering){fitToWidth=false;scale=Math.min(3,Math.round((scale+.2)*10)/10);await renderPage();}
    } else if(action==="zoomOut"){
      closeMore();
      if(pdf&&!rendering){fitToWidth=false;scale=Math.max(.5,Math.round((scale-.2)*10)/10);await renderPage();}
    } else if(action==="fullscreen"){
      closeMore();
      const fallbackActive=shellEl.classList.contains("reader-fullscreen-fallback");
      if(document.fullscreenElement || fallbackActive){
        try{if(document.fullscreenElement) await document.exitFullscreen?.();}catch{}
        shellEl.classList.remove("reader-fullscreen-fallback");
        document.documentElement.classList.remove("reader-fullscreen-fallback-active");
        document.body.classList.remove("reader-fullscreen-fallback-active");
        onFullscreen();
        return;
      }
      try{
        if(typeof shellEl.requestFullscreen!=="function") throw new Error("Fullscreen API unavailable");
        await shellEl.requestFullscreen();
      }catch{
        shellEl.classList.add("reader-fullscreen-fallback");
        document.documentElement.classList.add("reader-fullscreen-fallback-active");
        document.body.classList.add("reader-fullscreen-fallback-active");
        onFullscreen();
      }
    }
  });

  const onOutside=e=>{
    if(!e.target.closest(".reader-more-wrap"))closeMore();
  };
  document.addEventListener("click",onOutside);

  async function renderPage(){
    if(!pdf || destroyed || rendering)return;
    rendering=true;
    let page=null;
    try{
      currentPage=Math.min(pdf.numPages,Math.max(1,currentPage));
      page=await pdf.getPage(currentPage);
      if(destroyed)return;

      let viewport=page.getViewport({scale:1});
      if(fitToWidth){
        const available=Math.max(260,body.clientWidth-20);
        scale=Math.min(3,Math.max(.5,available/viewport.width));
        body.classList.add("fit-width");
      }else{
        body.classList.remove("fit-width");
      }

      viewport=page.getViewport({scale});
      const ctx=canvas.getContext("2d",{alpha:false});
      canvas.width=Math.ceil(viewport.width);
      canvas.height=Math.ceil(viewport.height);
      canvas.style.width=`${Math.ceil(viewport.width)}px`;
      canvas.style.height=`${Math.ceil(viewport.height)}px`;

      await page.render({canvasContext:ctx,viewport}).promise;
      if(destroyed)return;

      $r("#pageInfo").textContent=`${currentPage} / ${pdf.numPages}`;
      $r("#pageInfo").setAttribute("aria-label", lang==="ur" ? `${labels.page} ${currentPage} ${labels.of} ${pdf.numPages}` : `${labels.page} ${currentPage} ${labels.of} ${pdf.numPages}`);
      $r("#prev").disabled=currentPage<=1;
      $r("#next").disabled=currentPage>=pdf.numPages;
      setProgress(id,{page:currentPage,totalPages:pdf.numPages,percent:Math.round(currentPage/pdf.numPages*100)});
      lastSavedPage=currentPage;

      canvas.hidden=false;
      body.classList.add("reader-ready");
      body.setAttribute("aria-busy","false");
      loading.hidden=true;
    }catch(err){
      canvas.hidden=true;
      body.classList.remove("reader-ready");
      if(!destroyed)showLoading(L.readerPageError,false);
    }finally{
      try{page?.cleanup?.();}catch{}
      rendering=false;
    }
  }

  const go=async delta=>{
    if(!pdf||rendering)return;
    const next=Math.min(pdf.numPages,Math.max(1,currentPage+delta));
    if(next!==currentPage){currentPage=next;await renderPage();}
  };

  $r("#prev").onclick=()=>go(-1);
  $r("#next").onclick=()=>go(1);

  let touchX=0,touchY=0,touchMoved=false;
  body.addEventListener("click",e=>{
    if(e.target.closest("button")||touchMoved){touchMoved=false;return;}
    controlsHidden=!controlsHidden;
    shellEl.classList.toggle("controls-hidden",controlsHidden);
  });

  body.addEventListener("dblclick",async e=>{
    if(e.target.closest("button")||!pdf||rendering)return;
    fitToWidth=false;
    scale=scale<1.5?1.6:1;
    await renderPage();
  });

  body.addEventListener("touchstart",e=>{
    const t=e.changedTouches[0];touchX=t.clientX;touchY=t.clientY;touchMoved=false;
  },{passive:true});

  body.addEventListener("touchmove",e=>{
    const t=e.changedTouches[0];
    if(Math.abs(t.clientX-touchX)>12||Math.abs(t.clientY-touchY)>12)touchMoved=true;
  },{passive:true});

  body.addEventListener("touchend",e=>{
    const t=e.changedTouches[0],dx=t.clientX-touchX,dy=t.clientY-touchY;
    if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.25&&!rendering){
      touchMoved=true;
      if((lang==="ur"&&dx>0)||(lang!=="ur"&&dx<0))go(1);else go(-1);
    }
  },{passive:true});

  const onResize=()=>{
    clearTimeout(resizeTimer);
    resizeTimer=setTimeout(()=>{if(pdf&&!destroyed&&fitToWidth)renderPage();},160);
  };
  window.addEventListener("resize",onResize,{passive:true});

  const onFullscreen=()=>{
    const active=Boolean(document.fullscreenElement) || shellEl.classList.contains("reader-fullscreen-fallback");
    const item=moreMenu.querySelector('[data-action="fullscreen"]');
    if(item)item.querySelector("span").textContent=active
      ? (lang==="ur"?"اسکرین سے باہر":"Exit fullscreen")
      : labels.fullscreen;
    const icon=item?.querySelector("i");
    if(icon)icon.className=`fa-solid ${active?"fa-compress":"fa-expand"}`;
  };
  document.addEventListener("fullscreenchange",onFullscreen);

  const onVisibility=()=>{if(document.visibilityState!=="visible")saveProgress();};
  const onPageHide=()=>saveProgress();
  document.addEventListener("visibilitychange",onVisibility);
  window.addEventListener("pagehide",onPageHide);

  const onKey=async e=>{
    if(state.route!=="reader"){cleanup();return;}
    if(e.key==="Escape"&&!moreMenu.hidden){closeMore();return;}
    if(e.key==="Escape"&&shellEl.classList.contains("reader-fullscreen-fallback")){
      shellEl.classList.remove("reader-fullscreen-fallback");
      document.documentElement.classList.remove("reader-fullscreen-fallback-active");
      document.body.classList.remove("reader-fullscreen-fallback-active");
      onFullscreen();
      return;
    }
    if(e.key==="Escape"&&controlsHidden){controlsHidden=false;shellEl.classList.remove("controls-hidden");return;}
    if(["ArrowRight","ArrowLeft","PageDown","PageUp","+","-","="].includes(e.key))e.preventDefault();
    if(e.key==="ArrowRight")await go(lang==="ur"?-1:1);
    else if(e.key==="ArrowLeft")await go(lang==="ur"?1:-1);
    else if(e.key==="PageDown")await go(1);
    else if(e.key==="PageUp")await go(-1);
    else if(e.key==="+"||e.key==="="){
      fitToWidth=false;
      if(!rendering){scale=Math.min(3,Math.round((scale+.2)*10)/10);await renderPage();}
    }else if(e.key==="-"){
      fitToWidth=false;
      if(!rendering){scale=Math.max(.5,Math.round((scale-.2)*10)/10);await renderPage();}
    }
  };

  const cleanup=()=>{
    destroyed=true;saveProgress();clearTimeout(resizeTimer);
    if(cachedObjectUrl){ try{URL.revokeObjectURL(cachedObjectUrl);}catch{} cachedObjectUrl=null; }
    window.removeEventListener("resize",onResize);
    document.removeEventListener("keydown",onKey);
    document.removeEventListener("fullscreenchange",onFullscreen);
    document.removeEventListener("visibilitychange",onVisibility);
    document.removeEventListener("click",onOutside);
    window.removeEventListener("pagehide",onPageHide);
    clearExternalTimers();
    try{if(document.fullscreenElement) document.exitFullscreen?.();}catch{}
    shellEl.classList.remove("reader-fullscreen-fallback");
    document.documentElement.classList.remove("reader-fullscreen-fallback-active");
    document.body.classList.remove("reader-fullscreen-fallback-active");
    try{externalFrame.src="about:blank";}catch{}
    try{loadingTask?.destroy?.();}catch{}
    try{pdf?.destroy?.();}catch{}
    try{networkMonitor?.log?.();networkMonitor?.restore?.();}catch{}
    networkMonitor=null;
  };

  readerCleanup=cleanup;
  document.addEventListener("keydown",onKey);

  const isReaderAbortError=(err)=>{
    const name=String(err?.name||"").toLowerCase();
    const message=String(err?.message||err||"").toLowerCase();
    return name==="aborterror" || name==="abortexception" || message.includes("aborted") || message.includes("abort");
  };

  async function loadPdf(attempt=0){
    if(destroyed || readerMode!=="pdfjs")return;
    loading.hidden=false;canvas.hidden=true;body.classList.remove("reader-ready"); body.setAttribute("aria-busy","true");
    try{
      if(pdf){try{pdf.destroy?.();}catch{}pdf=null;}
      const pdfjs=await loadReaderPdfJs();
      if(destroyed)return;
      activePdfSource=activePdfSource || pdfGatewayUrl(id);
      networkMonitor?.restore?.();
      networkMonitor=createReaderNetworkMonitor({bookId:id,gatewayUrl:pdfGatewayUrl(id),debug:networkDebug});
      loadingTask=pdfjs.getDocument({
        url:activePdfSource,
        disableStream:true,
        disableAutoFetch:true,
        disableRange:false,
        // Keep the fallback reader demand-driven. Do not add a custom byte-range
        // cache here: PDF.js/browser HTTP caching remains the source of truth.
        rangeChunkSize:131072
      });
      // PDF.js intentionally aborts an initial streaming/probe request when
      // range loading is available and streaming is disabled. Treat that
      // AbortError as recoverable rather than surfacing it as a reader failure.
      loadingTask.onProgress=({loaded,total})=>{
        networkMonitor?.recordProgress?.(loaded,total);
        // PDF.js reports progress in range/chunk units. With a 128 KiB
        // range size, the cumulative loaded value can legitimately round
        // above the exact file length on the final chunk. It is a measurement
        // signal, not proof that extra bytes were downloaded, so do not emit
        // a false "exceeded advertised size" error. Actual network bytes are
        // measured separately by the reader network monitor.
      };
      try{
        pdf=await loadingTask.promise;
      }catch(err){
        const message=String(err?.message||err||"");
        if(isReaderAbortError(err)){
          // Some PDF.js/browser combinations surface the intentional probe
          // cancellation through loadingTask.promise. Retry once with a fresh
          // task so the real byte-range requests can proceed.
          loadingTask=null;
          if(attempt<1 && !destroyed){
            await new Promise(resolve=>setTimeout(resolve,120));
            return loadPdf(attempt+1);
          }
          if(destroyed)return;
        }
        if(/range|partial|content-range|byte/i.test(message)){
          showLoading(lang==="ur"
            ? "PDF ka range data source se theek nahi mila. Dobara koshish karein ya PDF download karein."
            : "The PDF source did not provide a valid byte-range response. Please retry or download the PDF.",true);
        }
        throw err;
      }
      loadingTask=null;
      if(destroyed){pdf.destroy?.();return;}
      if(!b.pages||Number(b.pages)!==pdf.numPages)b.pages=pdf.numPages;
      currentPage=Math.min(pdf.numPages,Math.max(1,currentPage));
      await renderPage();
    }catch(err){
      loadingTask=null;
      if(isReaderAbortError(err)){
        // Abort during reader startup is a recoverable cancellation, not a
        // useful console error. The retry above handles the first occurrence.
        if(!destroyed)showLoading(L.readerLoadError,true);
        return;
      }
      console.error("KR Urdu Library PDF load failed",{bookId:id,error:err});
      if(!destroyed)showLoading(L.readerLoadError,true);
    }
  }

  // Always prefer the source's native embedded viewer when a source exists.
  // Browser/WebView online state can be stale, and forcing cached PDF.js here
  // can make a valid Archive.org/Drive embed appear to be unavailable.
  // Cache/PDF.js remains the offline recovery path when there is no network.
  if(typeof navigator !== "undefined" && navigator.onLine === false && !readerSource){
    openCachedPdf().then(ok=>{ if(!ok && !destroyed) showLoading(L.readerLoadError,true); });
  } else if(readerSource){
    startExternalReader();
  } else {
    openCachedPdf().then(ok=>{ if(!ok && !destroyed) switchToPdfJs(); });
  }
}

function render(){document.querySelector(".fv-undo")?.remove();cleanupLocalReader();cleanupLibrary();setDirection();applyTheme(state.theme);const r=readRoute();state.prevRoute=state.shownRoute;state.shownRoute=r.route;state.route=r.route;state.params=r.params;switch(r.route){case"home":renderHome();break;case"catalogue":renderClass(null,true);break;case"classes":renderClasses();break;case"class":renderClass(r.params.id);break;case"categories":renderCategories();break;case"category":renderCategory(r.params.id);break;case"favorites":renderFavorites();break;case"search":renderSearch(r.params.q||"");break;case"book":renderBook(r.params.id);break;case"reader":renderReader(r.params.id);break;case"downloads":renderDownloads();break;case"local":renderLocal(r.params);break;case"more":renderMore();break;default:navigate("home",{}, {replace:true});}}
let lastRenderedRoute = "";
async function renderRouteOnce(){
  const raw = location.hash || "#home";
  if(raw === lastRenderedRoute) return;
  lastRenderedRoute = raw;
  const routeName = raw.slice(1).split('?')[0];
  const needsCompleteCatalogue = ['catalogue','classes','class','categories','category','favorites','book','reader'].includes(routeName);
  if(needsCompleteCatalogue) {
    try { await ensureAllBooksLoaded(); } catch(error) { console.error('KR Urdu Library catalogue load failed', error); }
  }
  // Read the saved scroll position BEFORE building the screen: building it changes the page height,
  // which fires scroll events that would otherwise overwrite the saved value with 0.
  const savedY = Math.max(0, Number(history.state?.scrollY) || 0);
  if(routeName !== "reader" && savedY > 0) lockScrollSave(true);
  render();
  // New routes start at the top; a Back/Forward navigation restores the scroll position saved on that
  // history entry. Screens fill in asynchronously, so keep trying until the page is tall enough.
  if(routeName !== "reader") restoreScroll(savedY); else lockScrollSave(false);
}
let scrollRestoreToken = 0;
function restoreScroll(y){
  const token = ++scrollRestoreToken;
  if(!(y > 0)){ lockScrollSave(false); window.scrollTo({ top: 0, left: 0, behavior: "auto" }); return; }
  let stop = false;
  const halt = () => { stop = true; };
  ["touchstart","wheel","keydown","mousedown"].forEach(ev => window.addEventListener(ev, halt, { once: true, passive: true }));
  const delays = [0, 60, 150, 300, 500, 800, 1200, 1800, 2600];
  const step = i => {
    if(token !== scrollRestoreToken) return;
    if(stop || i >= delays.length){ lockScrollSave(false); return; }
    setTimeout(() => {
      if(token !== scrollRestoreToken) return;
      if(stop){ lockScrollSave(false); return; }
      const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      window.scrollTo({ top: Math.min(y, max), left: 0, behavior: "auto" });
      if(max >= y - 1 && Math.abs(window.scrollY - y) <= 2){ lockScrollSave(false); history.replaceState({ ...history.state, scrollY: Math.round(window.scrollY) }, ""); return; }
      step(i + 1);
    }, delays[i]);
  };
  requestAnimationFrame(() => step(0));
}
window.addEventListener("popstate",e=>{
  const route=readRoute().route;
  const openPanel=document.querySelector(".class-search-panel.is-open");
  if((route==="class"||route==="catalogue") && openPanel && !e.state?.classSearchOpen){
    window.__krClassSearchClose?.();
    return;
  }
  const openCategoryPanel=document.querySelector(".category-topbar .class-search-panel.is-open");
  if(route==="category" && openCategoryPanel && !e.state?.categorySearchOpen){
    window.__krCategorySearchClose?.();
    return;
  }
  window.__krClassSearchClose=null;
  window.__krCategorySearchClose=null;
  renderRouteOnce();
});
window.addEventListener("hashchange",()=>{ syncHashNavigation(); renderRouteOnce(); });
window.addEventListener("DOMContentLoaded",watchSystemTheme);
window.addEventListener("offline",()=>announceNetworkStatus("offline"));
window.addEventListener("online",()=>announceNetworkStatus("online"));
function renderBootError(err){
  const ur=currentLang()==="ur";
  app.innerHTML=`<main class="load-error" role="alert"><div class="le-ico"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <h1>${ur?"لائبریری لوڈ نہیں ہو سکی":"Couldn't load the library"}</h1>
    <p>${ur?"انٹرنیٹ کنکشن چیک کریں اور دوبارہ کوشش کریں۔ پہلے سے محفوظ شدہ کتب آف لائن بھی کھل جاتی ہیں۔":"Check your connection and try again. Books you saved for offline reading still open without internet."}</p>
    <div class="le-actions"><button class="primary" id="bootRetry" type="button">${ur?"دوبارہ کوشش کریں":"Try again"}</button><button id="bootDownloads" type="button">${ur?"محفوظ شدہ کتب":"Saved books"}</button></div>
    <details><summary>Details</summary>${escapeHTML(String(err&&err.message||err||""))}</details></main>`;
  app.querySelector("#bootRetry").onclick=()=>location.reload();
  app.querySelector("#bootDownloads").onclick=()=>{ location.hash="#downloads"; location.reload(); };
}
(async function init(){try{watchInsets();ensureAppHistory();installPullToRefresh();watchNativePtr(()=>readRoute().route);data=await loadLibraryData();state.dataReady=true;updateNetworkStatus(null);lastRenderedRoute = "";renderRouteOnce();checkPendingOpen();}catch(err){console.error("KR Urdu Library failed to start",err);renderBootError(err);}})();
