package com.kr.urdulibrary;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * The annotate toolbar at the bottom of the reader: tool, colour, thickness, opacity, shape, snap, undo / redo.
 * It only edits the MuInk settings; the activity reacts through Cb. Add new tools (sticker, note pin) as new chips here.
 */
final class MuDock extends LinearLayout {
    interface Cb {
        void onTool(int tool);
        void onChanged();
        void onUndo();
        void onRedo();
        void onDone();
    }

    interface Str { String s(String key); }

    private final MuInk ink;
    private final Cb cb;
    private final Str str;
    private final float d;
    private int bg = 0xFFFFFFFF, fg = 0xFF1C2420, sub = 0xFF6B7770, chip = 0xFFEDEDE8, accent = 0xFF176B4D;

    private final LinearLayout toolRow, optBox;
    private final TextView[] toolChip = new TextView[3];
    private final MuReaderActivity.IconView undoBtn, redoBtn, doneBtn;
    private final LinearLayout colorRow;
    private final MuReaderActivity.Swatch[] sw = new MuReaderActivity.Swatch[MuAnnot.FILL.length];
    private final SeekBar thick, opac;
    private final Preview preview;
    private final TextView thickLbl, opacLbl;
    private final TextView[] shapeChip = new TextView[3];
    private final TextView snapChip, tipChip;
    private final View shapeRow, snapRow;
    private boolean optsShown = true;
    private boolean quiet = false;

    MuDock(Context c, MuInk ink, Cb cb, Str str) {
        super(c);
        this.ink = ink; this.cb = cb; this.str = str;
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setClickable(true);
        setElevation(dp(12));
        setPadding(dp(12), dp(10), dp(12), dp(10));

        // ---- row 1: tools + undo / redo / done
        toolRow = new LinearLayout(c);
        toolRow.setOrientation(HORIZONTAL);
        toolRow.setGravity(Gravity.CENTER_VERTICAL);
        final int[] icons = {MuReaderActivity.IconView.MARKER, MuReaderActivity.IconView.PEN, MuReaderActivity.IconView.ERASER};
        final String[] keys = {"tool_marker", "tool_pen", "tool_eraser"};
        for (int i = 0; i < 3; i++) {
            final int tool = i + 1;
            TextView t = new TextView(c);
            t.setText(str.s(keys[i]));
            t.setTextSize(12.5f);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setGravity(Gravity.CENTER);
            t.setSingleLine(true);
            t.setPadding(dp(11), 0, dp(11), 0);
            t.setOnClickListener(v -> {
                if (ink.tool == tool) { optsShown = !optsShown; refresh(); }
                else { optsShown = true; ink.tool = tool; cb.onTool(tool); refresh(); }
            });
            toolChip[i] = t;
            LayoutParams lp = new LayoutParams(-2, dp(38));
            lp.setMarginEnd(dp(6));
            toolRow.addView(t, lp);
        }
        View grow = new View(c);
        toolRow.addView(grow, new LayoutParams(0, 1, 1f));
        undoBtn = icon(c, MuReaderActivity.IconView.UNDO, str.s("undo"));
        undoBtn.setOnClickListener(v -> cb.onUndo());
        redoBtn = icon(c, MuReaderActivity.IconView.REDO, str.s("redo"));
        redoBtn.setOnClickListener(v -> cb.onRedo());
        doneBtn = icon(c, MuReaderActivity.IconView.CHECK, str.s("done"));
        doneBtn.setOnClickListener(v -> cb.onDone());
        toolRow.addView(undoBtn, new LayoutParams(dp(40), dp(40)));
        toolRow.addView(redoBtn, new LayoutParams(dp(40), dp(40)));
        toolRow.addView(doneBtn, new LayoutParams(dp(44), dp(40)));
        addView(toolRow, new LayoutParams(-1, -2));

        // ---- options (hidden for the eraser, or when collapsed)
        optBox = new LinearLayout(c);
        optBox.setOrientation(VERTICAL);
        addView(optBox, new LayoutParams(-1, -2));

        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        colorRow = new LinearLayout(c);
        colorRow.setOrientation(HORIZONTAL);
        colorRow.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < sw.length; i++) {
            final int ci = i;
            sw[i] = new MuReaderActivity.Swatch(c, MuAnnot.INK[i], false);
            sw[i].setOnClickListener(v -> { ink.color = ci; syncSwatches(); cb.onChanged(); invalidatePreview(); });
            LayoutParams lp = new LayoutParams(dp(38), dp(38));
            colorRow.addView(sw[i], lp);
        }
        hs.addView(colorRow, new ViewGroup.LayoutParams(-2, -2));
        LayoutParams hlp = new LayoutParams(-1, dp(42));
        hlp.topMargin = dp(8);
        optBox.addView(hs, hlp);

        thickLbl = label(c, str.s("thick"));
        thick = seek(c);
        thick.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (quiet || !user) return;
                float t = p / 100f;
                ink.setWidth(MuInk.MIN_W + t * t * (MuInk.MAX_W - MuInk.MIN_W));
                invalidatePreview(); cb.onChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        preview = new Preview(c);
        LinearLayout r1 = new LinearLayout(c);
        r1.setOrientation(HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        r1.addView(thickLbl, new LayoutParams(dp(74), -2));
        r1.addView(thick, new LayoutParams(0, dp(34), 1f));
        LayoutParams plp = new LayoutParams(dp(52), dp(30));
        plp.setMarginStart(dp(10));
        r1.addView(preview, plp);
        optBox.addView(r1, new LayoutParams(-1, dp(38)));

        opacLbl = label(c, str.s("opacity"));
        opac = seek(c);
        opac.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (quiet || !user) return;
                ink.setAlpha(15 + Math.round(p * 0.85f));
                invalidatePreview(); cb.onChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        LinearLayout r2 = new LinearLayout(c);
        r2.setOrientation(HORIZONTAL);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        r2.addView(opacLbl, new LayoutParams(dp(74), -2));
        r2.addView(opac, new LayoutParams(0, dp(34), 1f));
        optBox.addView(r2, new LayoutParams(-1, dp(38)));

        LinearLayout sr = new LinearLayout(c);
        sr.setOrientation(HORIZONTAL);
        sr.setGravity(Gravity.CENTER_VERTICAL);
        final String[] sk = {"shape_free", "shape_line", "shape_box"};
        for (int i = 0; i < 3; i++) {
            final int shape = i;
            TextView t = pill(c, str.s(sk[i]));
            t.setOnClickListener(v -> { ink.shape = shape; refresh(); cb.onChanged(); });
            shapeChip[i] = t;
            LayoutParams lp = new LayoutParams(-2, dp(34));
            lp.setMarginEnd(dp(6));
            sr.addView(t, lp);
        }
        shapeRow = sr;
        LayoutParams srl = new LayoutParams(-1, dp(38));
        srl.topMargin = dp(4);
        optBox.addView(sr, srl);

        LinearLayout nr = new LinearLayout(c);
        nr.setOrientation(HORIZONTAL);
        nr.setGravity(Gravity.CENTER_VERTICAL);
        snapChip = pill(c, str.s("snap"));
        snapChip.setOnClickListener(v -> { ink.snap = !ink.snap; refresh(); cb.onChanged(); });
        tipChip = pill(c, str.s("tip_flat"));
        tipChip.setOnClickListener(v -> { ink.flat = !ink.flat; refresh(); cb.onChanged(); });
        LayoutParams l1 = new LayoutParams(-2, dp(34));
        l1.setMarginEnd(dp(6));
        nr.addView(snapChip, l1);
        nr.addView(tipChip, new LayoutParams(-2, dp(34)));
        snapRow = nr;
        LayoutParams nrl = new LayoutParams(-1, dp(38));
        nrl.topMargin = dp(2);
        optBox.addView(nr, nrl);

        refresh();
    }

    private int dp(float v) { return Math.round(v * d); }

    private void invalidatePreview() { if (preview != null) preview.invalidate(); }

    private MuReaderActivity.IconView icon(Context c, int kind, String desc) {
        MuReaderActivity.IconView v = new MuReaderActivity.IconView(c, kind);
        v.setScale(0.58f);
        v.setBackground(null);
        v.setContentDescription(desc);
        return v;
    }

    private TextView label(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(12f);
        v.setSingleLine(true);
        return v;
    }

    private TextView pill(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(12.5f);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setPadding(dp(13), 0, dp(13), 0);
        return v;
    }

    private SeekBar seek(Context c) {
        SeekBar s = new SeekBar(c);
        s.setMax(100);
        s.setPadding(dp(14), 0, dp(14), 0);
        return s;
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    // ------------------------------------------------------------------ public
    void restyle(int bg, int fg, int sub, int chip, int accent) {
        this.bg = bg; this.fg = fg; this.sub = sub; this.chip = chip; this.accent = accent;
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        float r = dp(24);
        g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        setBackground(g);
        refresh();
    }

    void setUndoState(boolean canUndo, boolean canRedo) {
        undoBtn.setAlpha(canUndo ? 1f : 0.3f);
        redoBtn.setAlpha(canRedo ? 1f : 0.3f);
        undoBtn.setEnabled(canUndo);
        redoBtn.setEnabled(canRedo);
    }

    /** Re-reads everything from the MuInk settings. */
    void refresh() {
        quiet = true;
        boolean eraser = ink.tool == MuInk.ERASER;
        for (int i = 0; i < 3; i++) {
            boolean on = ink.tool == i + 1;
            toolChip[i].setBackground(round(on ? accent : chip, 19));
            toolChip[i].setTextColor(on ? 0xFFFFFFFF : fg);
        }
        undoBtn.setColor(fg); redoBtn.setColor(fg); doneBtn.setColor(accent);
        optBox.setVisibility(eraser || !optsShown ? GONE : VISIBLE);
        boolean marker = ink.tool == MuInk.MARKER;
        int colors = marker ? MuAnnot.TEXT_COLORS : MuAnnot.FILL.length;
        if (ink.color >= colors) ink.color = 0;
        for (int i = 0; i < sw.length; i++) sw[i].setVisibility(i < colors ? VISIBLE : GONE);
        syncSwatches();
        thickLbl.setTextColor(sub); opacLbl.setTextColor(sub);
        tint(thick); tint(opac);
        float t = (ink.width() - MuInk.MIN_W) / (MuInk.MAX_W - MuInk.MIN_W);
        thick.setProgress(Math.round((float) Math.sqrt(Math.max(0f, Math.min(1f, t))) * 100f));
        opac.setProgress(Math.round((ink.alpha() - 15) / 0.85f));
        for (int i = 0; i < 3; i++) {
            boolean on = ink.shape == i;
            shapeChip[i].setBackground(round(on ? accent : chip, 17));
            shapeChip[i].setTextColor(on ? 0xFFFFFFFF : fg);
        }
        snapChip.setVisibility(marker && ink.shape != MuInk.BOX ? VISIBLE : GONE);
        tipChip.setVisibility(marker ? VISIBLE : GONE);
        snapChip.setBackground(round(ink.snap ? accent : chip, 17));
        snapChip.setTextColor(ink.snap ? 0xFFFFFFFF : fg);
        tipChip.setText(str.s(ink.flat ? "tip_flat" : "tip_round"));
        tipChip.setBackground(round(chip, 17));
        tipChip.setTextColor(fg);
        snapRow.setVisibility(marker ? VISIBLE : GONE);
        preview.invalidate();
        quiet = false;
    }

    private void tint(SeekBar s) {
        try {
            s.getProgressDrawable().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
            s.getThumb().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) { }
    }

    private void syncSwatches() {
        for (int i = 0; i < sw.length; i++) sw[i].setOn(i == ink.color);
    }

    /** Live sample of the current stroke: real thickness relative to the page width. */
    private final class Preview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Preview(Context c) { super(c); }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            r.set(0, 0, w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(chip);
            cv.drawRoundRect(r, dp(10), dp(10), p);
            float screen = getResources().getDisplayMetrics().widthPixels;
            float th = Math.max(dp(1.5f), Math.min(h - dp(4), ink.width() * screen));
            int base = ink.tool == MuInk.MARKER ? MuAnnot.FILL[Math.min(ink.color, MuAnnot.FILL.length - 1)] : MuAnnot.INK[Math.min(ink.color, MuAnnot.INK.length - 1)];
            p.setColor(MuAnnot.alphaOf(base, ink.alpha()));
            float x0 = dp(9), x1 = w - dp(9), cy = h / 2f;
            if (ink.tool == MuInk.MARKER && ink.flat) {
                r.set(x0, cy - th / 2f, x1, cy + th / 2f);
                cv.drawRect(r, p);
            } else {
                r.set(x0, cy - th / 2f, x1, cy + th / 2f);
                cv.drawRoundRect(r, th / 2f, th / 2f, p);
            }
        }
    }
}
