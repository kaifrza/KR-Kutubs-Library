// Archive.org search for books that are NOT in the Maktabah library.
//
// Archive results are kept in a small SEPARATE registry (memory + localStorage). They are never
// merged into the Supabase library cache, so the real catalogue stays clean.
//
// An archive book looks like a normal book object (so bookCard / book detail / reader work
// unchanged) with:  id = "ia:<identifier>", isArchive = true, source.pageUrl = details page.
// The existing readerSourceForBook() already turns that page URL into archive.org/embed/<id>.
// The direct PDF file name is resolved lazily (archive.org/metadata) only when the user
// taps Download, so searching stays fast.

import { getFavorites, getHistory } from "../utils/storage.js";

const ARCHIVE_PREFIX = "ia:";
const ADVANCED_SEARCH = "https://archive.org/advancedsearch.php";
const METADATA = "https://archive.org/metadata/";
const STORE_KEY = "kr-archive-books-v1";
const STORE_LIMIT = 300;
const REQUEST_TIMEOUT_MS = 12000;

const registry = new Map();
let loadedFromStorage = false;

export const isArchiveId = id => String(id || "").startsWith(ARCHIVE_PREFIX);
export const archiveIdentifier = id => String(id || "").slice(ARCHIVE_PREFIX.length);

function loadStore() {
  if (loadedFromStorage) return;
  loadedFromStorage = true;
  try {
    const list = JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
    if (Array.isArray(list)) list.forEach(b => { if (b?.id && isArchiveId(b.id) && !registry.has(b.id)) registry.set(b.id, b); });
  } catch { /* storage unavailable: memory only */ }
}

function saveStore() {
  // Favourites and reading history are pinned: they are never trimmed away, so a saved
  // Archive book always still has its title / cover / author after the app restarts.
  let pinnedIds;
  try { pinnedIds = new Set([...getFavorites(), ...getHistory()]); } catch { pinnedIds = new Set(); }
  const all = [...registry.values()];
  const pinned = all.filter(b => pinnedIds.has(b.id));
  const recent = all.filter(b => !pinnedIds.has(b.id)).slice(-STORE_LIMIT);
  for (const list of [[...pinned, ...recent], pinned]) {   // second try: pinned only, if storage is full
    try { localStorage.setItem(STORE_KEY, JSON.stringify(list)); return; } catch { /* try smaller */ }
  }
}

export function getArchiveBook(id) {
  if (!isArchiveId(id)) return null;
  loadStore();
  return registry.get(id) || null;
}

function remember(book) {
  loadStore();
  const previous = registry.get(book.id);
  // Keep an already-resolved PDF link when the same item shows up again.
  const merged = previous?.pdfUrl && !book.pdfUrl ? { ...book, pdfUrl: previous.pdfUrl } : book;
  registry.delete(book.id);       // re-insert so the newest are kept when trimming
  registry.set(book.id, merged);
  return merged;
}

const first = v => Array.isArray(v) ? first(v[0]) : v;
const text = v => {
  const x = Array.isArray(v) ? v.filter(Boolean).join("، ") : v;
  return String(x ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
};

export function archiveCoverUrl(identifier) {
  return `https://archive.org/services/img/${encodeURIComponent(identifier)}`;
}

function bookFromRecord(identifier, fields = {}) {
  const title = text(fields.title) || identifier;
  const pages = Number(first(fields.imagecount));
  return {
    id: ARCHIVE_PREFIX + identifier,
    title,
    titleEn: title,
    author: text(fields.creator),
    description: text(fields.description).slice(0, 1200),
    classId: "",
    classIds: [],
    bookType: "archive",
    pages: Number.isFinite(pages) && pages > 0 ? pages : null,
    cover: archiveCoverUrl(identifier),
    pdfUrl: "",                       // resolved lazily, see resolveArchivePdf()
    pdfSourceType: "archive",
    driveFileId: "",
    source: { name: "Internet Archive", pageUrl: `https://archive.org/details/${encodeURIComponent(identifier)}` },
    status: "available",
    keywords: [],
    categoryIds: [],
    isArchive: true,
    addedAt: "",
    createdAt: ""
  };
}

async function fetchJson(url, signal) {
  const controller = new AbortController();
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener("abort", () => controller.abort(), { once: true });
  }
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`Archive.org request failed (${res.status})`);
    return await res.json();
  } catch (error) {
    if (timedOut) throw new Error("Archive.org request timed out");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function buildQuery(query) {
  const clean = String(query || "").replace(/["\\()\[\]{}:^~*?!]/g, " ").replace(/\s+/g, " ").trim();
  if (!clean) return "";
  // Every word must match somewhere in title / author / subject / description.
  const tokens = clean.split(" ").filter(Boolean).slice(0, 8);
  const terms = tokens.map(t => `(title:(${t}) OR creator:(${t}) OR subject:(${t}) OR description:(${t}))`).join(" AND ");
  return `(${terms}) AND mediatype:(texts)`;
}

/**
 * One page of Archive.org results (books only). Resolves to { books, done, total }.
 * Pages start at 1.
 */
export async function searchArchive(query, { page = 1, rows = 20, signal } = {}) {
  const q = buildQuery(query);
  if (!q) return { books: [], done: true, total: 0 };
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    const error = new Error("Offline");
    error.code = "OFFLINE";
    throw error;
  }
  const params = new URLSearchParams();
  params.set("q", q);
  ["identifier", "title", "creator", "description", "imagecount"].forEach(f => params.append("fl[]", f));
  params.append("sort[]", "downloads desc");
  params.set("rows", String(rows));
  params.set("page", String(page));
  params.set("output", "json");

  const json = await fetchJson(`${ADVANCED_SEARCH}?${params}`, signal);
  const docs = json?.response?.docs || [];
  const total = Number(json?.response?.numFound) || 0;
  const books = docs
    .filter(d => d?.identifier)
    .map(d => remember(bookFromRecord(d.identifier, d)));
  saveStore();
  return { books, done: page * rows >= total || !docs.length, total };
}

/** Loads one item's details by identifier (used when a deep link / favourite is opened after a restart). */
export async function hydrateArchiveBook(id) {
  const existing = getArchiveBook(id);
  if (existing) return existing;
  if (!isArchiveId(id)) return null;
  const identifier = archiveIdentifier(id);
  const json = await fetchJson(`${METADATA}${encodeURIComponent(identifier)}`);
  if (!json?.metadata) return null;
  const book = remember(bookFromRecord(identifier, { ...json.metadata, imagecount: json.metadata.imagecount }));
  saveStore();
  return book;
}

function pickPdf(files = []) {
  const pdfs = files.filter(f => /\.pdf$/i.test(f?.name || "") && !/^__ia_thumb/i.test(f.name));
  if (!pdfs.length) return null;
  const score = f => {
    let s = 0;
    const format = String(f.format || "");
    if (/text pdf/i.test(format)) s += 4;          // searchable, usually smaller
    else if (/image container pdf/i.test(format)) s += 3;
    if (!/_text\.pdf$/i.test(f.name)) s += 2;      // "_text.pdf" is just an OCR dump
    if (!/\//.test(f.name)) s += 1;                // top-level file
    return s;
  };
  return pdfs.slice().sort((a, b) => score(b) - score(a) || (Number(b.size) || 0) - (Number(a.size) || 0))[0];
}

/**
 * Finds the direct PDF address of an archive book and stores it on the book (book.pdfUrl),
 * so the normal download flow can use it. Resolves to the URL, or null if the item has no PDF.
 */
export async function resolveArchivePdf(book) {
  if (!book?.isArchive) return book?.pdfUrl || null;
  if (book.pdfUrl) return book.pdfUrl;
  const identifier = archiveIdentifier(book.id);
  const json = await fetchJson(`${METADATA}${encodeURIComponent(identifier)}`);
  const file = pickPdf(json?.files);
  if (!file) return null;
  const path = String(file.name).split("/").map(encodeURIComponent).join("/");
  book.pdfUrl = `https://archive.org/download/${encodeURIComponent(identifier)}/${path}`;
  if (!book.pages && json?.metadata?.imagecount) book.pages = Number(json.metadata.imagecount) || null;
  remember(book);
  saveStore();
  return book.pdfUrl;
}
