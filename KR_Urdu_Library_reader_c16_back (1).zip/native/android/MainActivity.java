package com.kr.urdulibrary;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    // Must match --bg in css/variables.css
    static final int BG_LIGHT = Color.parseColor("#f7f7f5");
    static final int BG_DARK = Color.parseColor("#101512");

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(KRDownloaderPlugin.class);
        super.onCreate(savedInstanceState);
        // Paint the window / status bar / nav bar with the app background right away so no
        // white strip is ever visible. The web layer re-syncs this when the theme changes.
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        applySystemBars(this, night ? BG_DARK : BG_LIGHT, !night);
        // Hardware/gesture Back: let the web layer decide (close dialog, previous screen,
        // double-press to exit). Registered after super.onCreate so it runs before Capacitor's.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                final WebView wv = (getBridge() != null) ? getBridge().getWebView() : null;
                if (wv == null) { finish(); return; }
                wv.evaluateJavascript(
                    "(function(){try{return window.__krBack?window.__krBack():'none'}catch(e){return 'none'}})()",
                    value -> {
                        // "handled" -> stay. "exit"/"none"/null -> leave the app (keep it in recents).
                        if (value != null && value.contains("handled")) return;
                        moveTaskToBack(true);
                    });
            }
        });
        if (savedInstanceState == null) {
            KRDownloaderPlugin.setPendingIntent(this, getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        KRDownloaderPlugin.setPendingIntent(this, intent);
    }

    /** Colours the window behind/around the WebView and the system bars to match the app theme. */
    @SuppressWarnings("deprecation")
    static void applySystemBars(Activity activity, int color, boolean lightBackground) {
        try {
            Window w = activity.getWindow();
            w.setBackgroundDrawable(new ColorDrawable(color));
            try { w.setStatusBarColor(color); } catch (Throwable ignored) { }
            try { w.setNavigationBarColor(color); } catch (Throwable ignored) { }
            WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
            if (c != null) {
                c.setAppearanceLightStatusBars(lightBackground);
                c.setAppearanceLightNavigationBars(lightBackground);
            }
            if (activity instanceof BridgeActivity) {
                BridgeActivity b = (BridgeActivity) activity;
                if (b.getBridge() != null && b.getBridge().getWebView() != null) {
                    b.getBridge().getWebView().setBackgroundColor(color);
                }
            }
        } catch (Throwable ignored) { }
    }
}
